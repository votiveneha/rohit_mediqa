<ul class="nav nav-pills nav-fill mt-4 tabs-feat" role="tablist">
    <li class="nav-item" role="presentation">
        <a id="basic_details_link" class="nav-link" href="<?php echo e(route('admin.edit_nurse', ['id' => $profileData->id ])); ?>?tab=tab-1">
            <span>Basic Details</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.setting_availablity' ? 'active' : ''); ?>" href="<?php echo e(route('admin.setting_availablity', ['id' => $profileData->id ])); ?>" href="<?php echo e(route('admin.setting_availablity', ['id' => $profileData->id ])); ?>">
            <span>Setting & Availability</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.add_registration_licences' ? 'active' : ''); ?>" href="<?php echo e(route('admin.add_registration_licences', ['id' => $profileData->id ])); ?>">
            <span>Registrations and Licences</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a id="profession_link" class="nav-link" href="<?php echo e(route('admin.edit_nurse', ['id' => $profileData->id ])); ?>?tab=tab-3">
            <span>Profession</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a id="edu_cert_link" class="nav-link" href="<?php echo e(route('admin.edit_nurse', ['id' => $profileData->id ])); ?>?tab=tab-4">
            <span>Education and Certifications</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.mandatory_training_edit' ? 'active' : ''); ?>" href="<?php echo e(route('admin.mandatory_training_edit', ['id' => $profileData->id ])); ?>">
            <span>Mandatory Training and Continuing Education</span>
        </a>
    </li>
    
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.exptab' ? 'active' : ''); ?>" href="<?php echo e(route('admin.exptab', ['id' => $profileData->id])); ?>">
            <span>Experience</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a id="references_link" class="nav-link" href="<?php echo e(route('admin.edit_nurse', ['id' => $profileData->id ])); ?>?tab=tab-6">
            <span>References</span>
        </a>
    </li>
    
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.updateVaccinationRecord' ? 'active' : ''); ?>" href="<?php echo e(route('admin.updateVaccinationRecord', ['id' => $profileData->id ?? null, 'tab' => 'tab-8'])); ?>">
            <span>Vaccinations</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.updateWorkClreance' ? 'active' : ''); ?>" href="<?php echo e(route('admin.updateWorkClreance', ['id' => $profileData->id ?? null, 'tab' => 'tab-8'])); ?>" href="<?php echo e(route('admin.updateWorkClreance', ['id' => $profileData->id ?? null, 'tab' => 'tab-9'])); ?>">
            <span>Checks and Clearances</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.professional_membership_awards' ? 'active' : ''); ?>" href="<?php echo e(route('admin.professional_membership_awards', ['id' => $profileData->id])); ?>" aria-selected="false"
            tabindex="-1">
            <span>Professional Memberships & Awards</span>
        </a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link <?php echo e(Route::currentRouteName() == 'admin.editLanguageSkills' ? 'active' : ''); ?>" href="<?php echo e(route('admin.editLanguageSkills', ['id' => $profileData->id])); ?>">
            <span>Language Skills</span>
        </a>
    </li>
</ul><?php /**PATH /home/mediqa/public_html/resources/views/admin/layouts/edit_nurse_tabs.blade.php ENDPATH**/ ?>