     <?php if(!Auth::guard('nurse_middle')->check()): ?> 
    <footer class="footer mt-50">

      <div class="container">


            <div class="row footer_hide">

          <div class="col-md-3 col-sm-12">

            <a href='index.php'><img alt="jobBox" src="<?php echo e(asset(env('LOGO_PATH'))); ?>" style="width:100px;"></a>

            <div class="mt-20 mb-20 font-sm">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</div>

          </div>

          <div class="col-md-2 col-xs-6"></div>

          <div class="col-md-2 col-xs-6">

            <h6 class="mb-20">Discover</h6>

            <ul class="menu-footer">

              <li><a href="about.php">About Us</a></li>

              <li><a href="contact.php">Contact Us</a></li>

              <li><a href="privacy.php">Privacy Policy</a></li>

              <li><a href="terms.php">Terms & Conditions</a></li>

            </ul>

          </div>

          <div class="col-md-2 col-xs-6">

            <h6 class="mb-20">Explore</h6>

            <ul class="menu-footer">

              <li><a href="<?php echo e(route('nurse.home')); ?>">Become a Nurse</a></li>

              <li><a href="hospital_signup.php">Healthcare Professional</a></li>

              <li><a href="#">become a agency</a></li>

              <li><a href="login.php">Log In</a></li>

            </ul>

          </div>

          <div class="col-md-3 col-sm-12">

            <h6 class="mb-20">Contact</h6>



            <ul class="mb-20">

              <li class="mb-10">

                <div class="d-flex gap-3 align-items-center">

                  <svg width="20" height="20" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">

                  <path d="M19.8862 15.154L29.9999 21.5477V8.49023L19.8862 15.154Z" fill="#000"/>

                  <path d="M0 8.49023V21.5477L10.1138 15.154L0 8.49023Z" fill="#000000"/>

                  <path d="M28.1234 4.6875H1.87344C0.937813 4.6875 0.195312 5.385 0.0546875 6.28313L14.9984 16.1287L29.9422 6.28313C29.8016 5.385 29.0591 4.6875 28.1234 4.6875Z" fill="#000000"/>

                  <path d="M18.1673 16.2861L15.5142 18.0336C15.3567 18.1367 15.1786 18.1873 14.9986 18.1873C14.8186 18.1873 14.6405 18.1367 14.483 18.0336L11.8298 16.2842L0.0585938 23.7298C0.202969 24.6204 0.941719 25.3123 1.87359 25.3123H28.1236C29.0555 25.3123 29.7942 24.6204 29.9386 23.7298L18.1673 16.2861Z" fill="#000"/>

                  </svg>



                  <p class="m-0">email@gmail.com</p>

                </div>

              </li>



              <li >

                <div class="d-flex gap-3 align-items-center">

                  <img src="<?php echo e(asset('nurse/assets/imgs/template/icons/call.svg')); ?>" style="height: 20px;">

                  <p class="m-0">+91 7894561230</p>

                </div>

              </li>

              

            </ul>

              

            <div class="footer-social">

              <a class="icon-socials icon-facebook" href="#"></a>

              <a class="icon-socials icon-twitter" href="#"></a>

              <a class="icon-socials icon-linkedin" href="#"></a>

            </div>

          </div>

        </div>

      

        <div class="footer-bottom mt-50">

          <div class="row footer_profile_cls">

            <div class="col-md-6"><span class="font-xs color-text-paragraph">Copyright &copy; <?php echo e(date('Y')); ?>. Mediqa all right reserved</span></div>

            <div class="col-md-6 text-md-end text-start privacy_option">

              <div class="footer-social"><a class="font-xs color-text-paragraph" href="#">Privacy Policy</a><a class="font-xs color-text-paragraph mr-30 ml-30" href="#">Terms &amp; Conditions</a></div>

            </div>

          </div>

        </div>

      </div>

    </footer> <?php else: ?>

    <footer class="footer pt-0">

      <div class="container">


      

        <div class="footer-bottom ">

          <div class="row footer_profile_cls">

            <div class="col-md-6"><span class="font-xs color-text-paragraph">Copyright &copy; <?php echo e(date('Y')); ?>. Mediqa all right reserved</span></div>

            <div class="col-md-6 text-md-end text-start privacy_option">

              <div class="footer-social"><a class="font-xs color-text-paragraph" href="#">Privacy Policy</a><a class="font-xs color-text-paragraph mr-30 ml-30" href="#">Terms &amp; Conditions</a></div>

            </div>

          </div>

        </div>

      </div>

    </footer>
    <?php endif; ?>

    <script src="<?php echo e(asset('nurse/assets/js/vendor/modernizr-3.6.0.min.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/vendor/jquery-3.6.0.min.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/vendor/jquery-migrate-3.3.0.min.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/vendor/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/waypoints.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/wow.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/magnific-popup.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/perfect-scrollbar.min.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/isotope.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/scrollup.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/swiper-bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/plugins/counterup.js')); ?>"></script>

     <script src="<?php echo e(asset('nurse/assets/js/noUISlider.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/slider.js')); ?>"></script>

    <script src="<?php echo e(asset('nurse/assets/js/main8c94.js?v=4.1')); ?>"></script>





    <script> $(document).ready(function() { 

      // Get the current page URL 

      var currentUrl = window.location.href;

     // Find the navigation link that matches the current URL

      $('.menu-link').each(function() { 

        if (currentUrl.includes($(this).attr('href'))){

         $(this).addClass('active');

     // Add 'active' class to the matched item 

    } 

  }); 

    });

  </script>



  </body>



</html><?php /**PATH /home1/vitalqzv/nextjs.webwiders.in/mediqa/resources/views/nurse/layouts/footer.blade.php ENDPATH**/ ?>