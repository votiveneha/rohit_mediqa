<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="back_arrow" onclick="history.back()" title="Go Back">
        <i class="fa fa-arrow-left"></i>
    </div>
    <div class="card bg-light-info shadow-none position-relative overflow-hidden">
        <div class="card-body px-4 py-3">
            <div class="row align-items-center">
                <div class="col-9">
                    <h4 class="fw-semibold mb-8"> View Profile </h4>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a class="text-muted " href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">View Profile</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-3">
                    <div class="text-center mb-n5">
                        <img src="<?php echo e(asset('admin/dist/images/breadcrumb/ChatBc.png')); ?>" alt=""
                            class="img-fluid" style="height: 125px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card w-100  overflow-hidden">
        <div class="card-body p-3 px-md-4 pb-0">
            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Personal Detail <?php if($profileData->status == 1): ?>
                <span class="badge bg-success ms-2">Unblock</span>
                <?php else: ?>
                <span class="badge bg-danger ms-2">Blocked</span>
                <?php endif; ?>
            </h3>
        </div>
        <div class="card-body p-3 px-md-4">
            <div class="row align-items-center justify-content-between">
                <div class="col ">
                    <div class="d-flex align-items-md-center gap-4 flex-column flex-md-row">
                        <div class="d-flex  mb-2 ">
                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center "
                                style="width: 144px; height: 144px;" ;>
                                <div class="border rounded-circle border-3 border-white d-flex align-items-center justify-content-center  overflow-hidden btn-light commingsoon"
                                    data-bs-toggle="modal" data-bs-target="#commingsoonModel"
                                    style="width: 140px; height: 140px;" ;>
                                    <img src="<?php echo e(asset($profileData->profile_img)); ?>" alt=""
                                        class="w-100 h-100">
                                </div>

                            </div>
                        </div>
                        <div class="w-100">
                            <div class="d-flex justify-content-between">
                                <h5 class="fs-5 mb-2 fw-bolder"> <?php echo e(ucwords($profileData->name)." ".ucwords($profileData->lastname)); ?> </h5>
                                <h5 class="fs-5 mb-2 fw-bolder"> </h5>

                            </div>
                            <?php if($profileData->phone != ''): ?>
                            <p class="d-flex text-dark align-items-center gap-2 mb-1">
                                <i class="ti ti-phone fs-4"></i><strong> +<?php echo e($profileData->country_code); ?>

                                    <?php echo e($profileData->phone); ?>

                                </strong>
                            </p>
                            <?php endif; ?>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <p class="mb-0 d-flex text-dark align-items-center gap-2">
                                    <i class="ti ti-mail fs-4"></i><?php echo e($profileData->email); ?>

                                </p>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->post_code != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Post Code : <?php echo e($profileData->post_code); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->preferred != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Preferred Name : <?php echo e($profileData->preferred); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-">
                                <?php if($profileData->store_url != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Store URL: <?php echo e($profileData->store_url); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>


                        </div>
                    </div>
                </div>



            </div>

        </div>
    </div>
    <div class="card list-drpdwns-set">
        <div class="card-body">
            <?php echo $__env->make("admin.layouts.nurse_view_tabs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="tab-content border mt-2">
                <div class="tab-pane fade" id="tab-my-profile-setting" style="display: block;opacity:1;">
                    <div class="row">
                        <div class=" w-100  overflow-hidden">
                            <div class="card-body p-3 px-md-4 pb-0">
                                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Mandatory Training and Continuing Education</h3>
                            </div>
                            <div class="card-body p-3 px-md-4">
                                <?php if(!empty($trainingData)): ?>
                                <?php
                                    if(!empty($trainingData)){
                                        $organization_data = json_decode($trainingData->training_data);
                                        
                                    }else{
                                        $organization_data = array(); 
                                    }
                                    
                                    
                                    $o_data = (array)$organization_data;
                                    $p_memb_arr = array();

                                    if(!empty($organization_data)){
                                        foreach ($organization_data as $p_memb) {
                                        
                                        //print_r($p_memb);
                                            $p_memb_arr[] = array_search($p_memb, (array)$organization_data);
                                        
                                        }
                                    }
                                
                                ?>
                               
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Completed Mandatory Training</label>
                                    <div>
                                        <?php $__currentLoopData = $p_memb_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_memb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $training_name = DB::table("man_training_category")->where("id",$p_memb)->first();
                                        ?>
                                        <span class="badge bg-dark me-1"><?php echo e($training_name->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>   
                                <?php $__currentLoopData = $p_memb_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    //print_r($o_data[$p_arr]);
                                    $country_name = DB::table("man_training_category")->where("id",$p_arr)->first();
                                    
                                    $os_data = (array)$o_data[$p_arr];
                                    $sub_count_arr = array();
        
                                    foreach ($os_data as $p_memb) {
                                        $sub_count_arr[] = array_search($p_memb, $os_data);
                                    }
                                    
                                ?>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold"><?php echo e($country_name->name); ?></label>
                                    <div>
                                        <?php $__currentLoopData = $sub_count_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_memb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $training_name = DB::table("man_training_category")->where("id",$p_memb)->first();
                                        ?>
                                        <span class="badge bg-dark me-1"><?php echo e($training_name->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $sub_count_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_arr1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php

                                    $country_name = DB::table("man_training_category")->where("id",$p_arr1)->first();
                                    
                                    $oss_data = (array)$os_data[$p_arr1];
                                    //print_r($oss_data['institution']);die;
                                ?>
                                <h5><?php echo e($country_name->name); ?></h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>Institution/Regulating Body:</strong>
                                        <span>
                                            <?php echo e($oss_data['institution']); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Training Start Date:</strong>
                                        <span>
                                            <?php echo e($oss_data['training_start_date']); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Training End Date:</strong>
                                        <span>
                                            <?php echo e($oss_data['training_end_date']); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Expiry:</strong>
                                        <span>
                                            <?php echo e($oss_data['training_expiry_date']); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Upload Certificate:</strong>
                                        <ul>
                                            <?php
                                                if(isset($oss_data['evidence_imgs']) && $oss_data['evidence_imgs']){
                                                    $evidence_imgs = (array)json_decode($oss_data['evidence_imgs']);
                                                    
                                                    //print_r($evidence_imgs);die;
                                                    $i = 0;
                                                    ?>
                                                    <?php if(!empty($evidence_imgs)): ?>
                                                    <?php $__currentLoopData = $evidence_imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        
                                                        <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($ev_img); ?>" target="_blank" style="color: #000000; text-decoration: none;">
                                                            📄 <?php echo e($ev_img); ?>

                                                        </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                            <?php
                                                }
                                            
                                            ?>
                                            
                                        
                                        </ul>
                                        
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h4>Other Trainings</h4>
                                <?php
                                if (!empty($trainingData)) {
                                  $additional_tra_data = json_decode($trainingData->other_tra_data);
                                } else {
                                  $additional_tra_data = "";
                                }
                                $i = 1;
                                $l = 0;
                                ?>
                                <div class="row">
                                    <?php if(!empty($additional_tra_data)): ?>
                                    <?php $__currentLoopData = $additional_tra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div class="col-md-6">
                                        <strong>Training <?php echo e($i); ?>:</strong>
                                        <span>
                                            <?php echo e($a_data->training_name); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Institution/Regulating Body:</strong>
                                        <span>
                                            <?php echo e($a_data->training_ins); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Training Start Date:</strong>
                                        <span>
                                            <?php echo e($a_data->training_start_date); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Training End Date:</strong>
                                        <span>
                                            <?php echo e($a_data->training_end_date); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Expiry:</strong>
                                        <span>
                                            <?php echo e($a_data->tra_exp); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Upload your certification/Licence:</strong>
                                        <?php
                                            $getedufieldsdata = DB::table("edu_fields")->where("user_id", $trainingData->user_id)->first();
                
                                            if (!empty($getedufieldsdata)) {
                                            $other_tra_img = (array)json_decode($getedufieldsdata->other_tran_img);
                                            } else {
                                            $other_tra_img = '';
                                            }
                
                
                                            if (!empty($other_tra_img)) {
                                                $other_tra_img_data = json_decode($other_tra_img["tran_$i"]);
                                            } else {
                                                $other_tra_img_data = "";
                                            }
                                            
                                        ?>
                                        <ul>
                                            
                                        <?php if(!empty($other_tra_img_data)): ?>
                                        <?php $__currentLoopData = $other_tra_img_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            
                                            <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($ev_img); ?>" target="_blank" style="color: #000000; text-decoration: none;">
                                                📄 <?php echo e($ev_img); ?>

                                            </a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                            
                                        </ul>
                                        
                                    </div>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php
                                        $i++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <h4>Mandatory Continuing Education</h4>
                                <?php
                                    
                                    
                                    if(!empty($trainingData)){
                                      $organization_data = json_decode($trainingData->education_data);
                                      
                                    }else{
                                      $organization_data = array(); 
                                    }
                                    
                                    
                                    $o_data = (array)$organization_data;
                                    $p_memb_arr = array();

                                    if(!empty($organization_data)){
                                      foreach ($organization_data as $p_memb) {
                                      
                                        //print_r($p_memb);
                                        $p_memb_arr[] = array_search($p_memb, (array)$organization_data);
                                        
                                      }
                                    }
                                    
                                    
                                ?>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Education Name</label>
                                    <div>
                                        <?php $__currentLoopData = $p_memb_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_memb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $training_name = DB::table("man_training_category")->where("id",$p_memb)->first();
                                        ?>
                                        <span class="badge bg-dark me-1"><?php echo e($training_name->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>   
                                <?php $__currentLoopData = $p_memb_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    //print_r($o_data[$p_arr]);
                                    $country_name = DB::table("man_training_category")->where("id",$p_arr)->first();
                                    
                                    $os_data = (array)$o_data[$p_arr];
                                    $sub_count_arr = array();
        
                                    foreach ($os_data as $p_memb) {
                                        $sub_count_arr[] = array_search($p_memb, $os_data);
                                    }
                                    
                                ?>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold"><?php echo e($country_name->name); ?></label>
                                    <div>
                                        <?php $__currentLoopData = $sub_count_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_memb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $training_name = DB::table("man_training_category")->where("id",$p_memb)->first();
                                        ?>
                                        <span class="badge bg-dark me-1"><?php echo e($training_name->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $sub_count_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_arr1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php

                                    $country_name = DB::table("man_training_category")->where("id",$p_arr1)->first();
                                    
                                    $oss_data = (array)$os_data[$p_arr1];
                                    //print_r($oss_data['institution']);die;
                                ?>
                                <h5><?php echo e($country_name->name); ?></h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>Institution/Regulating Body:</strong>
                                        <span>
                                            <?php echo e($os_data[$p_arr1]->institution); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Start Date:</strong>
                                        <span>
                                            <?php echo e($os_data[$p_arr1]->start_date); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>End Date:</strong>
                                        <span>
                                            <?php echo e($os_data[$p_arr1]->end_date); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Status:</strong>
                                        <span>
                                            <?php echo e($os_data[$p_arr1]->status); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Expiry:</strong>
                                        <span>
                                            <?php echo e($os_data[$p_arr1]->expiry_date); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Upload Certificate:</strong>
                                        <ul>
                                            <?php
                                                if(isset($os_data['evidence_imgs']) && $os_data['evidence_imgs']){
                                                    $evidence_imgs = (array)json_decode($os_data['evidence_imgs']);
                                                    
                                                    //print_r($evidence_imgs);die;
                                                    $i = 0;
                                                    ?>
                                                    <?php if(!empty($evidence_imgs)): ?>
                                                    <?php $__currentLoopData = $evidence_imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        
                                                        <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($ev_img); ?>" target="_blank" style="color: #000000; text-decoration: none;">
                                                            📄 <?php echo e($ev_img); ?>

                                                        </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                            <?php
                                                }
                                            
                                            ?>
                                            
                                        
                                        </ul>
                                        
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <h4>Other Continuing Education</h4>
                                <?php
                                    if (!empty($trainingData)) {
                                        $additional_edu_data = json_decode($trainingData->other_edu_data);
                                    } else {
                                        $additional_edu_data = "";
                                    }
                                    $i = 1;
                                   
                                
                                ?>
                                <div class="row">
                                    <?php if(!empty($additional_edu_data)): ?>
                                    <?php $__currentLoopData = $additional_edu_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div class="col-md-6">
                                        <strong>Course/Workshop <?php echo e($i); ?>:</strong>
                                        <span>
                                            <?php echo e($edu_data->education_name); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Institution/Regulating Body:</strong>
                                        <span>
                                            <?php echo e($edu_data->education_ins); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Start Date:</strong>
                                        <span>
                                            <?php echo e($edu_data->education_start_date); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>End Date:</strong>
                                        <span>
                                            <?php echo e($edu_data->education_end_date); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Status:</strong>
                                        <span>
                                            <?php echo e($edu_data->education_status); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Expiry:</strong>
                                        <span>
                                            <?php echo e($edu_data->education_exp); ?>

                                        </span> 
                                    </div>
                                    <div class="col-md-6">
                                        <strong>Upload your certification/Licence:</strong>
                                        <?php
                                            $getedufieldsdata = DB::table("edu_fields")->where("user_id", $trainingData->user_id)->first();
                
                                            if (!empty($getedufieldsdata)) {
                                                $ano_education_img = (array)json_decode($getedufieldsdata->ano_education_imgs);
                                            } else {
                                                $ano_education_img = '';
                                            }
                
                
                                            if (!empty($ano_education_img)) {
                                                $ano_education_img_data = json_decode($ano_education_img["edu_$i"]);
                                            } else {
                                                $ano_education_img_data = "";
                                            }
                                            
                                        ?>
                                        <ul>
                                            
                                        <?php if(!empty($ano_education_img_data)): ?>
                                        <?php $__currentLoopData = $ano_education_img_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            
                                            <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($ev_img); ?>" target="_blank" style="color: #000000; text-decoration: none;">
                                                📄 <?php echo e($ev_img); ?>

                                            </a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                            
                                        </ul>
                                        
                                    </div>
                                    <?php
                                        $i++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    
                                </div>
                                <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mediqa/public_html/resources/views/admin/mandatory_training_view.blade.php ENDPATH**/ ?>