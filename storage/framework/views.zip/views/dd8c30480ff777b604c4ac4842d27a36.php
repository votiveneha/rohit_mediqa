<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal927bf64738275ef40a237a9b079b6e15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal927bf64738275ef40a237a9b079b6e15 = $attributes; } ?>
<?php $component = App\View\Components\CardComponent::resolve(['parentHeading' => 'Complete Profile Nurse List','childHeading' => 'Complete Profile Nurse List','parentUrl' => ''.e(route('admin.dashboard')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CardComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal927bf64738275ef40a237a9b079b6e15)): ?>
<?php $attributes = $__attributesOriginal927bf64738275ef40a237a9b079b6e15; ?>
<?php unset($__attributesOriginal927bf64738275ef40a237a9b079b6e15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal927bf64738275ef40a237a9b079b6e15)): ?>
<?php $component = $__componentOriginal927bf64738275ef40a237a9b079b6e15; ?>
<?php unset($__componentOriginal927bf64738275ef40a237a9b079b6e15); ?>
<?php endif; ?>
    <div class="card w-100  overflow-hidden ">
        <div class="card-header pb-0 p-4">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <h5 class="card-title fw-semibold mb-0">Complete Profile Nurse List</h5>
                </div>
                
            </div>
        </div>
        <div class="card-body p-3 px-md-4">

            <div class="table-responsive rounded-2 mb-4">
                <table  class="table border table-striped table-bordered text-nowrap">
                    <thead class="text-dark fs-4">
                        <tr>
                            <th>
                                    <h6 class="fs-4 fw-semibold mb-0">Sn.</h6>
                                </th>
                               
                                <th>
                                    <h6 class="fs-4 fw-semibold mb-0"> Full Name</h6>
                                </th>
                                <th>
                                    <h6 class="fs-4 fw-semibold mb-0">Profession</h6>
                                </th>
                            
                                <th>
                                    <h6 class="fs-4 fw-semibold mb-0">Practitioner Type</h6>
                                </th>
                            
                                <th>
                                    <h6 class="fs-4 fw-semibold mb-0">Phone</h6>
                                </th>
                                <th>
                                    <h6 class="fs-4 fw-semibold mb-0">Email</h6>
                                </th>
                                <th class="fs-4 fw-semibold mb-0">Date</th>
                                <th>
                                    <h6 class="fs-4 fw-semibold mb-0 text-end">Action</h6>
                                </th>

                        </tr>
                    </thead>
                    <tbody>
                         <?php $i=1 ?>
                            <?php if($completeprofileUsers): ?>
                                <?php $__currentLoopData = $completeprofileUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <td><?php echo e($i); ?></td>
                                        
                                        <td>
                                            <div class="">
                                                <span class="mb-0 fw-normal fs-3"><?php echo e(ucwords($item->name)); ?> <?php echo e(ucwords($item->lastname)); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="">
                                                <span class="mb-0 fw-normal fs-3"> - - - </span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="">
                                                <span class="mb-0 fw-normal fs-3"> - - - </span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="">
                                                <?php if($item->phone): ?>
                                                <span class="mb-0 fw-normal fs-3">+<?php echo e(isset($item->country_code) ? $item->country_code : ''); ?> <?php echo e($item->phone); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="">
                                                <span class="mb-0 fw-normal fs-3"><?php echo e($item->email); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="">
                                                <span class="mb-0 fw-normal fs-3"><?php echo e(\Carbon\Carbon::parse($item->completed_date)->format('d-m-Y')); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                        <div class="d-flex align-items-center gap-1">
                                            <a href="<?php echo e(route('admin.view-profile', ['id' => $item->id])); ?>"
                                                class="btn btn-primary" data-bs-toggle="tooltip" data-bs-trigger="hover"
                                                title="View">
                                                View
                                            </a>
                                            <button type="button" class="btn btn-success "
                                                onclick="changeStatus(<?php echo e($item->id); ?>,'2')">Approve
                                            </button>
                                            <button type="button" class="btn btn-danger "
                                                onclick="changeStatus(<?php echo e($item->id); ?>,'0')">Reject
                                            </button>
                                        </div>
                                        </td>
                                        <?php $i++ ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php echo e('No Data Found'); ?>

                            <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });

        function changeStatus(id, status) {
            let reasonData = '';
            let swalText = (status == 2 ? "you want to Approve the Nurse" : "You want to Reject The Nurse") + ' ?';
            Swal.fire({
                title: 'Are you sure?',
                text: swalText,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    if (status == 0) {
                        Swal.fire({
                            title: 'Provide a reason',
                            input: 'text',
                            inputLabel: 'Reason for rejection',
                            inputPlaceholder: 'Enter your reason here...',
                            inputValidator: (value) => {
                                if (!value) {
                                    return 'You must provide a reason for rejection.';
                                }
                            }
                        }).then((result) => {
                            if (result.isConfirmed) {
                                reasonData = result.value;
                                sendData(id, status, reasonData);
                            }
                        });
                    } else {
                        sendData(id, status, reasonData);
                    }
                }
            });
        }

        function sendData(id, status, reasonData) {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('admin.change-status')); ?>",
                data: {
                    reasonData: reasonData,
                    id: id,
                    status: status,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(res) {
                    console.log(res);
                    if (res.status == '2') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: res.message,
                        }).then(function() {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: res.message,
                        });
                    }
                },
                error: function(error) {
                    console.log(error);
                }
            });
            return false;
        }

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/phpserver2/public_html/mediqa/resources/views/admin/complete-profile-nurse-list.blade.php ENDPATH**/ ?>