  <?php if(!Auth::guard('nurse_middle')->check()): ?> 
    <header class="header sticky-bar">
      <div class="container">
        <div class="main-header">
          <div class="header-left">
            <div class="header-logo"><a class='d-flex' href='<?php echo e(route("home_main")); ?>'><img alt="jobBox" src="<?php echo e(asset(env('LOGO_PATH'))); ?>"></a></div>
          </div>
          <div class="header-nav">
            <nav class="nav-main-menu">
              <ul class="main-menu">

               <!--  <li class="">
                  <a class='menu-link hover-up' href='<?php echo e(route("nurse.home")); ?>'>Home</a>
                </li> -->

                <li>

                  <a class='menu-link hover-up' href='<?php echo e(route("nurse.home")); ?>'>Nurses</a>

                </li>

                <li class="">
                  <!--<a class='menu-link hover-up' href='medical_facilities.php'>Medical Facilities</a>-->
                  <a class=' hover-up' href='<?php echo e(route("nurse.home")); ?>'>Medical Facilities</a>
                </li>
                <li class="">
                  <!--<a class='' href='agencies.php'>Agencies</a>-->
                  <a class='' href='<?php echo e(route("nurse.home")); ?>'>Agencies</a>
                </li>
                <li class="">
                  <!--<a class='menu-link hover-up' href='contact.php'>Contact</a>-->
                  <a class=' hover-up' href='<?php echo e(route("nurse.home")); ?>'>Contact</a>
                </li>

                



                <!-- <li class="has-children"><a href='#'>Find a Job</a>
                  <ul class="sub-menu">
                    <li><a href='#'>Jobs </a></li>
                    <li><a href='#'>Jobs List</a></li>
                  </ul>
                </li> -->

              </ul>
            </nav>
            <div class="burger-icon burger-icon-white">
              <span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
          </div>
          <div class="header-right">
            <div class="block-signin d-flex align-items-center gap-3 justify-content-end">
              <!-- <a class='text-link-bd-btom hover-up' href='nurse_signup.php'>Become a Nurse</a> -->
            <?php if(request()->is('') || request()->is('/')): ?>
                 <a class='btn btn-default btn-shadow hover-up' href='<?php echo e(route("nurse.home")); ?>'>Sign in</a>
            <?php elseif(request()->is('nurse')): ?>
                <a class='btn btn-default btn-shadow hover-up' href='<?php echo e(route("nurse.login")); ?>'>Sign in</a>
            <?php endif; ?>
            
            </div>
          </div>
        </div>
      </div>
    </header>
    
    <?php else: ?>
    <header class="header sticky-bar  border-bottom">
      <div class="container">
        <div class="main-header">
          <div class="header-left">
            <div class="header-logo"><a class='d-flex' href='<?php echo e(route("home_main")); ?>'><img alt="jobBox" src="<?php echo e(asset(env('LOGO_PATH'))); ?>"></a></div>
          </div>
          <div class="header-nav">
            <nav class="nav-main-menu">
              <ul class="main-menu">
                <li class="">
                  <a class='menu-link hover-up' href='<?php echo e(route("nurse.dashboard")); ?>'>Find Work</a>
                </li>
                <li class="">
                  <a class='hover-up' href='<?php echo e(route("nurse.dashboard")); ?>'>My Work</a>
                </li>
                <!-- <li class="">
                  <a class='' href='recruiter_signup.php'>Agencies Sign Up</a>
                </li> -->
                <li class="">
                  <a class=' hover-up' href='<?php echo e(route("nurse.dashboard")); ?>'>Timesheet</a>
                </li>

                <li>

                  <a class=' hover-up' href='<?php echo e(route("nurse.my-profile")); ?>'>Profile</a>

                </li>

              </ul>
            </nav>
            <div class="burger-icon burger-icon-white">
              <span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span></div>
          </div>
          <div class="header-right">
            <div class="block-signin d-flex align-items-center gap-3 justify-content-end">
              <!-- <a class='text-link-bd-btom hover-up' href='nurse_signup.php'>Become a Nurse</a> -->
              <div class="dropdown d-inline-block">
                <a class="btn btn-notify" id="dropdownNotify" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
                  <i class="fa-regular fa-bell"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-light dropdown-menu-end" aria-labelledby="dropdownNotify">
                  <li><a class="dropdown-item active" href="#">0 notifications</a></li>
                  <li><a class="dropdown-item" href="#">0 messages</a></li>
                  <li><a class="dropdown-item" href="#">0 replies</a></li>
                </ul>
              </div>


              <div class="member-login d-flex align-items-center gap-1">
                <img alt="<?php echo e(Auth::guard('nurse_middle')->user()->name); ?>"src="<?php echo e(asset( Auth::guard('nurse_middle')->user()->profile_img)); ?>">
                <div class="info-member"> 
                  <div class="dropdown">

                    <a class="font-xs color-text-paragraph-2 icon-down" data-bs-toggle="dropdown"><strong class="color-brand-1"><?php echo e(Auth::guard('nurse_middle')->user()->name); ?></strong></a>
                    <ul class="dropdown-menu dropdown-menu-light dropdown-menu-end" aria-labelledby="dropdownProfisle">
                      <!-- <li> --><a href='<?php echo e(route("nurse.my-profile")); ?>' class="dropdown-item" >Profile</a><!-- </li> -->
                     <!--  <li> --><a href="#" class="dropdown-item" >change Password</a><!-- </li> -->
                      <!-- <li> --><a href='<?php echo e(route("nurse.logout")); ?>' class="dropdown-item" >Logout</a><!-- </li> -->
                    </ul>
                  </div>
                </div>
              </div>
              <!-- <a class='btn btn-default btn-shadow hover-up' href='#'>Sign in</a> -->
            </div>
          </div>
        </div>
      </div>
    </header>
    <?php endif; ?>
<?php /**PATH /home1/vitalqzv/nextjs.webwiders.in/mediqa/resources/views/nurse/layouts/header.blade.php ENDPATH**/ ?>