<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal927bf64738275ef40a237a9b079b6e15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal927bf64738275ef40a237a9b079b6e15 = $attributes; } ?>
<?php $component = App\View\Components\CardComponent::resolve(['parentHeading' => 'Dashboard','childHeading' => 'Dashboard','parentUrl' => ''.e(route('admin.dashboard')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CardComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal927bf64738275ef40a237a9b079b6e15)): ?>
<?php $attributes = $__attributesOriginal927bf64738275ef40a237a9b079b6e15; ?>
<?php unset($__attributesOriginal927bf64738275ef40a237a9b079b6e15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal927bf64738275ef40a237a9b079b6e15)): ?>
<?php $component = $__componentOriginal927bf64738275ef40a237a9b079b6e15; ?>
<?php unset($__componentOriginal927bf64738275ef40a237a9b079b6e15); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/vitalqzv/nextjs.webwiders.in/mediqa/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>