<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="back_arrow" onclick="history.back()" title="Go Back">
        <i class="fa fa-arrow-left"></i>
    </div>
    <div class="card bg-light-info shadow-none position-relative overflow-hidden">
        <div class="card-body px-4 py-3">
            <div class="row align-items-center">
                <div class="col-9">
                    <h4 class="fw-semibold mb-8"> View Profile </h4>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a class="text-muted " href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">View Profile</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-3">
                    <div class="text-center mb-n5">
                        <img src="<?php echo e(asset('admin/dist/images/breadcrumb/ChatBc.png')); ?>" alt=""
                            class="img-fluid" style="height: 125px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card w-100  overflow-hidden">
        <div class="card-body p-3 px-md-4 pb-0">
            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Personal Detail <?php if($profileData->status == 1): ?>
                <span class="badge bg-success ms-2">Unblock</span>
                <?php else: ?>
                <span class="badge bg-danger ms-2">Blocked</span>
                <?php endif; ?>
            </h3>
        </div>
        <div class="card-body p-3 px-md-4">
            <div class="row align-items-center justify-content-between">
                <div class="col ">
                    <div class="d-flex align-items-md-center gap-4 flex-column flex-md-row">
                        <div class="d-flex  mb-2 ">
                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center "
                                style="width: 144px; height: 144px;" ;>
                                <div class="border rounded-circle border-3 border-white d-flex align-items-center justify-content-center  overflow-hidden btn-light commingsoon"
                                    data-bs-toggle="modal" data-bs-target="#commingsoonModel"
                                    style="width: 140px; height: 140px;" ;>
                                    <img src="<?php echo e(asset($profileData->profile_img)); ?>" alt=""
                                        class="w-100 h-100">
                                </div>

                            </div>
                        </div>
                        <div class="w-100">
                            <div class="d-flex justify-content-between">
                                <h5 class="fs-5 mb-2 fw-bolder"> <?php echo e(ucwords($profileData->name)." ".ucwords($profileData->lastname)); ?> </h5>
                                <h5 class="fs-5 mb-2 fw-bolder"> </h5>

                            </div>
                            <?php if($profileData->phone != ''): ?>
                            <p class="d-flex text-dark align-items-center gap-2 mb-1">
                                <i class="ti ti-phone fs-4"></i><strong> +<?php echo e($profileData->country_code); ?>

                                    <?php echo e($profileData->phone); ?>

                                </strong>
                            </p>
                            <?php endif; ?>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <p class="mb-0 d-flex text-dark align-items-center gap-2">
                                    <i class="ti ti-mail fs-4"></i><?php echo e($profileData->email); ?>

                                </p>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->post_code != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Post Code : <?php echo e($profileData->post_code); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->preferred != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Preferred Name : <?php echo e($profileData->preferred); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-">
                                <?php if($profileData->store_url != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Store URL: <?php echo e($profileData->store_url); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>


                        </div>
                    </div>
                </div>



            </div>

        </div>
    </div>
    <div class="card list-drpdwns-set">
        <div class="card-body">
            <?php echo $__env->make("admin.layouts.nurse_view_tabs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="tab-content border mt-2">
                <div class="tab-pane p-3 active show" id="navpill-1" role="tabpanel">
                    <div class=" w-100  overflow-hidden">
                        <div class="card-body p-3 px-md-4 pb-0">
                            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Professional Information
                            </h3>
                        </div>
                        <div class="card-body p-3 px-md-4">
                            <div class="col-md-12">

                                <?php if($profileData->nurseType && $profileData->specialties): ?>
                                <div class="row">

                                    <?php if($profileData->nurseType != 'null'): ?>
                                    <?php $nurseType=json_decode($profileData->nurseType); ?>
                                    <?php if(is_array($nurseType)): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Profession : </strong>
                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $nurseType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(specialty_name_by_id_NEW($ubspecialty)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom">No specialties available</a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($profileData->nurseType != 'null'): ?>
                                    <?php
                                    $nurseType = json_decode($profileData->nurseType);

                                    // Ensure $nurseType is an array
                                    $nurseType = is_array($nurseType) ? $nurseType : [];
                                    $nursepra = [];

                                    ?>

                                    <?php $__currentLoopData = $nurseType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php

                                    $specialtyName = specialty_name_by_id_NEW($ubspecialty);

                                    $normalizedSpecialty = strtolower(str_replace('_', ' ', $specialtyName));

                                    // Define strings to compare
                                    $string1 = 'entry level nursing';
                                    $string2 = 'registered nurses';
                                    $string3 = 'advanced practitioner';

                                    // Extract words from normalized specialty
                                    $words = explode(' ', $normalizedSpecialty);
                                    $firstWord = isset($words[0]) ? strtolower($words[0]) : '';
                                    $secondWord = isset($words[1]) ? strtolower($words[1]) : '';
                                    $firstTwoWords = $firstWord . ' ' . $secondWord;

                                    // Determine the correct nurse sub-job type
                                    if ($normalizedSpecialty === $string1) {
                                    $nursesubjobType = json_decode($profileData->entry_level_nursing);

                                    } elseif ($firstTwoWords === strtolower($string2)) {
                                    $nursesubjobType = json_decode($profileData->registered_nurses);
                                    } elseif ($firstWord === 'advanced') {
                                    $nursepra = $profileData->advanced_practioner;
                                    $nursesubjobType = json_decode($profileData->advanced_practioner);
                                    } else {
                                    $nursesubjobType = json_decode($profileData->advanced_practioner); // Default case
                                    }

                                    // Ensure $nursesubjobType is an array
                                    $nursesubjobType = is_array($nursesubjobType) ? $nursesubjobType : [];
                                    ?>

                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong><?php echo e($specialtyName); ?>:</strong>

                                            
                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $nursesubjobType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                                <li><span class="dropdown-item-custom"><?php echo e(specialty_name_by_id_NEW($subtype)); ?> , </span></li>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <?php
                                    // Decode the JSON strings to associative arrays
                                    // $nursepraArray = json_decode($nursepra, true); // `true` to return an associative array
                                    $nursepraArray = is_string($nursepra) ? json_decode($nursepra, true) : (is_array($nursepra) ? $nursepra : []);

                                    // Ensure $profileData is not null and has the required properties
                                    $profileData = $profileData ?? new stdClass();
                                    // $nurse_prac = isset($profileData->nurse_prac) ? json_decode($profileData->nurse_prac, true) : [];
                                    $nurse_prac = isset($profileData->nurse_prac)
                                        ? (is_string($profileData->nurse_prac)
                                            ? json_decode($profileData->nurse_prac, true)
                                            : (is_array($profileData->nurse_prac)
                                                ? $profileData->nurse_prac
                                                : []))
                                        : [];
                                    ?>

                                    <?php if(is_array($nursepraArray) && in_array(179, $nursepraArray)): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Nurse Practitioner (NP) : </strong>
                                            

                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $nurse_prac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(specialty_name_by_id_NEW($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($profileData->specialties != 'null'): ?>
                                    <?php $specialties=json_decode($profileData->specialties); ?>
                                    <?php if(is_array($specialties)): ?>
                                    <div class="col-md-12 mt-4">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Specialties : </strong>
                                            
                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if($profileData->specialties != 'null'): ?>
                                    <?php
                                    $specialties = json_decode($profileData->specialties);

                                    // Ensure $nurseType is an array
                                    $specialties = is_array($specialties) ? $specialties : [];
                                    $surgical_preoperative = [];
                                    $surgical_obstrics_gynacology = [];
                                    $neonatal_care = [];
                                    $paedia_surgical_preoperative = [];
                                    $i= 1;
                                    ?>

                                    <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php

                                    $specialtyName = practitioner_type_by_id($ubspecialty);

                                    $normalizedSpecialty = strtolower(str_replace('_', ' ', $specialtyName));

                                    // Define strings to compare
                                    $string1 = 'adults';
                                    $string2 = 'maternity';
                                    $string3 = 'paediatrics neonatal';
                                    $string4 = 'community';

                                    // Extract words from normalized specialty
                                    $words = explode(' ', $normalizedSpecialty);
                                    $firstWord = isset($words[0]) ? strtolower($words[0]) : '';
                                    $secondWord = isset($words[1]) ? strtolower($words[1]) : '';
                                    $firstTwoWords = $firstWord . ' ' . $secondWord;

                                    // Determine the correct nurse sub-job type
                                    if ($normalizedSpecialty === $string1) {
                                    $surgical_preoperative = $profileData->adults;
                                    $specsubType = json_decode($profileData->adults);
                                    } elseif ($firstWord === strtolower($string2)) {
                                    $surgical_obstrics_gynacology = $profileData->maternity;
                                    $specsubType = json_decode($profileData->maternity);
                                    } elseif ($firstTwoWords === strtolower($string3)) {
                                    $neonatal_care = $profileData->paediatrics_neonatal;
                                    $paedia_surgical_preoperative = $profileData->paediatrics_neonatal;
                                    $specsubType = json_decode($profileData->paediatrics_neonatal);
                                    } elseif ($firstWord === strtolower($string4)) {


                                    $specsubType = json_decode($profileData->community);
                                    }else {
                                    $specsubType = json_decode($profileData->community); // Default case
                                    }

                                    // Ensure $nursesubjobType is an array
                                    $specsubType = is_array($specsubType) ? $specsubType : [];
                                    ?>

                                    <div class="col-md-12 mt-4" id="cat_<?php echo e($i); ?>">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong><?php echo e($specialtyName); ?>:</strong>

                                            

                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $specsubType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>

                                        </div>
                                    </div>
                                    <?php $i++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>

                                    <?php


                                    $surgicalArray = is_string($surgical_preoperative) ? json_decode($surgical_preoperative, true) : (is_array($surgical_preoperative) ? $surgical_preoperative : []);

                                    $profileData = $profileData ?? new stdClass();
                                    $sargicaldata = isset($profileData->surgical_preoperative) ? json_decode($profileData->surgical_preoperative, true) : [];
                                    $operating_room = isset($profileData->operating_room) ? json_decode($profileData->operating_room, true) : [];
                                    $operating_room_scout = isset($profileData->operating_room_scout) ? json_decode($profileData->operating_room_scout, true) : [];
                                    $operating_room_scrub = isset($profileData->operating_room_scrub) ? json_decode($profileData->operating_room_scrub, true) : [];
                                    ?>

                                    <?php if(is_array($surgicalArray) && in_array(96, $surgicalArray)): ?>
                                    <div class="col-md-12 mt-3" id="sugical_care">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Surgical Preoperative and Postoperative Care : </strong>
                                            

                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $sargicaldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($ubspecialty)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php if(!empty($operating_room)): ?>
                                    <div class="col-md-12 mt-3" id="Operating_Room">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Operating Room (OR) : </strong>
                                            
                                            <ul class="dropdown-list">
                                                
                                                <?php $__empty_1 = true; $__currentLoopData = $operating_room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $operating_rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($operating_rooms)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($operating_room_scout)): ?>
                                    <div class="col-md-12 mt-3" id="paediatric_oR">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong>Paediatric OR: Scout (Circulating Nurse) : </strong>
                                            
                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $operating_room_scout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $operating_room_scouts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($operating_room_scouts)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($operating_room)): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap" id="Technician_Nurse">
                                            <strong> Paediatric OR: Scrub (Technician Nurse) : </strong>
                                            
                                            <ul class="dropdown-list">
                                                
                                                <?php $__empty_1 = true; $__currentLoopData = $operating_room_scrub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $operating_room_scrubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($operating_room_scrubs)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>

                                    <?php

                                    $gynacologyArray = is_string($surgical_obstrics_gynacology) ? json_decode($surgical_obstrics_gynacology, true) : (is_array($surgical_obstrics_gynacology) ? $surgical_obstrics_gynacology : []);

                                    $profileData = $profileData ?? new stdClass();
                                    $surgical_preoperative = isset($profileData->surgical_obstrics_gynacology) ? json_decode($profileData->surgical_obstrics_gynacology, true) : [];
                                    ?>

                                    <?php if(is_array($gynacologyArray) && in_array(233, $gynacologyArray)): ?>
                                    <div class="col-md-12 mt-3" id="Surgical_Obstetrics">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Surgical Obstetrics and Gynecology (OB/GYN) : </strong>
                                            
                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $surgical_preoperative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <?php
                                    $neonatalcareArray = is_string($neonatal_care) ? json_decode($neonatal_care, true) : (is_array($neonatal_care) ? $neonatal_care : []);
                                    $profileData = $profileData ?? new stdClass();
                                    $neonatal_care = isset($profileData->neonatal_care) ? json_decode($profileData->neonatal_care, true) : [];
                                    ?>

                                    <?php if(is_array($neonatalcareArray) && in_array(250, $neonatalcareArray)): ?>
                                    <div class="col-md-12 mt-3" id="Neonatal_Care">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Neonatal Care : </strong>
                                            
                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $neonatal_care; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <?php
                                    $paediaArray = is_string($paedia_surgical_preoperative) ? json_decode($paedia_surgical_preoperative, true) : (is_array($paedia_surgical_preoperative) ? $paedia_surgical_preoperative : []);
                                    $profileData = $profileData ?? new stdClass();
                                    $paedia_surgical_preoperative = isset($profileData->paedia_surgical_preoperative) ? json_decode($profileData->paedia_surgical_preoperative, true) : [];
                                    $pad_op_room = isset($profileData->pad_op_room) ? json_decode($profileData->pad_op_room, true) : [];
                                    $pad_qr_scout = isset($profileData->pad_qr_scout) ? json_decode($profileData->pad_qr_scout, true) : [];
                                    $pad_qr_scrub = isset($profileData->pad_qr_scrub) ? json_decode($profileData->pad_qr_scrub, true) : [];
                                    ?>

                                    <?php if(is_array($paediaArray) && in_array(285, $paediaArray)): ?>
                                    <div class="col-md-12 mt-3" id="Surgical_Preop">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Paediatric Surgical Preop. and Postop. Care : </strong>
                                            
                                            <ul class="dropdown-list">
                                                <?php $__empty_1 = true; $__currentLoopData = $paedia_surgical_preoperative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <?php if(!empty($pad_op_room)): ?>
                                    <div class="col-md-12 mt-3" id="Paediatric_Operating">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Paediatric Operating Room (OR) : </strong>
                                            
                                            <ul class="dropdown-list">
                                                
                                                
                                                <?php $__currentLoopData = $pad_op_room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($pad_qr_scout)): ?>
                                    <div class="col-md-12 mt-3" id="Paediatric_Operating_Scout">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong>Paediatric OR: Scout (Circulating Nurse) : </strong>
                                            
                                            <ul class="dropdown-list">
                                                
                                                <?php $__empty_1 = true; $__currentLoopData = $pad_qr_scout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($pad_qr_scrub)): ?>
                                    <div class="col-md-12 mt-3" id="Paediatric_Operating_Scrub">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong> Paediatric OR: Scrub (Technician Nurse) : </strong>
                                            <ul class="dropdown-list">
                                                
                                                <?php $__empty_1 = true; $__currentLoopData = $pad_qr_scrub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                <?php endif; ?>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if($profileData->assistent_level): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <?php
                                                $assistent_level = $profileData->assistent_level;   
                                            ?>
                                            <strong>What is your overall level of experience in nursing/midwifery?</strong> <span><?php echo e($assistent_level); ?> <?php echo e($assistent_level == 1 ? 'st' : ($assistent_level == 2 ? 'nd' : ($assistent_level == 3 ? 'rd' : 'th'))); ?>

                              Year</span>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($profileData->current_employee_status): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                           
                                            <strong>Current Employment Status</strong>
                                            <span><?php echo e($profileData->current_employee_status); ?></span>
                                        </div>
                                    </div>
                                   
                                    <?php if($profileData->permanent_status): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                           
                                            <strong>Permanent</strong>
                                            <span><?php echo e($profileData->permanent_status); ?></span>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($profileData->temporary_status): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                           
                                            <strong>Temporary</strong>
                                            <span><?php echo e($profileData->temporary_status); ?></span>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($profileData->current_employee_status == "Unemployed"): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                           
                                            <strong>Reason for Unemployment</strong>
                                            <span><?php echo e($profileData->unemployeed_status); ?></span>
                                        </div>
                                    </div>
                                    <?php if($profileData->unemployeed_status == "Other (Please specify)"): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                           
                                            <strong>Other (Please specify)</strong>
                                            <span><?php echo e($profileData->unemployeed_reason); ?></span>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($profileData->long_unemplyeed): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                           
                                            <strong>How long have you been unemployed?</strong>
                                            <span><?php echo e($profileData->long_unemplyeed); ?></span>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if($profileData->bio): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong>Professional Bio : </strong> <span><?php echo e($profileData->bio); ?></span>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <?php if($profileData->current_employee_status): ?>
                                    <div class="col-md-12 mt-3">
                                        <div class="d-flex gap-3 flex-wrap">
                                            <strong>Current Employee Status : </strong> <span><?php echo e($profileData->current_employee_status); ?></span>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php else: ?>
                                <div class="col-md-12">
                                    <div class="text-center text-danger fs-5">No data found</div>
                                </div>

                                <?php endif; ?>


                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mediqa/public_html/resources/views/admin/view_profession.blade.php ENDPATH**/ ?>