<?php $__env->startSection('css'); ?>

<style type="text/css">
#container {
/*  max-width: 550px;  */
}
.reqError {
    color:red;
}
.step-container {
  position: relative;
  text-align: center;
  transform: translateY(-43%);
}

.step-circle {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background-color: #fff;
  border: 2px solid #000000;
  line-height: 30px;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 10px;
  cursor: pointer; /* Added cursor pointer */
}

.step-line {
  position: absolute;
  top: 16px;
  left: 50px;
  width: calc(100% - 100px);
  height: 2px;
  background-color: #000000;
  z-index: -1;
}

#multi-step-form{
  overflow-x: hidden;
}

#multi-step-form .step-1:before, #multi-step-form .step-2:before{
   display: none;
}


.progress-bar {
    display: flex;
    flex-direction: column;
    justify-content: center;
    overflow: hidden;
    color: #fff;
    text-align: center;
    white-space: nowrap;
    background-color: #000000;
    transition: width .6s ease;
}
.activ1, .activ {
    background: #000;
    color: #fff;
}


span.select2.select2-container {
    padding: 5px !important;
    width: 100 !important;
}


.select2-container--default .select2-selection--multiple {
    background-color: white !important;
    border: 1px solid #0000 !important;
    border-radius: 4px !important;
    cursor: text !important;
}

.select2-container--default .select2-selection--multiple .select2-selection__choice {
    background-color: #000 !important;
    border: 1px solid #000 !important;
    border-radius: 4px !important;
    cursor: default !important;
    float: left !important;
    margin-right: 5px !important;
    margin-top: 5px !important;
    color: #fff !important;
    padding: 2px 10px 5px !important;
}

.select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
    color: #fff !important;
    cursor: pointer !important;
    display: inline-block !important;
    font-weight: bold !important;
    margin-right: 10px !important;
    font-size: 20px !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main class="main">
      <section class="pt-100 login-register">

      	<div id="container" class="container mt-5">
          <div class="row justify-content-center">
            <div class="col-md-5">
               <div class="progress px-1" style="height: 3px;">
        <div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
      </div>


      <div class="step-container d-flex justify-content-between">
        <div class="step-circle" onclick="displayStep(1)">1</div>
        <div class="step-circle" onclick="displayStep(2)">2</div>
        <div class="step-circle" onclick="displayStep(3)">3</div>
      </div>
            </div>
          </div>
		 

		  <form id="multi-step-form" >
                <?php echo csrf_field(); ?>
		    <div class="step step-1">
		      <!-- Step 1 form fields here -->
		      <div class="row ">
            <div class="col-lg-5 col-md-6 col-sm-12 mx-auto">
              <div class="text-center">
                <!-- <p class="font-sm text-brand-2">Register </p> -->
                <h2 class="mt-10 mb-5 text-brand-1 fs_24">Let's get started. See all the shifts & rates of pay. No onboarding needed.</h2>
                
              </div>
              <div class="login-register text-start mt-20" action="#">
                <div class="form-group">
                    
                   
                  <label class="form-label" for="input-1">Do you have work rights in Austrailia?</label>

                    <button class="btn social-login hover-up mb-20 btn_select yes_btn position-relative">
                        <strong>Yes</strong>
                        <input type="radio" class="position-absolute w-100 top-0 left-0" id="yes" name="work_right" value="1" style="opacity: 0;">
                    </button>
                    <button class="btn social-login hover-up mb-20 btn_select no_btn position-relative">
                        <strong>No</strong>
                        <input type="radio"  class="position-absolute w-100 top-0 left-0" id="no" name="work_right" value="0" style="opacity: 0;">
                    </button>
                </div>
                
              </div>

          <button type="button" class="btn btn-default w-100 next-step">Next</button>

            </div>
            
          </div>

		    </div>

		    <div class="step step-2">
		      <!-- Step 2 form fields here -->
		      <div class="row ">
            <div class="col-lg-5 col-md-6 col-sm-12 mx-auto">
              <div class="text-center">
                <!-- <p class="font-sm text-brand-2">Register </p> -->
                <h2 class="mt-10 mb-5 text-brand-1 fs_24">Tell us about your qualifications</h2>
               
              </div>
              <div class="login-register text-start mt-20" action="#">


                <div class="form-group">
                    <label class="form-label" for="input-1">What profession are you qualified in?</label>
                    <select class="form-control" name="profession" id="specialtyId">
                       
                         
                        <?php $specialty = specialty();$spcl=$specialty[0]->id;?>
                        <?php $__currentLoopData = $specialty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($spl->id); ?>"><?php echo e($spl->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                 <span id="reqspecialtyId" class="reqError valley"></span>

                 <?php $sub_specialty = sub_specialty($spcl); $count=count($sub_specialty);?>
               
                <div class="" id="nurse_select">
            <?php if($count > 0): ?>
                <div class="form-group" id="subspecialtyGroup">
                    <label class="form-label" for="input-1">What practitioner type are you?</label>
                    <select class="form-input mr-10 select-active" name="practitionertype" id="subspecialtyId">
                        <?php $__currentLoopData = $sub_specialty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sspl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sspl->id); ?>"><?php echo e($sspl->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                 <span id="reqsubspecialtyId" class="reqError valley"></span>
            <?php endif; ?>
                
                


                
                <div class="form-group">
                  <label class="form-label" for="input-1">What Assistant in Nursing level are you?</label>
                  <!-- <input class="form-control" type="text" required="" name="fullname" placeholder="Steven Job"> -->
                  <select class="form-input mr-10 select-active" name="assistent_level">
                      <option value="">Select</option>
                      <option value="1st Year">1st Year</option>
                      <option value="2nd Year">2nd Year</option>
                      <option value="3rd Year">3rd Year</option>
                     <option value="4th Year">4th Year</option>
                    </select>
                </div>
                 <span id="reqassistent_level" class="reqError valley"></span>
                </div>

                <div class="" id="mid_select">
                  <div class="form-group">
                  <label class="form-label" for="input-1">Specialties</label>
                  <!-- <input class="form-control" type="text" required="" name="fullname" placeholder="Steven Job"> -->
                 

                  <select class="form-input mr-10 select-active" name="specialties[]" multiple>
                      <option value="">Select</option>
                         <?php $practitioner_type = practitioner_type(); ?>
                        <?php $__currentLoopData = $practitioner_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ptl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ptl->id); ?>"><?php echo e($ptl->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span id="reqspecialties" class="reqError valley"></span>
                </div>
                

                </div>
                
              </div>
              <div class="d-flex align-items-center justify-content-between">
                
              <button type="button" class="btn btn-border-brand-2 prev-step">Previous</button>
              <button type="button" class="btn btn-default next-step">Next</button>
              </div>
            </div>
          </div>

		      
		    </div>

		    <div class="step step-3">
		      <!-- Step 3 form fields here -->
		     <div class="row ">
            <div class="col-lg-5 col-md-6 col-sm-12 mx-auto">
              <div class="text-center">
                <!-- <p class="font-sm text-brand-2">Register </p> -->
                <h2 class="mt-10 mb-5 text-brand-1 fs_24">You’re moments away from seeing job opportunities, and their rates</h2>
              </div>

              <div class="login-register text-start mt-20" action="#">
                <div class="form-group">
                  <label class="form-label" for="input-1">Preferred Name*</label>
                  <input class="form-control" type="text" required="" name="preferred"  id="preferredI" placeholder="Enter Your Preferred Name">
                   <span id="reqTxtpreferredI" class="reqError valley"></span>
                </div>
                <div class="form-group">
                  <label class="form-label" for="input-1">Legal First Name *</label>
                  <input class="form-control" type="text" required="" name="fullname"  id="firstNameI" placeholder="Steven Job">
                   <span id="reqTxtfirstNameI" class="reqError valley"></span>
                </div>
                <div class="form-group">
                  <label class="form-label" for="input-1">Last Name *</label>
                  <input class="form-control" type="text" required="" name="lastname"  id="lastNameI" placeholder="Enter Your Last name">
                   <span id="reqTxtlastNameI" class="reqError valley"></span>
                </div>
               
                <div class="form-group">
                  <label class="form-label" for="input-2">Email *</label>  
                  <input class="form-control"  type="email"  name="email"  id="emailI" onkeyup="emailVerifi()" placeholder="stevenjob@gmail.com">
                  <span id="reqTxtemailI" class="reqError valley"></span>
                </div>
                <div class="form-group">
                  <label class="form-label" for="input-3">Mobile Number *</label>

                  <div class="row">
                    <div class="col-md-3">
                      <select name="countryCode" id="countryCode" class="form-control" placeholder="C. Code" aria-label="Default select example">
                           <?php $country_phone_code  = country_phone_code();?>
                                <?php $__empty_1 = true; $__currentLoopData = $country_phone_code; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($cpc->phonecode!='0'): ?>
                                        <option data-countryCode="GB" value="<?php echo e($cpc->phonecode); ?>">(+<?php echo e($cpc->phonecode); ?>)</option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                    </select>
                    </div>
                    <div class="col-md-9">
                      <input class="form-control numbers" type="text" required="" name="contact" id="contactI" placeholder="1234567890">
                  <span id="reqTxtcontactI" class="reqError valley"></span>
                    </div>
                  </div>
                    

                  
                </div>
                <div class="form-group">
                  <label class="form-label" for="input-4">Post Code *</label>
                  <input class="form-control numbers"  type="text" required="" name="post_code" id="post_codeI" placeholder="123456">
                  <span id="reqTxtpost_codeI" class="reqError valley"></span>
                </div>
                <div class="form-group">
                  <label class="form-label" for="input-4">Password *</label>
                  <input class="form-control" type="password" required=""  name="password" id="passwordI" placeholder="********">
                   <span id="reqTxtpasswordI" class="reqError valley"></span>
                </div>
                <div class="form-group">
                  <label class="form-label" for="input-4">Confirm Password *</label> 
                  <input class="form-control" type="password" required=""id="confirm_passwordI" name="confirm_password"  placeholder="********">
                   <span id="reqTxtconfirm_passwordI" class="reqError valley"></span>
                </div>

                <!--<div class="login_footer form-group d-flex justify-content-between">-->
                <!--  <label class="cb-container">-->
                <!--    <input type="checkbox"><span class="text-small">Agree our terms and policy</span><span class="checkmark"></span>-->
                <!--  </label><a class='text-muted' href='#'>Lean more</a>-->
                <!--</div>-->
              </div>

              <div class="d-flex align-items-center justify-content-between">
                
              <button type="button" class="btn btn-border-brand-2 prev-step">Previous</button>
              <!--<a type="button" class="btn btn-default" href="email_verification.php">Submit &amp; Register</a>-->
               <button onclick="dosignup()" class="btn btn-default px-5 py-8  rounded-2 mb-0 submit-btn-120" type="submit"><span class="resetpassword">Submit &amp; Register</span>
                                                <div class="spinner-border submit-btn-1" role="status" style="display:none;">
                                                    <span class="sr-only">Loading...</span>
                                                </div>
                                            </button>
              </div>
              


            </div>
          </div>


		      
		    </div>
		  </form>


		</div>

      </section>
    </main>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function(){
    $('.option1').on('click', function(){
    $('#nurse_select').removeClass('d-none');
    });

    $('.option2').on('click', function(){
    $('#mid_select').removeClass('d-none');
    });
  });
</script>



<script type="text/javascript">
var currentStep = 1;
var updateProgressBar;

// function displayStep(stepNumber) {
//     alert();
//   if (stepNumber >= 1 && stepNumber <= 3) {
//     $(".step-" + currentStep).hide();
//     $(".step-" + stepNumber).show();
//     currentStep = stepNumber;
//     updateProgressBar();
//   }
// }

  $(document).ready(function() {
    $('#multi-step-form').find('.step').slice(1).hide();
  
    $(".next-step").click(function() {
       
    
      if (currentStep < 3) {
          if(currentStep ==1){
               if ($('input[name="work_right"]:checked').length === 0) {
                // If none is checked, show an alert and return false
                alert("Please select whether you have work rights in Australia.");
                return false;
            }
              
          }
          if(currentStep ==2){
              $(".valley").html("");
              
              if(validateForm()==false){
               return false;
              }
            
          }
          
          
          
        $(".step-" + currentStep).addClass("animate__animated animate__fadeOutLeft");
        currentStep++;
        setTimeout(function() {
          $(".step").removeClass("animate__animated animate__fadeOutLeft").hide();
          $(".step-" + currentStep).show().addClass("animate__animated animate__fadeInRight");
          updateProgressBar();
        }, 500);
      }
    });

    $(".prev-step").click(function() {
      if (currentStep > 1) {
        $(".step-" + currentStep).addClass("animate__animated animate__fadeOutRight");
        currentStep--;
        setTimeout(function() {
          $(".step").removeClass("animate__animated animate__fadeOutRight").hide();
          $(".step-" + currentStep).show().addClass("animate__animated animate__fadeInLeft");
          updateProgressBar();
        }, 500);
      }
    });

    updateProgressBar = function() {
      var progressPercentage = ((currentStep - 1) / 2) * 100;
      $(".progress-bar").css("width", progressPercentage + "%");
    }
  });

</script>
<script>
    function validate(step_no){
        
    }
</script>
<script type="text/javascript">
   $(document).ready(function(){
    $('#specialtyId').change(function(){
        var specialtyId = $(this).val();
        if (specialtyId !== '') {
            // Show the subspecialty select input group

            // Fetch the subspecialties based on the selected specialty
            $.ajax({
                url: '<?php echo e(route("nurse.fetch-subspecialty")); ?>',
                method: 'GET',
                data: {specialty_id: specialtyId},
                success: function(response) {
                    // Clear existing options
                    $('#subspecialtyId').empty();
                    // Check if there are subspecialties available
                    if (response.subspecialty.length > 0) {
                        // If there are subspecialties available, show the subspecialty select input group
                        $('#subspecialtyGroup').show();
                    // Add new options
                    $.each(response.subspecialty, function(index, subspecialty) {
                        $('#subspecialtyId').append('<option value="' + subspecialty.id + '">' + subspecialty.name + '</option>');
                    });
}else{
    // If no subspecialties are available, hide the subspecialty select input group
                        $('#subspecialtyGroup').hide();
}
                   
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        } else {
            // If no specialty is selected, hide the subspecialty select input group
            
            // Clear options of subspecialty select input
            $('#subspecialtyId').empty();
            
            // Hide the subspecialty select input group
            $('#subspecialtyGroup').hide();
        }
    });
});

</script>
<script>
    function validateForm() {
        var isValid = true;
        $('[name="profession"]').next('.text-danger').remove();
       
        $('[name="practitionertype"]').next('.text-danger').remove();
       
        $('[name="assistent_level"]').next('.text-danger').remove();
        $('[name="specialties[]"]').next('.text-danger').remove();
         
        
        // Validate specialty select
        if ($('[name="specialty"]').val() == '') {
           document.getElementById("reqspecialtyId").innerHTML = "*  Please select an Specialty.";
            //  $('<div class="text-danger">Please select an option</div>').insertAfter('[name="specialty"]');
            isValid = false;
        }
       if ($('#subspecialtyGroup').css('display') !== 'none') {
        // Validate subspecialty select
            if ($('#subspecialtyId').val() == '') {
             document.getElementById("reqsubspecialtyId").innerHTML = "*  Please select an Sub specialty.";
                //  $('<div class="text-danger">Please select an option</div>').insertAfter('[name="practitionertype"]');
                isValid = false;
         
            } 
         
        }
        // Validate assistant level select
        if ($('[name="assistent_level"]').val() == '') {
            document.getElementById("reqassistent_level").innerHTML = "*  Please select an Assistent level.";
            isValid = false;
        }

        // Validate practitioner type select
        if ($('[name="specialties[]"]').val() == '') {
            document.getElementById("reqspecialties").innerHTML = "* Please select one or more specialties.";
            isValid = false;
        }
        return isValid;
    }
</script>
<script>
     function emailVerifi() {
            var mail = document.getElementById('emailI').value;


            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('nurse.mail-exist')); ?>",
                data: {
                    "email": mail,
                },
                dataType: 'JSON',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(resp) {
                    if (resp.status == 1) {
                        document.getElementById("reqTxtemailI").innerHTML = "*" + resp.message;
                        //  $('#emailI').val('');
                        $('#nexres').prop('disabled', true);


                    }
                    if (resp.status == 0) {
                        document.getElementById("reqTxtemailI").innerHTML = "";
                        $('#nexres').prop('disabled', false);
                    }
                }
            });

            return false;

        }
</script>
<script>
        function dosignup() {

            event.preventDefault();

            $(".valley").html("");

            $('.submit-btn-120').prop('disabled', true);

            $('.submit-btn-1').show();

            $('.resetpassword').hide();

            var returnValue;

            var firstNameI = document.getElementById("firstNameI").value;
            var lastNameI = document.getElementById("lastNameI").value;
            var preferredI = document.getElementById("preferredI").value;
            
          
            var countryCode = document.getElementById("countryCode").value;

            var contactI = document.getElementById("contactI").value;

            

            var post_codeI = document.getElementById("post_codeI").value;
            var emailI = document.getElementById("emailI").value;
            
            
            var passwordI = document.getElementById("passwordI").value;

            var confirm_passwordI = document.getElementById("confirm_passwordI").value;

         
            returnValue = true;
          if (emailI.trim() == "") {
        
                        document.getElementById("reqTxtemailI").innerHTML = "* Please enter the Store Email address.";
        
                        returnValue = false;
        
                    }
        
                    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        
                    if (emailI.match(mailformat)) {
        
                        returnValue = true;
        
                    } else {
        
                        document.getElementById("reqTxtemailI").innerHTML = "* Please enter the  Email address.";
        
                        returnValue = false;
        
                    }
            if (preferredI.trim() == "") {

                document.getElementById("reqTxtpreferredI").innerHTML = "* Please enter the Your  Preferred  Name.";

                returnValue = false;

            }
            if (firstNameI.trim() == "") {

                document.getElementById("reqTxtfirstNameI").innerHTML = "* Please enter the First Name .";

                returnValue = false;

            }
            if (lastNameI.trim() == "") {

                document.getElementById("reqTxtlastNameI").innerHTML = "* Please enter the Last Name .";

                returnValue = false;

            }
            if (post_codeI.trim() == "") {

                document.getElementById("reqTxtpost_codeI").innerHTML = "* Please enter the Post Code .";

                returnValue = false;

            }
           
             if (countryCode.trim() == "") {
                document.getElementById("reqTxtcountryCode").innerHTML = "*  Select the country code.";
                returnValue = false;
                }
            
            
            if (contactI.trim() == "") {

                document.getElementById("reqTxtcontactI").innerHTML = "* Please enter the Phone Number .";

                returnValue = false;

                }

            

          
            
           
           
            

        if (passwordI.trim() == "") {

                document.getElementById("reqTxtpasswordI").innerHTML = "*  Please enter the PasswordI.";

                returnValue = false;

            }

            if (confirm_passwordI.trim() == "") {

                document.getElementById("reqTxtconfirm_passwordI").innerHTML = "* Please Enter the Confirm password.";

                returnValue = false;

            }

            if (passwordI != confirm_passwordI) {

                document.getElementById("reqTxtconfirm_passwordI").innerHTML = "Password And Confirm password did not match.";

                returnValue = false;

            }

            if (returnValue == false) {

                $('.submit-btn-120').prop('disabled', false);

                $('.submit-btn-1').hide();

                $('.resetpassword').show();

            }



            if (returnValue == true) {

                let formData = new FormData($('#multi-step-form')[0]);



                $.ajax({

                    type: 'POST',

                    url: "<?php echo e(route('nurse.do-nurse-register')); ?>",

                    data: formData,

                    dataType: 'JSON',

                    processData: false,

                    contentType: false,

                    cache: false,

                    headers: {

                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

                    },

                    beforeSend: function() {

                        $('.submit-btn-120').prop('disabled', true);

                        $('.submit-btn-1').show();

                        $('.resetpassword').hide();



                    },

                    success: function(resp) {



                        if (resp.status == 1) {

                            $('.submit-btn-120').prop('disabled', false);

                            $('.submit-btn-1').hide();

                            $('.resetpassword').show();

                            $('#multi-step-form')[0].reset();

                        

                                Swal.fire({

                                    icon: 'success',

                                    title: 'Registered Successfully',

                                    text: resp.message,

                                }).then(function() {

                                    window.location = resp.url;

                                });


                        
                        } else {

                            $('.submit-btn-120').prop('disabled', false);

                            $('.submit-btn-1').hide();

                            $('.resetpassword').show();

                            Swal.fire({

                                'icon': 'error',

                                'title': 'Error',

                                'text': resp.message

                            });

                            printErrorMsg(resp.validation);

                        }

                    }

                });

                return false;

            }



        }



        function printErrorMsg(msg) {

            $(".print-error-msg").find("ul").html('');



            $(".print-error-msg").css('display', 'block');

            $(".error").remove();

            $.each(msg, function(key, value) {

                $('#district_id').after('<span class="error">' + value + '</span>');

                $(".print-error-msg").find("ul").append('<li>' + value + '</li>');





            });

        }
    </script>



    <script type="text/javascript">
        $(document).ready(function(){
          $('#yes').click(function(){
            $('.yes_btn').addClass('activ1').siblings().removeClass('activ');       
          });
          $('#no').click(function(){
            $('.no_btn').addClass('activ').siblings().removeClass('activ1');       
          });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nurse.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/vitalqzv/nextjs.webwiders.in/mediqa/resources/views/nurse/nurseRegister.blade.php ENDPATH**/ ?>