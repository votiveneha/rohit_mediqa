<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="back_arrow" onclick="history.back()" title="Go Back">
        <i class="fa fa-arrow-left"></i>
    </div>
    <div class="card bg-light-info shadow-none position-relative overflow-hidden">
        <div class="card-body px-4 py-3">
            <div class="row align-items-center">
                <div class="col-9">
                    <h4 class="fw-semibold mb-8"> View Profile </h4>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a class="text-muted " href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">View Profile</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-3">
                    <div class="text-center mb-n5">
                        <img src="<?php echo e(asset('admin/dist/images/breadcrumb/ChatBc.png')); ?>" alt=""
                            class="img-fluid" style="height: 125px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card w-100  overflow-hidden">
        <div class="card-body p-3 px-md-4 pb-0">
            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Personal Detail <?php if($profileData->status == 1): ?>
                <span class="badge bg-success ms-2">Unblock</span>
                <?php else: ?>
                <span class="badge bg-danger ms-2">Blocked</span>
                <?php endif; ?>
            </h3>
        </div>
        <div class="card-body p-3 px-md-4">
            <div class="row align-items-center justify-content-between">
                <div class="col ">
                    <div class="d-flex align-items-md-center gap-4 flex-column flex-md-row">
                        <div class="d-flex  mb-2 ">
                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center "
                                style="width: 144px; height: 144px;" ;>
                                <div class="border rounded-circle border-3 border-white d-flex align-items-center justify-content-center  overflow-hidden btn-light commingsoon"
                                    data-bs-toggle="modal" data-bs-target="#commingsoonModel"
                                    style="width: 140px; height: 140px;" ;>
                                    <img src="<?php echo e(asset($profileData->profile_img)); ?>" alt=""
                                        class="w-100 h-100">
                                </div>

                            </div>
                        </div>
                        <div class="w-100">
                            <div class="d-flex justify-content-between">
                                <h5 class="fs-5 mb-2 fw-bolder"> <?php echo e(ucwords($profileData->name)." ".ucwords($profileData->lastname)); ?> </h5>
                                <h5 class="fs-5 mb-2 fw-bolder"> </h5>

                            </div>
                            <?php if($profileData->phone != ''): ?>
                            <p class="d-flex text-dark align-items-center gap-2 mb-1">
                                <i class="ti ti-phone fs-4"></i><strong> +<?php echo e($profileData->country_code); ?>

                                    <?php echo e($profileData->phone); ?>

                                </strong>
                            </p>
                            <?php endif; ?>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <p class="mb-0 d-flex text-dark align-items-center gap-2">
                                    <i class="ti ti-mail fs-4"></i><?php echo e($profileData->email); ?>

                                </p>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->post_code != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Post Code : <?php echo e($profileData->post_code); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->preferred != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Preferred Name : <?php echo e($profileData->preferred); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-">
                                <?php if($profileData->store_url != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Store URL: <?php echo e($profileData->store_url); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>


                        </div>
                    </div>
                </div>



            </div>

        </div>
    </div>
    <div class="card list-drpdwns-set">
        <div class="card-body">
            <?php echo $__env->make("admin.layouts.nurse_view_tabs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="tab-content border mt-2">
                <div class="tab-pane p-3 active show" id="navpill-1" role="tabpanel">
                    <div class=" w-100  overflow-hidden">
                        <div class="card-body p-3 px-md-4 pb-0">
                            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Registrations and Licences</h3>
                        </div>
                        <div class="card-body p-3 px-md-4">
                            <div class="col-md-12">
                                <div class="row">
                                    <?php if(!empty($licensesData)): ?>
                                        <?php if($licensesData->ahpra_registration_status == "RN" || $licensesData->ahpra_registration_status == "RM" || $licensesData->ahpra_registration_status == "RN_RM" || $licensesData->ahpra_registration_status == "NP"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="ahpra_details">
                                                <h5>
                                                    
                                                    <?php if($licensesData->ahpra_registration_status == "RN"): ?>
                                                        Registered Nurse (RN)
                                                    <?php endif; ?>
                                                    <?php if($licensesData->ahpra_registration_status == "RM"): ?>
                                                        Registered Midwife (RM)
                                                    <?php endif; ?>
                                                    <?php if($licensesData->ahpra_registration_status == "RN_RM"): ?>
                                                        Registered Nurse and Midwife (RN/RM)
                                                    <?php endif; ?>
                                                    <?php if($licensesData->ahpra_registration_status == "NP"): ?>
                                                        Nurse Practitioner (NP) (as endorsed under RN)
                                                    <?php endif; ?>
                                                </h5>
                                                <div class="row">
                                                    <div class="col-md-12 registration_no">
                                                        <strong>AHPRA Registration Number:</strong>
                                                        <span><?php echo e($licensesData->aphra_registration_no); ?></span>
                                                    </div>
                                                </div><br>    
                                                <div class="ahpra_lookup_details">
                                                    <h5>Ahpra Lookup Details</h5>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <strong>Division:</strong>
                                                            <span>
                                                                <?php if($licensesData->api_verify == "1"): ?>
                                                                    <?php echo e($licensesData->register_division); ?>

                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_division == "RN"): ?>
                                                                    Registered Nurse (RN)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_division == "EN"): ?>
                                                                    Enrolled Nurse (EN)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_division == "RM"): ?>
                                                                    Registered Midwife (RM)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_division == "RN+RM"): ?>
                                                                    Registered Nurse and Midwife (RN+RM)
                                                                <?php endif; ?>
                                                            </span> 
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Endorsements:</strong>
                                                            <span>
                                                                <?php if($licensesData->api_verify == "1"): ?>
                                                                    <?php echo e($licensesData->register_endorsements); ?>

                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_endorsements == "NP"): ?>
                                                                    Nurse Practitioner (NP)
                                                                <?php endif; ?>
                                                                
                                                                <?php if($licensesData->register_endorsements == "RIPRN"): ?>
                                                                    Scheduled Medicines – Midwife
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_endorsements == "NP+Midwife"): ?>
                                                                    Scheduled Medicines – RN (Rural and Isolated Practice)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_endorsements == "IVs"): ?>
                                                                    Both NP and Endorsed Midwife
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_endorsements == "meds"): ?>
                                                                    IV Endorsed - Enrolled Nurse (IVs)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_endorsements == "none"): ?>
                                                                    Medication Endorsed - Enrolled Nurse (meds)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->register_endorsements == "MidwifeMeds"): ?>
                                                                    No endorsed status
                                                                <?php endif; ?>
                                                            </span> 
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Registration Type:</strong>
                                                            <span>
                                                                <?php echo e($licensesData->register_reg_type); ?>

                                                            </span> 
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Registration Status:</strong>
                                                            <span>
                                                                <?php if($licensesData->register_reg_status == "Not registered"): ?>
                                                                    Not currently registered
                                                                <?php else: ?>
                                                                    <?php echo e($licensesData->register_reg_status); ?>    
                                                                <?php endif; ?>
                                                            </span> 
                                                        </div>
                                                        <?php if($licensesData->register_notations != NULL): ?>
                                                        <div class="col-md-6">
                                                            <strong>Notations:</strong><br>
                                                            <?php if($licensesData->api_verify == "1"): ?>
                                                                <span><?php echo e($licensesData->register_notations); ?></span>
                                                            <?php endif; ?>
                                                            <?php
                                                                $notations = json_decode($licensesData->register_notations);
                                                                //print_r($notations);
                                                                $i = 1;
                                                            ?>
                                                            <?php if(!empty($notations)): ?>
                                                            <?php $__currentLoopData = $notations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="notations">
                                                                
                                                                <?php if($nt == "Other"): ?>
                                                                <?php echo e($i); ?>. Other Notation- <?php echo e($licensesData->register_other_notation_reason); ?>    
                                                                <?php else: ?>
                                                                <?php echo e($i); ?>. <?php echo e($nt); ?>

                                                                <?php endif; ?>
                                                            </div> 

                                                            <?php
                                                                $i++;
                                                            ?>                                                               
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if($licensesData->register_conditions != NULL): ?>
                                                        <div class="col-md-6">
                                                            <strong>Conditions:</strong><br>
                                                            <?php if($licensesData->api_verify == "1"): ?>
                                                                <span><?php echo e($licensesData->register_conditions); ?></span>
                                                            <?php endif; ?>
                                                            <?php
                                                                $conditions = json_decode($licensesData->register_conditions);
                                                                //print_r($notations);
                                                                $i = 1;
                                                            ?>
                                                            <?php if(!empty($conditions)): ?>
                                                            <?php $__currentLoopData = $conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cond): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="notations">
                                                               <?php echo e($i); ?>. <?php echo e($cond); ?>

                                                            </div> 

                                                            <?php
                                                                $i++;
                                                            ?>                                                               
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </div>
                                                        <?php endif; ?>
                                                        <div class="col-md-6">
                                                            <strong>Expiry:</strong><br>
                                                            <span><?php echo e($licensesData->register_expiry); ?></span>
                                                             
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Principal Place of Practice:</strong><br>
                                                            <span>
                                                                <?php if($licensesData->api_verify == "1"): ?>
                                                                    <?php echo e($licensesData->register_conditions); ?>

                                                                <?php else: ?>
                                                                    <?php echo e($licensesData->register_principal_place); ?>

                                                                <?php endif; ?>
                                                            </span>
                                                            
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Other Places of Practice:</strong><br>
                                                            <span>
                                                                <?php
                                                                    $other_place = json_decode($licensesData->register_other_place);
                                                                    //print_r($notations);
                                                                    $i = 1;
                                                                ?>
                                                                <?php if(!empty($other_place)): ?>
                                                                <?php $__currentLoopData = $other_place; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <div class="other_place">
                                                                    <?php echo e($i); ?>. <?php echo e($place); ?>

                                                                </div> 

                                                                <?php
                                                                    $i++;
                                                                ?>                                                               
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </span>
                                                             
                                                        </div>
                                                        <?php if($licensesData->register_upload_evidence != NULL): ?>
                                                        <div class="col-md-6">
                                                            <strong>Evidence</strong>
                                                            <?php
                                                                $evidence = json_decode($licensesData->register_upload_evidence);
                                                                $i = 1;
                                                            ?>
                                                            <ul>
                                                            <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                
                                                                <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                                    <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                                </a>
                                                            </li>    
                                                            <?php $i++; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                        <?php endif; ?>
                                                    </div><br>
                                                    <div class="form-group">
                                                    <label>
                                                        <input type="checkbox" id="isAdmin" <?php if($licensesData->ahpra_reverify == "1"): ?> checked <?php endif; ?>>&nbsp;&nbsp;Override the cooldown and force the Re-verify
                                                    </label>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($licensesData->ahpra_registration_status == "Graduate_RN" || $licensesData->ahpra_registration_status == "Graduate_RM" || $licensesData->ahpra_registration_status == "Student_Nurse" || $licensesData->ahpra_registration_status == "Student_Midwife"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="graduate_details">
                                                <h5>
                                                    
                                                    <?php if($licensesData->ahpra_registration_status == "Graduate_RN"): ?>
                                                        Graduate Nurse – Transitional Authorisation
                                                    <?php endif; ?>
                                                    <?php if($licensesData->ahpra_registration_status == "Graduate_RM"): ?>
                                                        Graduate Midwife – Transitional Authorisation
                                                    <?php endif; ?>
                                                    <?php if($licensesData->ahpra_registration_status == "Student_Nurse"): ?>
                                                        Student Nurse – AHPRA-registered (NMBA-approved course)
                                                    <?php endif; ?>
                                                    <?php if($licensesData->ahpra_registration_status == "Student_Midwife"): ?>
                                                        Student Midwife – AHPRA-registered (NMBA-approved course)
                                                    <?php endif; ?>
                                                </h5>
                                                <div class="row">
                                                    <div class="col-md-12 registration_no">
                                                        <strong>AHPRA Registration Number:</strong>
                                                        <span><?php echo e($licensesData->graduate_student_reg_no); ?></span>
                                                    </div>
                                                </div><br>    
                                                <div class="ahpra_lookup_details">
                                                    <h5>Ahpra Lookup Details</h5>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <strong>Division:</strong>
                                                            <span>
                                                                
                                                                <?php if($licensesData->graduate_division == "RN"): ?>
                                                                    Registered Nurse (RN)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_division == "EN"): ?>
                                                                    Enrolled Nurse (EN)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_division == "RM"): ?>
                                                                    Registered Midwife (RM)
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_division == "RN+RM"): ?>
                                                                    Registered Nurse and Midwife (RN+RM)
                                                                <?php endif; ?>
                                                            </span> 
                                                        </div>
                                                        
                                                        <div class="col-md-6">
                                                            <strong>Registration Type:</strong>
                                                            <span>
                                                                <?php if($licensesData->graduate_reg_type == "general"): ?>
                                                                    General
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_type == "limited"): ?>
                                                                    Limited
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_type == "provisional"): ?>
                                                                    Provisional
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_type == "student_nurse"): ?>
                                                                    Student Nurse
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_type == "student_midwife"): ?>
                                                                    Student Midwife
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_type == "non_practising"): ?>
                                                                    Non-practising
                                                                <?php endif; ?>
                                                            </span> 
                                                        </div>
                                                        <div class="col-md-6">
                                                            <strong>Registration Status:</strong>
                                                            <span>
                                                                <?php if($licensesData->graduate_reg_status == "current"): ?>
                                                                    Current
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_status == "suspended"): ?>
                                                                    Suspended
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_status == "cancelled"): ?>
                                                                    Cancelled
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_status == "inactive"): ?>
                                                                    Inactive
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_status == "ineligible"): ?>
                                                                    Ineligible
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_status == "lapsed"): ?>
                                                                    Lapsed
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_status == "expired"): ?>
                                                                    Expired
                                                                <?php endif; ?>
                                                                <?php if($licensesData->graduate_reg_status == "not_registered"): ?>
                                                                    Not currently registered
                                                                <?php endif; ?>
                                                            </span> 
                                                        </div>
                                                        <?php if($licensesData->graduation_date != NULL): ?>
                                                        <div class="col-md-6">
                                                            <strong>Graduation Date:</strong>
                                                            <span><?php echo e($licensesData->graduation_date); ?></span>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if($licensesData->graduation_upload_evidence != NULL): ?>
                                                        <div class="col-md-6">
                                                            <strong>Evidence</strong>
                                                            <?php
                                                                $evidence = json_decode($licensesData->graduation_upload_evidence);
                                                                $i = 1;
                                                            ?>
                                                            <ul>
                                                            <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                
                                                                <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                                    <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                                </a>
                                                            </li>    
                                                            <?php $i++; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <?php endif; ?>    
                                        <?php if($licensesData->ahpra_registration_status == "Overseas"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="graduate_details">
                                                <h5>Overseas-Qualified Nurses and Midwives not currently registered with AHPRA</h5>
                                                <div class="col-md-12 mt-3">
                                                    
                                                    <span>
                                                        <?php
                                                            $overseas = json_decode($licensesData->overseas_qualified_specify);
                                                            //print_r($notations);
                                                            $i = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $overseas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $over_seas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="other_place">
                                                            <?php echo e($i); ?>. 
                                                            <?php if($over_seas == "recently_migrated"): ?>
                                                                I recently migrated to Australia and am preparing to apply for AHPRA
                                                            <?php endif; ?>
                                                            <?php if($over_seas == "aphra_app"): ?>
                                                                I have submitted my AHPRA application and am awaiting outcome
                                                            <?php endif; ?>
                                                            <?php if($over_seas == "aphra_assessment"): ?>
                                                                I am preparing documentation for AHPRA assessment
                                                            <?php endif; ?>
                                                            <?php if($over_seas == "aphra_bridge"): ?>
                                                                I am studying to meet AHPRA bridging/re-entry requirements
                                                            <?php endif; ?>
                                                            <?php if($over_seas == "other"): ?>
                                                                Other:- <?php echo e($licensesData->other_overseas_qualified); ?>

                                                            <?php endif; ?>
                                                        </div> 

                                                        <?php
                                                            $i++;
                                                        ?>                                                               
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </span>
                                                </div><br>        
                                                <?php if($licensesData->overseas_upload_evidence != NULL): ?>
                                                    <div class="col-md-6">
                                                        <strong>Evidence</strong>
                                                        <?php
                                                            $evidence = json_decode($licensesData->overseas_upload_evidence);
                                                            $i = 1;
                                                        ?>
                                                        <ul>
                                                        <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            
                                                            <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                                <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                            </a>
                                                        </li>    
                                                        <?php $i++; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                    <?php endif; ?>    
                                            </div>    
                                        </div>
                                        <?php endif; ?>
                                        <?php if($licensesData->ahpra_registration_status == "Not_Registered"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="graduate_details">
                                                <h5>Not currently registered with AHPRA</h5>
                                                <?php
                                                    $not_registered = json_decode($licensesData->not_currently_registered_reason);
                                                    $i = 1;
                                                ?>
                                                <ul>
                                                <?php $__currentLoopData = $not_registered; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($i); ?>. 
                                                        <?php if($nt == "education_related"): ?>
                                                            Education-Related Reasons
                                                        <?php endif; ?>
                                                        <?php if($nt == "returning_practice"): ?>
                                                            Returning to Practice
                                                        <?php endif; ?>
                                                        <?php if($nt == "personal_career"): ?>
                                                            Personal or Career Reasons
                                                        <?php endif; ?>
                                                        <?php if($nt == "other"): ?>
                                                            Other:- <?php echo e($licensesData->other_not_registered_reason); ?>

                                                        <?php endif; ?>
                                                    </li>
                                                    <?php
                                                        $i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>   
                                        <?php if($licensesData->education_related_reason != "null"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="graduate_details">
                                                <h5>Education-Related Reasons:</h5>
                                                <?php
                                                    $education_related_reason = json_decode($licensesData->education_related_reason);
                                                    $i = 1;
                                                ?>
                                                <ul>
                                                <?php $__currentLoopData = $education_related_reason; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($i); ?>. 
                                                        <?php if($nt == "startProgram"): ?>
                                                            I am about to begin an AHPRA-approved nursing/midwifery program
                                                        <?php endif; ?>
                                                        <?php if($nt == "waitingAssessment"): ?>
                                                            I have completed my studies and am waiting for AHPRA assessment
                                                        <?php endif; ?>
                                                        <?php if($nt == "studiedOutside"): ?>
                                                            I completed my studies outside Australia and have not applied yet
                                                        <?php endif; ?>
                                                        <?php if($nt == "didNotComplete"): ?>
                                                            I did not complete my nursing/midwifery qualification
                                                        <?php endif; ?>
                                                    </li>
                                                    <?php
                                                        $i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>    
                                        <?php endif; ?> 
                                        <?php if($licensesData->returning_practice != "null"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="graduate_details">
                                                <h5>Returning to Practice:</h5>
                                                <?php
                                                    $returning_practice = json_decode($licensesData->returning_practice);
                                                    $i = 1;
                                                ?>
                                                <ul>
                                                <?php $__currentLoopData = $returning_practice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($i); ?>. 
                                                        <?php if($nt == "lapsed"): ?>
                                                            I previously held registration but let it lapse
                                                        <?php endif; ?>
                                                        <?php if($nt == "reentryProgram"): ?>
                                                            I am currently completing a re-entry to practice program
                                                        <?php endif; ?>
                                                        <?php if($nt == "waitingPlacement"): ?>
                                                            I am waiting for supervised practice placement approval
                                                        <?php endif; ?>
                                                        <?php if($nt == "nonPractisingToGeneral"): ?>
                                                            I am transitioning from non-practising to general registration
                                                        <?php endif; ?>
                                                    </li>
                                                    <?php
                                                        $i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>    
                                        <?php endif; ?> 
                                        <?php if($licensesData->personal_career != "null"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="graduate_details">
                                                <h5>Personal or Career Reasons:</h5>
                                                <?php
                                                    $personal_career = json_decode($licensesData->personal_career);
                                                    $i = 1;
                                                ?>
                                                <ul>
                                                <?php $__currentLoopData = $personal_career; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($i); ?>. 
                                                        <?php if($nt == "maternityLeave"): ?>
                                                            On maternity or extended personal leave
                                                        <?php endif; ?>
                                                        <?php if($nt == "careerBreak"): ?>
                                                            Taking a career break
                                                        <?php endif; ?>
                                                        <?php if($nt == "nonClinical"): ?>
                                                            Working in a non-clinical healthcare role (e.g. admin, education)
                                                        <?php endif; ?>
                                                        <?php if($nt == "overseasPractice"): ?>
                                                            Practising in another country
                                                        <?php endif; ?>
                                                        <?php if($nt == "nonHealth"): ?>
                                                            Working in a non-healthcare sector
                                                        <?php endif; ?>
                                                        <?php if($nt == "notReturning"): ?>
                                                            I do not intend to practise again
                                                        <?php endif; ?>
                                                    </li>
                                                    <?php
                                                        $i++;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                               
                                            </div>
                                        </div>    
                                        <?php endif; ?> 
                                        <?php if($licensesData->personal_career != "null"): ?>
                                        <div class="col-md-12 mt-3">
                                            <div class="graduate_details">
                                                <h5>Other Reason</h5>
                                                <?php
                                                    echo $other_not_registered_reason = $licensesData->other_not_registered_reason;
                                                    
                                                ?>
                                                
                                            </div>
                                        </div>    
                                        <?php endif; ?> 
                                         <?php if($licensesData->not_registered_evidence_file != NULL): ?>
                                            <div class="col-md-6 mt-3">
                                                <h5>Evidence</h5>
                                                <?php
                                                    $evidence = json_decode($licensesData->not_registered_evidence_file);
                                                    $i = 1;
                                                ?>
                                                <ul>
                                                <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    
                                                    <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                        <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                    </a>
                                                </li>    
                                                <?php $i++; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                    
                                    
                                    <div class="col-md-12 mt-3">
                                        <div class="ndis_details">
                                            <h5>NDIS</h5>
                                            <div class="ndis_detail_block">
                                                <strong>NDIS status:</strong>
                                                <span>
                                                    <?php
                                                        $ndis_status = $licensesData->ndis_status;    
                                                    ?>
                                                    <?php if($ndis_status == "registered"): ?>
                                                        I am an NDIS-registered provider
                                                    <?php endif; ?>
                                                    <?php if($ndis_status == "compliant"): ?>
                                                        I am NDIS-compliant, but not registered
                                                    <?php endif; ?>
                                                    <?php if($ndis_status == "not_compliant"): ?>
                                                        I am not NDIS-compliant
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                            <?php if($ndis_status == "registered"): ?>
                                            <div class="ndis_registered_provider mt-1">
                                                <div class="ndis_number">
                                                    <strong>NDIS Registration Number:</strong>
                                                    <span><?php echo e($licensesData->ndis_registration_no); ?></span>
                                                </div>
                                                <div class="ndis_evidence mt-1">
                                                    <strong>Evidence:</strong>
                                                    <?php
                                                        $i = 1;
                                                        $evidence = json_decode($licensesData->ndis_registration_evidence);
                                                    ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            
                                                            <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                                <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                            </a>
                                                        </li>    
                                                        <?php $i++; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>        
                                    <div class="col-md-12 mt-3">
                                        <?php if($licensesData->medical_provider_no != NULL): ?>
                                        <div class="ndis_registered_provider mt-1">
                                            <h5>Medicare Provider</h5>
                                            <div class="ndis_number">
                                                <strong>Medicare Provider Number:</strong>
                                                <span><?php echo e($licensesData->medical_provider_no); ?></span>
                                            </div>
                                            <div class="ndis_evidence mt-1">
                                                <strong>Evidence:</strong>
                                                <?php
                                                    $i = 1;
                                                    $evidence = json_decode($licensesData->medical_upload_evidence);
                                                ?>
                                                <ul>
                                                    <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        
                                                        <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                            <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                        </a>
                                                    </li>    
                                                    <?php $i++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-12 mt-3">
                                        <?php if($licensesData->pbs_type != NULL): ?>
                                        <div class="ndis_registered_provider mt-1">
                                            <h5>PBS Prescriber</h5>
                                            <div class="ndis_number">
                                                <strong>Prescriber Type:</strong>
                                                <?php
                                                    $pbs_type = $licensesData->pbs_type;
                                                ?>
                                                <span>
                                                    <?php if($pbs_type == "nurse_prac"): ?>
                                                        Nurse Practitioner (NP)
                                                    <?php endif; ?>
                                                    <?php if($pbs_type == "eligible_midwife"): ?>
                                                        Eligible Midwife
                                                    <?php endif; ?>
                                                    <?php if($pbs_type == "endorsed_midwife"): ?>
                                                        Endorsed Midwife – Scheduled Medicines
                                                    <?php endif; ?>
                                                    <?php if($pbs_type == "prescriber_under"): ?>
                                                        Prescriber under Collaborative Arrangement (under a doctor for PBS access)
                                                    <?php endif; ?>
                                                    <?php if($pbs_type == "other_nursing"): ?>
                                                        Other (nursing/midwifery-specific role)
                                                    <?php endif; ?>
                                                    
                                                </span>
                                            </div>
                                            <?php if($licensesData->pbs_type == "other_nursing"): ?>
                                            <div class="ndis_number mt-1">
                                                <strong>Other (nursing/midwifery-specific role):</strong>
                                                <span><?php echo e($licensesData->pbs_other_nursing); ?></span>
                                            </div>
                                            <?php endif; ?>
                                            <div class="ndis_number mt-1">
                                                <strong>Prescriber Number:</strong>
                                                <span><?php echo e($licensesData->prescribe_no); ?></span>
                                            </div>
                                            <div class="ndis_evidence mt-1">
                                                <strong>Evidence:</strong>
                                                <?php
                                                    $i = 1;
                                                    $evidence = json_decode($licensesData->prescribe_evidence);
                                                ?>
                                                <ul>
                                                    <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        
                                                        <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                            <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                        </a>
                                                    </li>    
                                                    <?php $i++; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-12 mt-3">
                                        <?php if($licensesData->authorizing_body_program != NULL): ?>
                                        <div class="ndis_registered_provider mt-1">
                                            <h5>Immunisation Provider</h5>
                                            <?php
                                                $immunization_state_data = (array)json_decode($licensesData->immunization_state);
                                                $authorizing_body = (array)json_decode($licensesData->authorizing_body_program);
                                            ?>
                                            <div class="row">
                                            <?php $__currentLoopData = $immunization_state_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imstate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="state_data col-md-6">
                                                <div class="state_data_block">
                                                    <strong>State of Authorisation:</strong>
                                                    <?php
                                                        if($imstate == "NSW"){
                                                        $state_name = "New South Wales (NSW)";
                                                        }
                                                        if($imstate == "VIC"){
                                                        $state_name = "Victoria (VIC)";
                                                        }
                                                        if($imstate == "QLD"){
                                                        $state_name = "Queensland (QLD)";
                                                        }
                                                        if($imstate == "WA"){
                                                        $state_name = "Western Australia (WA)";
                                                        }
                                                        if($imstate == "SA"){
                                                        $state_name = "South Australia (SA)";
                                                        }
                                                        if($imstate == "TAS"){
                                                        $state_name = "Tasmania (TAS)";
                                                        }
                                                        if($imstate == "ACT"){
                                                        $state_name = "Australian Capital Territory (ACT)";
                                                        }
                                                        if($imstate == "NT"){
                                                        $state_name = "Northern Territory (NT)";
                                                        }
                                                    ?>
                                                    <span><?php echo e($state_name); ?></span>
                                                </div>
                                                <div class="state_data_block mt-1">
                                                    <strong>Authorising Body or Program:</strong>
                                                    <span><?php if(isset($authorizing_body[$imstate])): ?><?php echo e($imstate); ?><?php endif; ?></span>
                                                </div>
                                                <div class="state_data_block mt-1">
                                                    <strong>Date Authorised:</strong>
                                                    <span><?php if(isset($authorizing_body[$imstate])): ?><?php echo e($authorizing_body[$imstate]->date_authorized); ?><?php endif; ?></span>
                                                </div>
                                                <div class="ndis_evidence mt-1">
                                                    <strong>Evidence:</strong>
                                                    <?php if(isset($authorizing_body[$imstate]) && $authorizing_body[$imstate]->evidence != NULL): ?>
                                                    <?php
                                                        $i = 1;
                                                        $evidence = json_decode($authorizing_body[$imstate]->evidence);
                                                    ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            
                                                            <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                                <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                            </a>
                                                        </li>    
                                                        <?php $i++; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-12 mt-3">
                                        <?php if($licensesData->radiation_licence_type != "null"): ?>
                                        <div class="ndis_registered_provider mt-1">
                                            <h5>Radiation Use Licence</h5>
                                            <?php
                               
                                            if(!empty($licensesData) && $licensesData->radiation_licence_type != NULL){
                                                $radiation_licence_type = json_decode($licensesData->radiation_licence_type);
                                                $radiation_licenses_no = (array)json_decode($licensesData->radiation_licenses_no);
                                                
                                            }else{
                                                $radiation_licence_type = array(); 
                                            }

                                                                                       

                                            $licenses_array = [
                                                'medical_r' => 'Medical Radiation Use Licence – Restricted',
                                                'diagnostic_radiography_restricted' => 'Diagnostic Radiography - Restricted',
                                                'limited_xray_operator' => 'Limited X-ray Operator',
                                                'mobile_xray_operator' => 'Mobile X-ray Operator',
                                                'neonatal_xray_operator' => 'Neonatal X-ray Operator',
                                                'fluoroscopy_assistive_restricted' => 'Fluoroscopy – Assistive Use (Restricted)',
                                                'bone_mineral_restricted' => 'Bone Mineral Densitometry (DEXA) – Restricted',
                                                'ct_mri_support_non_operator' => 'CT or MRI Support Role (Non-operator)',
                                                'radiation_use_trainee_student' => 'Radiation Use Licence – Trainee / Student',
                                                'radiation_use_educational' => 'Radiation Use Licence – Educational Purposes',
                                                'diagnostic_ultrasound' => 'Diagnostic Ultrasound',
                                                'other' => 'Other'
                                            ];


                                            ?>  
                                            <?php if(!empty($radiation_licence_type)): ?>
                                            <div class="row">
                                            <?php $__currentLoopData = $radiation_licence_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licence_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="state_data col-md-6">
                                                <div class="state_data_block">
                                                    <strong>Licence Type:</strong>
                                                    <?php
                                                        $licence_name = $licenses_array[$licence_type];
                                                    ?>
                                                    <span><?php echo e($licence_name); ?></span>
                                                </div>    
                                                <?php if($licence_type == "other"): ?>
                                                <div class="state_data_block mt-1">
                                                    <strong>Other Licence Type:</strong>
                                                    <span><?php echo e($licensesData->licenses_type_other); ?></span>
                                                </div>    
                                                <?php endif; ?>
                                                <div class="state_data_block mt-1">
                                                    <strong>Licence Number:</strong>
                                                    <span><?php if(!empty($licensesData) && isset($radiation_licenses_no['other'])): ?><?php echo e($radiation_licenses_no['other']->radiation_licenses_no); ?><?php endif; ?></span>
                                                </div> 
                                                
                                                <div class="state_data_block mt-1">
                                                    <strong>State of Issue:</strong>
                                                    <?php if(isset($radiation_licenses_no['other']->state_issue)): ?>
                                                    <?php
                                                        
                                                        $state_issue = $radiation_licenses_no['other']->state_issue;
                                                        //print_r($state_issue);
                                                        $i = 1;
                                                    ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $state_issue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($i); ?>. 
                                                                <?php if($st == "NSW"): ?>
                                                                    New South Wales (NSW)
                                                                <?php endif; ?>
                                                                <?php if($st == "VIC"): ?>
                                                                    Victoria (VIC)
                                                                <?php endif; ?>
                                                                <?php if($st == "QLD"): ?>
                                                                    Queensland (QLD)
                                                                <?php endif; ?>
                                                                <?php if($st == "WA"): ?>
                                                                    Western Australia (WA)
                                                                <?php endif; ?>
                                                                <?php if($st == "SA"): ?>
                                                                    South Australia (SA)
                                                                <?php endif; ?>
                                                                <?php if($st == "TAS"): ?>
                                                                    Tasmania (TAS)
                                                                <?php endif; ?>
                                                                <?php if($st == "ACT"): ?>
                                                                    Australian Capital Territory (ACT)
                                                                <?php endif; ?>
                                                                <?php if($st == "NT"): ?>
                                                                    Northern Territory (NT)
                                                                <?php endif; ?>
                                                            </li>
                                                            <?php
                                                                $i++;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                    <?php endif; ?>
                                                </div> 
                                                <div class="state_data_block mt-1">
                                                    <strong>Licensing Body:</strong>
                                                    <?php if(isset($radiation_licenses_no['other']->licence_body)): ?>
                                                    <?php
                                                        $licensing_body = $radiation_licenses_no['other']->licence_body;
                                                        //print_r($state_issue);
                                                        $i = 1;
                                                    ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $licensing_body; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l_body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><?php echo e($i); ?>. 
                                                                <?php if($l_body == "environment_protection"): ?>
                                                                    EPA NSW – Environment Protection Authority
                                                                <?php endif; ?>
                                                                <?php if($l_body == "radiation_safety"): ?>
                                                                    Department of Health – Radiation Safety
                                                                <?php endif; ?>
                                                                <?php if($l_body == "radiation_health"): ?>
                                                                    Queensland Health – Radiation Health
                                                                <?php endif; ?>
                                                                <?php if($l_body == "radiation_protection"): ?>
                                                                    SA EPA – Radiation Protection
                                                                <?php endif; ?>
                                                                <?php if($l_body == "radiological_council"): ?>
                                                                    Radiological Council of WA
                                                                <?php endif; ?>
                                                                <?php if($l_body == "health_department"): ?>
                                                                    Radiation Protection Unit – Department of Health
                                                                <?php endif; ?>
                                                                <?php if($l_body == "health_nt"): ?>
                                                                    Department of Health NT Radiation Safety
                                                                <?php endif; ?>
                                                                <?php if($l_body == "health_protection"): ?>
                                                                    Health Protection Service
                                                                <?php endif; ?>
                                                            </li>
                                                            <?php
                                                                $i++;
                                                            ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                    <?php endif; ?>
                                                </div> 
                                                <div class="state_data_block">
                                                    <strong>Issue Date:</strong>
                                                    <span><?php if(!empty($licensesData) && isset($radiation_licenses_no['other'])): ?><?php echo e($radiation_licenses_no['other']->radiation_issue_date); ?><?php endif; ?></span>
                                                </div> 
                                                <div class="state_data_block mt-1">
                                                    <strong>Expiry Date:</strong>
                                                    <span><?php if(!empty($licensesData) && isset($radiation_licenses_no['other'])): ?><?php echo e($radiation_licenses_no['other']->radiation_expiry_date); ?><?php endif; ?></span>
                                                </div> 
                                                <div class="ndis_evidence mt-1">
                                                    <strong>Evidence:</strong>
                                                    <?php if(isset($radiation_licenses_no['other']) && $radiation_licenses_no['other']->evidence != NULL): ?>
                                                    <?php
                                                        $i = 1;
                                                        $evidence = (array)json_decode($radiation_licenses_no['other']->evidence);
                                                        
                                                    ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $evidence; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            
                                                            <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($evi); ?>" target="_blank">
                                                                <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo e($evi); ?>

                                                            </a>
                                                        </li>    
                                                        <?php $i++; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                    <?php endif; ?>
                                                </div>
                                            </div>    
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    $('#isAdmin').click(function(){
        if ($('#isAdmin').prop('checked')) {
            $.ajax({
                url: "<?php echo e(route('admin.ahpra_reverify')); ?>",  // or Laravel route
                type: 'POST',                  // or 'GET'
                data: {
                    ahpra_reverify: '1',
                    user_id: '<?php echo e($licensesData->user_id); ?>',
                    _token:"<?php echo e(csrf_token()); ?>"
                },
                success: function(response) {
                    console.log('Success:', response);
                    // You can update the DOM here
                    
                }
            });
        } else {
            $.ajax({
                url: "<?php echo e(route('admin.ahpra_reverify')); ?>",  // or Laravel route
                type: 'POST',                  // or 'GET'
                data: {
                    ahpra_reverify: '0',
                    user_id: '<?php echo e($licensesData->user_id); ?>',
                    _token:"<?php echo e(csrf_token()); ?>"
                },
                success: function(response) {
                    console.log('Success:', response);
                    // You can update the DOM here
                    
                }
            });
        }
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mediqa/public_html/resources/views/admin/registration_licenses_view.blade.php ENDPATH**/ ?>