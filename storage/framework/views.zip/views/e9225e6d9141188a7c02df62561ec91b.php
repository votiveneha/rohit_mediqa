<?php $__env->startSection('content'); ?>
 <main class="main">
<div class="bg-homepage4"></div>
      <section class="section-box mb-70">
        <div class="banner-hero hero-1 banner-homepage5">
          <div class="banner-inner">
            <div class="row align-items-center">
              <div class="col-xl-7 col-lg-12">
                <div class="block-banner">
                  <h1 class="heading-banner wow animate__animated animate__fadeInUp">Register and<br class="d-none d-lg-block">create your profile</h1>
                  <div class="banner-description mt-20 wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                    Refine your search by specialty, location, time, and assignment duration. Apply directly for the ideal shift or permanent position Connect with facilities and agencies.</div>
                  <div class="mt-30"> <a class="btn btn-default mr-15" href="<?php echo e(route('nurse.nurse-register')); ?>">Register Now for find your job!</a>
                  </div>
                  
                </div>
              </div>
              <div class="col-xl-5 col-lg-12 d-none d-xl-block col-md-6">
                <div class="banner-imgs">
                  <div class="banner-1 shape-1"><img class="img-responsive" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/nurse1.png')); ?>"></div>
                  <div class="banner-2 shape-2"><img class="img-responsive" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/nurse2.png')); ?>"></div>
                  <div class="banner-3 shape-3"><img class="img-responsive" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/nurse3.png')); ?>"></div>
                  <div class="banner-4 shape-3"><img class="img-responsive" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/nurse4.png')); ?>"></div>
                  <div class="banner-5 shape-2"><img class="img-responsive" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/nurse5.png')); ?>"></div>
                  <div class="banner-6 shape-1"><img class="img-responsive" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/nurse6.png')); ?>"></div>
                </div>
              </div>
            </div>
            <div class="box-search-2">
              <div class="block-banner">
                <div class="form-find mt-40 wow animate__animated animate__fadeIn" data-wow-delay=".2s">
                  <form>
                    <input class="form-input input-keysearch mr-10" type="text" placeholder="Your keyword... ">
                    <select class="form-input mr-10 select-active">
                      <option value="">Location</option>
                      <option value="AX">option 1</option>
                      <option value="AF">option 2</option>
                    
                    </select>
                    <a class="btn btn-default btn-find font-sm" href="<?php echo e(route('nurse.home')); ?>">Search</a>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>



        <section class="section-box mt-70 mb-40">
        <div class="container">
          <div class="text-center">
            <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">How It Works</h2>
            <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">Just via some simple steps, you will find your ideal candidates you’r looking for!</p>
          </div>
          <div class="mt-70"> 
            <div class="row"> 
              <div class="col-lg-4">
                <div class="box-step step-1">
                  <h1 class="number-element">1</h1>
                  <h4 class="mb-10">Create an account</h4>
                  <p class="font-lg color-text-paragraph-2">Lorem ipsum dolor sit amet,<br class="d-none d-lg-block">consectetur adipisicing elit, sed do </p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="box-step step-2">
                  <h1 class="number-element">2</h1>
                  <h4 class="mb-10">Search for Jobs</h4>
                  <p class="font-lg color-text-paragraph-2">Lorem ipsum dolor sit amet,<br class="d-none d-lg-block">consectetur adipisicing elit, sed do </p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="box-step">
                  <h1 class="number-element">3</h1>
                  <h4 class="mb-10">Save & Apply</h4>
                  <p class="font-lg color-text-paragraph-2">Lorem ipsum dolor sit amet,<br class="d-none d-lg-block">consectetur adipisicing elit, sed do </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>



       <section class="section-box overflow-visible mt-80 mb-100">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-sm-12">
              <div class="box-image-job">
                <!-- <img class="img-job-1" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/page/homepage1/img-chart.png')); ?>"> -->
                <img class="img-job-2" alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/page/homepage1/img-chart.png')); ?>">
                <figure class="wow animate__ animate__fadeIn animated" style="visibility: visible; animation-name: fadeIn;"><img alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/img1.png')); ?>"></figure>
              </div>
            </div>
            <div class="col-lg-6 col-sm-12">
              <div class="content-job-inner"><span class="color-text-mutted text-32">Find Jobs.</span>
                <h2 class="text-52 wow animate__ animate__fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">Find The One That’s <span class="color-brand-2">Right</span> For You</h2>
                <div class="mt-20 pr-50 text-md-lh28 wow animate__ animate__fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec justo a quam varius maximus. Maecenas sodales tortor quis tincidunt commodo. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
                <div class="mt-20">
                  <div class="wow animate__ animate__fadeInUp animated" style="visibility: visible; animation-name: fadeInUp;"><a class="btn btn-default" href="#">Search Jobs</a></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>



       <section class="section-box overflow-visible mt-50 mb-0 bg-cat2">
        <div class="container">
          <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="text-center">
                <h1 class="color-brand-2"><span class="count">25</span><span> K+</span></h1>
                <h5>Completed Cases</h5>
                <p class="font-sm color-text-paragraph mt-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec justo a quam varius maximus. Maecenas sodales tortor quis tincidunt commodo.</p>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="text-center">
                <h1 class="color-brand-2"><span class="count">17</span><span> +</span></h1>
                <h5>Our Office</h5>
                <p class="font-sm color-text-paragraph mt-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec justo a quam varius maximus. Maecenas sodales tortor quis tincidunt commodo.</p>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="text-center">
                <h1 class="color-brand-2"><span class="count">86</span><span> +</span></h1>
                <h5>Skilled People</h5>
                <p class="font-sm color-text-paragraph mt-10">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec justo a quam varius maximus. Maecenas sodales tortor quis tincidunt commodo.</p>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="text-center">
                <h1 class="color-brand-2"><span class="count">28</span><span> +</span></h1>
                <h5>Happy Clients</h5>
                <p class="font-sm color-text-paragraph mt-10">We always provide people a <br class="d-none d-lg-block">complete solution upon focused of <br class="d-none d-lg-block">any business</p>
              </div>
            </div>
          </div>
        </div>
      </section>

  



      <section class="section-box mt-50">
        <div class="section-box wow animate__animated animate__fadeIn">
          <div class="container">

            <div class="text-center">
              <h2 class="section-title mb-10 wow animate__animated animate__fadeInUp">Latest Jobs Post</h2>
              <p class="font-lg color-text-paragraph-2 wow animate__animated animate__fadeInUp">Explore the different types of available jobs to apply<br class="d-none d-lg-block">discover which is right for you.</p>
            </div>



            <div class="row mt-50">
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                      <div class="card-grid-2 grid-bd-16 hover-up">
                        <div class="card-grid-2-image"><span class="lbl-hot bg-green"><span>Anaesthetics</span></span>
                          <div class="image-box">
                            <figure><img src="<?php echo e(asset('nurse/assets/imgs/page/homepage2/img1.png')); ?>" alt="jobBox"></figure>
                          </div>
                        </div>
                        <div class="card-block-info">
                          <h5><a href='#'>Anaesthetics</a></h5>
                          <div class="mt-5"><span class="card-location mr-15">New York, US</span><span class="card-time">7:00 AM - 5:30 PM</span></div>
                          <div class="card-2-bottom mt-20">
                            <div class="row">
                              <div class="col-xl-7 col-md-7 mb-2">
                                <a class='btn btn-tags-sm mr-5' href='#'>Start Application</a>

                              </div>
                              <div class="col-xl-5 col-md-5 text-lg-end"><span class="card-text-price">$90 - $120</span><span class="text-muted">/Hour</span></div>
                            </div>
                          </div>
                          <p class="font-sm color-text-paragraph mt-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae architecto eveniet, dolor quo repellendus pariatur</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                      <div class="card-grid-2 grid-bd-16 hover-up">
                        <div class="card-grid-2-image"><span class="lbl-hot"><span>Full time</span></span>
                          <div class="image-box">
                            <figure><img src="<?php echo e(asset('nurse/assets/imgs/page/homepage2/img2.png')); ?>" alt="jobBox"></figure>
                          </div>
                        </div>
                        <div class="card-block-info">
                          <h5><a href='#'>Gen Med/Gen Surg Ward</a></h5>
                          <div class="mt-5"><span class="card-location mr-15">New York, US</span><span class="card-time">7:00 AM - 5:30 PM</span></div>
                          <div class="card-2-bottom mt-20">
                            <div class="row">
                              <div class="col-xl-7 col-md-7 mb-2">
                                <a class='btn btn-tags-sm mr-5' href='#'>Start Application</a>

                              </div>
                              <div class="col-xl-5 col-md-5 text-lg-end"><span class="card-text-price">$80 - $150</span><span class="text-muted">/Hour</span></div>
                            </div>
                          </div>
                          <p class="font-sm color-text-paragraph mt-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae architecto eveniet, dolor quo repellendus pariatur</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                      <div class="card-grid-2 grid-bd-16 hover-up">
                        <div class="card-grid-2-image"><span class="lbl-hot"><span>Full time</span></span>
                          <div class="image-box">
                            <figure><img src="<?php echo e(asset('nurse/assets/imgs/page/homepage2/img3.png')); ?>" alt="jobBox"></figure>
                          </div>
                        </div>
                        <div class="card-block-info">
                          <h5><a href='#'>Anaesthetics</a></h5>
                          <div class="mt-5"><span class="card-location mr-15">New York, US</span><span class="card-time">7:00 AM - 5:30 PM</span></div>
                          <div class="card-2-bottom mt-20">
                            <div class="row">
                             <div class="col-xl-7 col-md-7 mb-2">
                                <a class='btn btn-tags-sm mr-5' href='#'>Start Application</a>

                              </div>
                              <div class="col-xl-5 col-md-5 text-lg-end"><span class="card-text-price">$120 - $150</span><span class="text-muted">/Hour</span></div>
                            </div>
                          </div>
                          <p class="font-sm color-text-paragraph mt-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae architecto eveniet, dolor quo repellendus pariatur</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                      <div class="card-grid-2 grid-bd-16 hover-up">
                        <div class="card-grid-2-image"><span class="lbl-hot"><span>Full time</span></span>
                          <div class="image-box">
                            <figure><img src="<?php echo e(asset('nurse/assets/imgs/page/homepage2/img4.png')); ?>" alt="jobBox"></figure>
                          </div>
                        </div>
                        <div class="card-block-info">
                          <h5><a href='#'>Gen Med/Gen Surg Ward</a></h5>
                          <div class="mt-5"><span class="card-location mr-15">New York, US</span><span class="card-time">7:00 AM - 5:30 PM</span></div>
                          <div class="card-2-bottom mt-20">
                            <div class="row">
                              <div class="col-xl-7 col-md-7 mb-2">
                                <a class='btn btn-tags-sm mr-5' href='#'>Start Application</a>

                              </div>
                              <div class="col-xl-5 col-md-5 text-lg-end"><span class="card-text-price">$80 - $150</span><span class="text-muted">/Hour</span></div>
                            </div>
                          </div>
                          <p class="font-sm color-text-paragraph mt-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae architecto eveniet, dolor quo repellendus pariatur</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                      <div class="card-grid-2 grid-bd-16 hover-up">
                        <div class="card-grid-2-image"><span class="lbl-hot"><span>Full time</span></span>
                          <div class="image-box">
                            <figure><img src="<?php echo e(asset('nurse/assets/imgs/page/homepage2/img5.png')); ?>" alt="jobBox"></figure>
                          </div>
                        </div>
                        <div class="card-block-info">
                          <h5><a href='#'>Anaesthetics</a></h5>
                          <div class="mt-5"><span class="card-location mr-15">New York, US</span><span class="card-time">7:00 AM - 5:30 PM</span></div>
                          <div class="card-2-bottom mt-20">
                            <div class="row">
                              <div class="col-xl-7 col-md-7 mb-2">
                                <a class='btn btn-tags-sm mr-5' href='#'>Start Application</a>

                              </div>
                              <div class="col-xl-5 col-md-5 text-lg-end"><span class="card-text-price">$80 - $150</span><span class="text-muted">/Hour</span></div>
                            </div>
                          </div>
                          <p class="font-sm color-text-paragraph mt-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae architecto eveniet, dolor quo repellendus pariatur</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                      <div class="card-grid-2 grid-bd-16 hover-up">
                        <div class="card-grid-2-image"><span class="lbl-hot"><span>Full time</span></span>
                          <div class="image-box">
                            <figure><img src="<?php echo e(asset('nurse/assets/imgs/page/homepage2/img6.png')); ?>" alt="jobBox"></figure>
                          </div>
                        </div>
                        <div class="card-block-info">
                          <h5><a href='#'>Gen Med/Gen Surg Ward</a></h5>
                         <div class="mt-5"><span class="card-location mr-15">New York, US</span><span class="card-time">7:00 AM - 5:30 PM</span></div>
                          <div class="card-2-bottom mt-20">
                            <div class="row">
                              <div class="col-xl-7 col-md-7 mb-2">
                                <a class='btn btn-tags-sm mr-5' href='#'>Start Application</a>

                              </div>
                              <div class="col-xl-5 col-md-5 text-lg-end"><span class="card-text-price">$80 - $150</span><span class="text-muted">/Hour</span></div>
                            </div>
                          </div>
                          <p class="font-sm color-text-paragraph mt-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae architecto eveniet, dolor quo repellendus pariatur</p>
                        </div>
                      </div>
                    </div>
                  </div>




          </div>
        </div>
      </section>
  




   <section class="section-box bg-15 pt-50 pb-50 mt-80">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 text-center"><img class="img-job-search mt-20" src="<?php echo e(asset('nurse/assets/imgs/page/homepage3/img-job-search.png')); ?>" alt="jobBox"></div>
            <div class="col-xl-5 col-lg-6 col-md-12 col-sm-12">
              <h2 class="mb-40 text-white">Job search for people passionate about startup</h2>
              <div class="box-checkbox mb-30">
                <h6 class="text-white">Create an account</h6>
                <p class="text-white font-sm opacity_6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec justo a quam varius maximus. Maecenas sodales tortor quis tincidunt commodo.</p>
              </div>
              <div class="box-checkbox mb-30">
                <h6 class="text-white">Search for Jobs</h6>
                <p class="text-white font-sm opacity_6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec justo a quam varius maximus. Maecenas sodales tortor quis tincidunt commodo.</p>
              </div>
              <div class="box-checkbox mb-30">
                <h6 class="text-white">Save &amp; Apply</h6>
                <p class="text-white font-sm opacity_6">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nec justo a quam varius maximus. Maecenas sodales tortor quis tincidunt commodo.</p>
              </div>
            </div>
          </div>
        </div>
      </section>


     


      <section class="section-box mt-50 mb-0">
        <div class="container">
          <h2 class="text-center mb-15 wow animate__animated animate__fadeInUp">Our Happy Customer</h2>
          <div class="font-lg color-text-paragraph-2 text-center wow animate__animated animate__fadeInUp">When it comes to choosing the right web hosting provider, we know how easy it<br class="d-none d-lg-block"> is to get overwhelmed with the number.</div>
          <div class="row mt-50">
            <div class="box-swiper">
              <div class="swiper-container swiper-group-3 swiper">
                <div class="swiper-wrapper pb-70 pt-5">
                  <div class="swiper-slide">
                    <div class="card-grid-6 hover-up">
                      <div class="card-text-desc mt-10">
                        <p class="font-md color-text-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vitae neque metus. Vivamus consectetur ultricies commodo. Pellentesque at nisl sit amet neque finibus egestas ut at magna. Cras tincidunt tortor sed eros aliquam eleifend.</p>
                      </div>
                      <div class="card-image">
                        <div class="image">
                          <figure><img alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/page/about/user1.png')); ?>"></figure>
                        </div>
                        <div class="card-profile">
                          <h6>Mark Adair</h6><span>Nurse</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="card-grid-6 hover-up">
                      <div class="card-text-desc mt-10">
                        <p class="font-md color-text-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vitae neque metus. Vivamus consectetur ultricies commodo. Pellentesque at nisl sit amet neque finibus egestas ut at magna. Cras tincidunt tortor sed eros aliquam eleifend.</p>
                      </div>
                      <div class="card-image">
                        <div class="image">
                          <figure><img alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/page/about/user2.png')); ?>"></figure>
                        </div>
                        <div class="card-profile">
                          <h6>Mark Adair</h6><span>Hospital</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="card-grid-6 hover-up">
                      <div class="card-text-desc mt-10">
                        <p class="font-md color-text-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vitae neque metus. Vivamus consectetur ultricies commodo. Pellentesque at nisl sit amet neque finibus egestas ut at magna. Cras tincidunt tortor sed eros aliquam eleifend.</p>
                      </div>
                      <div class="card-image">
                        <div class="image">
                          <figure><img alt="jobBox" src="<?php echo e(asset('nurse/assets/imgs/page/about/user3.png')); ?>"></figure>
                        </div>
                        <div class="card-profile">
                          <h6>Mark Adair</h6><span>Recruiter</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-pagination swiper-pagination3"></div>
              </div>
            </div>
          </div>
        </div>
      </section>




      <script src="<?php echo e(asset('nurse/assets/js/plugins/counterup.js')); ?>"></script>
    </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('nurse.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/vitalqzv/nextjs.webwiders.in/mediqa/resources/views/nurse/home.blade.php ENDPATH**/ ?>