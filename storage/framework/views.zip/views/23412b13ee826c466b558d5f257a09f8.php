  <?php if(!Auth::guard('nurse_middle')->check()): ?>
  <header class="header sticky-bar">
    <div class="container">
      <div class="main-header">
        <div class="header-left">
          <div class="header-logo"><a class='d-flex' href='<?php echo e(route("home_main")); ?>'><img alt="jobBox" src="<?php echo e(asset(env('LOGO_PATH'))); ?>"></a></div>
        </div>
        <div class="header-nav">
          <nav class="nav-main-menu">
            <ul class="main-menu">

              <!--  <li class="">
                  <a class='menu-link hover-up' href='<?php echo e(route("nurse.home")); ?>'>Home</a>
                </li> -->

              <li class="has-children">

                <a class='menu-link hover-up' href='<?php echo e(route("nurse.home")); ?>'>Nurses</a>
                <ul class="sub-menu">
                  <?php $nurseTypeData =nurse_Type_header();?>
                  <?php if($nurseTypeData): ?>
                  <?php $__currentLoopData = $nurseTypeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li> <a href='<?php echo e(route("nurse.login")); ?>' class="active"> <?php echo e($items->name); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  <li> <a href='<?php echo e(route("nurse.login")); ?>'>JOBS by specialties <i class="fa-solid fa-caret-right fs-6"></i></a>
                    <ul class="sub-menu">
                      <?php $nurseTypeSpecialData =practitioner_type_header();?>
                      <?php if($nurseTypeSpecialData): ?>
                      <?php $__currentLoopData = $nurseTypeSpecialData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $itemSps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li> <a href='<?php echo e(route("nurse.login")); ?>'><?php echo e($itemSps->name); ?></a></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>

                    </ul>
                  </li>

                </ul>
              </li>

              <li class="">
                <a class='<?php echo e(request()->is('medical-facilities') ?"active":""); ?> hover-up' href='<?php echo e(route("medical-facilities.medical_facilities_home_main")); ?>'>Healthcare Facilities</a>
              </li>
              <li class="">
                <a class='<?php echo e(request()->is('agencies') ?"active":""); ?> hover-up' href='<?php echo e(route("agencies.agencies_home_main")); ?>'>Agencies</a>
              </li>
              <li class="">

                <a class='<?php echo e(request()->is('nurseCareHome') ?"active":""); ?> hover-up' href='<?php echo e(route("nurseCareHome")); ?>'>Nurse Care at Home
</a>
              </li>
              <li class="">

                <a class='<?php echo e(request()->is('contact') ?"active":""); ?> hover-up' href='<?php echo e(route("contact")); ?>'>Contact</a>
              </li>
            </ul>
          </nav>
          <div class="burger-icon burger-icon-white">
            <span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span>
          </div>
        </div>
        <div class="header-right">
          <div class="block-signin d-flex align-items-center gap-3 justify-content-end">
            <!-- <a class='text-link-bd-btom hover-up' href='nurse_signup.php'>Become a Nurse</a> -->
            <a class='btn btn-default btn-shadow hover-up' href='<?php echo e(route("nurse.login")); ?>'>Log in</a>
            <a class='btn btn-default btn-shadow hover-up' href='<?php echo e(route("nurse.nurse-register")); ?>'>Sign up</a>
            <!-- <?php if(request()->is('') || request()->is('/')): ?>
            <a class='btn btn-default btn-shadow hover-up' href='<?php echo e(route("nurse.home")); ?>'>Sign in</a>
            <?php elseif(request()->is('nurse')): ?>
            <a class='btn btn-default btn-shadow hover-up' href='<?php echo e(route("nurse.login")); ?>'>Sign in</a>
            <?php endif; ?> -->

          </div>
        </div>
      </div>
    </div>
  </header>

  <?php else: ?>
  <header class="header sticky-bar  border-bottom">
    <div class="container">
      <div class="main-header">
        <div class="header-left">
          <div class="header-logo"><a class='d-flex' href='<?php echo e(route("home_main")); ?>'><img alt="jobBox" src="<?php echo e(asset(env('LOGO_PATH'))); ?>"></a></div>
        </div>
        <div class="header-nav">
          <nav class="nav-main-menu">
            <ul class="main-menu">
              <li class="">
                <a class='menu-link hover-up' href='<?php echo e(route("nurse.dashboard")); ?>'>Find Jobs</a>
              </li>
              <li class="">
                <a class='hover-up' href='<?php echo e(route("nurse.dashboard")); ?>'>My Jobs</a>
              </li>
              <!-- <li class="">
                  <a class='' href='recruiter_signup.php'>Agencies Sign Up</a>
                </li> -->
              <li class="">
                <a class=' hover-up' href='<?php echo e(route("nurse.dashboard")); ?>'>Community</a>
              </li>

              <li>

                <a class="<?php echo e(request()->is('nurse/my-profile') ?"active":""); ?>  hover-up " href='<?php echo e(route("nurse.my-profile")); ?>?page=my_profile'>Profile</a>

              </li>

            </ul>
          </nav>
          <div class="burger-icon burger-icon-white">
            <span class="burger-icon-top"></span><span class="burger-icon-mid"></span><span class="burger-icon-bottom"></span>
          </div>
        </div>
        <div class="header-right">
          <div class="block-signin d-flex align-items-center gap-3 justify-content-end">
            <!-- <a class='text-link-bd-btom hover-up' href='nurse_signup.php'>Become a Nurse</a> -->
            <div class="dropdown d-inline-block">
              <a class="btn btn-notify" id="dropdownNotify" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
                <i class="fa-regular fa-bell"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-light dropdown-menu-end" aria-labelledby="dropdownNotify">
                <li><a class="dropdown-item active" href="#">0 notifications</a></li>
                <li><a class="dropdown-item" href="#">0 messages</a></li>
                <li><a class="dropdown-item" href="#">0 replies</a></li>
              </ul>
            </div>


            <div class="member-login d-flex align-items-center gap-1">
             
              <div class="info-member">
                <div class="dropdown">

                  <a class="font-xs color-text-paragraph-2 icon-down" data-bs-toggle="dropdown" style="cursor:pointer;"> <img alt="<?php echo e(Auth::guard('nurse_middle')->user()->name); ?>" src="<?php echo e(asset( Auth::guard('nurse_middle')->user()->profile_img)); ?>"><strong class="color-brand-1" ><?php echo e(Auth::guard('nurse_middle')->user()->name); ?></strong></a>
                  <ul class="dropdown-menu dropdown-menu-light dropdown-menu-end" aria-labelledby="dropdownProfisle">
                    <!-- <li> --><a href='<?php echo e(route("nurse.my-profile")); ?>?page=my_profile' class="dropdown-item">Profile</a><!-- </li> -->
                    <!--  <li> --><a class="dropdown-item change_password_link" style="cursor: pointer;">change Password</a><!-- </li> -->
                    <!-- <li> --><a href='<?php echo e(route("nurse.logout")); ?>' class="dropdown-item">Logout</a><!-- </li> -->
                  </ul>
                </div>
              </div>
            </div>
            <!-- <a class='btn btn-default btn-shadow hover-up' href='#'>Sign in</a> -->
          </div>
        </div>
      </div>
    </div>
  </header>
  
  <?php endif; ?>
  <?php /**PATH /home4/phpserver2/public_html/mediqa/resources/views/nurse/layouts/header.blade.php ENDPATH**/ ?>