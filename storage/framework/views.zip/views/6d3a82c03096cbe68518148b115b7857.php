<?php $__env->startSection('content'); ?>
     <style>
        .dropdown-list {
            background-color: white;
            color:white;
            max-height: 200px; /* Adjust the height as needed */
            overflow-y: auto; /* Add scrollbar if content overflows */
            padding: 0;
            list-style: none;
            margin: 0;
            border: 1px solid #f1f1f1;
            border-radius: 4px;
            background-color: #ffffff;
            padding: 11px 15px 13px 15px;
            width: 100%;
            color: #A0ABB8;

        }
        .dropdown-item-custom {
            padding: 10px; /* Add padding to list items */
            color: black;
            text-decoration: none;
            display: block;
        }
        .dropdown-item-custom:hover {
            background-color: white; /* Change the hover background color */
        }
    </style>
    <div class="container-fluid">
        <div class="card bg-light-info shadow-none position-relative overflow-hidden">
            <div class="card-body px-4 py-3">
                <div class="row align-items-center">
                    <div class="col-9">
                        <h4 class="fw-semibold mb-8"> View Profile </h4>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a class="text-muted " href="index.html">Dashboard</a></li>
                                <li class="breadcrumb-item" aria-current="page">View Profile</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-3">
                        <div class="text-center mb-n5">
                            <img src="<?php echo e(asset('admin/dist/images/breadcrumb/ChatBc.png')); ?>" alt=""
                                class="img-fluid" style="height: 125px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Personal Detail <?php if($profileData->status == 1): ?>
                        <span class="badge bg-success ms-2">Unblock</span>
                    <?php else: ?>
                        <span class="badge bg-danger ms-2">Blocked</span>
                    <?php endif; ?>
                </h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col ">
                        <div class="d-flex align-items-md-center gap-4 flex-column flex-md-row">
                            <div class="d-flex  mb-2 ">
                                <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center "
                                    style="width: 144px; height: 144px;" ;>
                                    <div class="border rounded-circle border-3 border-white d-flex align-items-center justify-content-center  overflow-hidden btn-light commingsoon"
                                        data-bs-toggle="modal" data-bs-target="#commingsoonModel"
                                        style="width: 140px; height: 140px;" ;>
                                        <img src="<?php echo e(asset($profileData->profile_img)); ?>" alt=""
                                            class="w-100 h-100">
                                    </div>

                                </div>
                            </div>
                            <div class="w-100">
                                <div class="d-flex justify-content-between"> 
                                    <h5 class="fs-5 mb-2 fw-bolder"> <?php echo e(ucwords($profileData->name)." ".ucwords($profileData->lastname)); ?> </h5>
                                    <h5 class="fs-5 mb-2 fw-bolder"> </h5>

                                </div>
                                <?php if($profileData->phone != ''): ?>
                                    <p class="d-flex text-dark align-items-center gap-2 mb-1">
                                        <i class="ti ti-phone fs-4"></i><strong> +<?php echo e($profileData->country_code); ?>

                                            <?php echo e($profileData->phone); ?>

                                        </strong>
                                    </p>
                                <?php endif; ?>
                                <div class="d-md-flex align-items-center gap-3 mb-2">
                                    <p class="mb-0 d-flex text-dark align-items-center gap-2">
                                        <i class="ti ti-mail fs-4"></i><?php echo e($profileData->email); ?>

                                    </p>

                                </div>
                                <div class="d-md-flex align-items-center gap-3 mb-2">
                                    <?php if($profileData->post_code != ''): ?>
                                        <p class="fs-3 mb-0 fw-bolder">Post Code : <?php echo e($profileData->post_code); ?></p>
                                    <?php endif; ?>
                                    <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                                </div>
                                <div class="d-md-flex align-items-center gap-3 mb-2">
                                    <?php if($profileData->preferred != ''): ?>
                                        <p class="fs-3 mb-0 fw-bolder">Preferred Name : <?php echo e($profileData->preferred); ?></p>
                                    <?php endif; ?>
                                    <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                                </div>
                                <div class="d-md-flex align-items-center gap-3 mb-">
                                    <?php if($profileData->store_url != ''): ?>
                                        <p class="fs-3 mb-0 fw-bolder">Store URL: <?php echo e($profileData->store_url); ?></p>
                                    <?php endif; ?>
                                    <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                                </div>


                            </div>
                        </div>
                    </div>



                </div>

            </div>
        </div>
        <div class="card list-drpdwns-set">
            <div class="card-body">
                <ul class="nav nav-pills nav-fill mt-4 tabs-feat" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link active" data-bs-toggle="tab" href="#navpill-1" role="tab"
                            aria-selected="true">
                            <span>Basic Details</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-2" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Professional Information</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-3" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Education and Certifications</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-4" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Experience</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-4.1" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>References</span>
                        </a>
                    </li>
                    
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-5" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Mandatory Training</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-6" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Vaccinations</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-7" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Work Clearances</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-8" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Professional Memberships</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-9" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Interview and References</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-10" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Personal Preferences</span>
                        </a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a class="nav-link" data-bs-toggle="tab" href="#navpill-11" role="tab" aria-selected="false"
                            tabindex="-1">
                            <span>Find Work Preferences</span>
                        </a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content border mt-2">
                    <div class="tab-pane p-3 active show" id="navpill-1" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Basic Details</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                        <div class="row">
                                        <?php if($profileData->date_of_birth && $profileData->gender && $profileData->state && $profileData->city
                                        && $profileData->personal_website && $profileData->home_address && $profileData->emergency_conact_numeber): ?>    
                                            <?php if($profileData->date_of_birth): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    
                                                    <strong>Date of Birth : </strong>
                                                    <span><?php echo e(\Carbon\Carbon::parse($profileData->date_of_birth)->format('d/m/Y')); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if($profileData->gender): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                <!-- specialty_name_by_id -->
                                                    <strong>Gender: </strong><span><?php echo e($profileData->gender); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            
                    
                    
                                            
                                            
                                            <?php if($profileData->state): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> State  : </strong> <span><?php echo e(state_name($profileData->state)); ?></span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($profileData->city): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> City   : </strong> <span><?php echo e($profileData->city); ?></span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($profileData->personal_website): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Personal website   : </strong> <span><?php echo e($profileData->personal_website); ?></span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($profileData->home_address): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Home Address   : </strong> <span><?php echo e($profileData->home_address); ?></span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center  mt-3">Emergency Contact Information : </h4>
                                            <?php if($profileData->emergency_conact_numeber): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Mobile No  :</strong> <span>
                                                             +<?php echo e($profileData->emegency_country_code); ?><?php echo e(" "); ?>

                                                             <?php echo e($profileData->emergency_conact_numeber); ?>

                                                        </span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($profileData->emergergency_contact_email): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Email  :</strong> <span>
                                                             <?php echo e($profileData->emergergency_contact_email); ?>

                                                        </span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                    
                                            
                                            <?php else: ?>
                                            <div class="col-md-12">
                                                <div class="text-center text-danger fs-5">No data found</div>
                                            </div>
                                            
                                            <?php endif; ?>
                                        </div>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-2" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Professional Information
                                    </h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">

                                        <?php if($profileData->nurseType && $profileData->specialties): ?>
                                            <div class="row">
                                                
                                                <?php if($profileData->nurseType != 'null'): ?>
                                                <?php $nurseType=json_decode($profileData->nurseType); ?>
                                                <?php if(is_array($nurseType)): ?>
                                                    <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong> Profession : </strong>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $nurseType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <li><span class="dropdown-item-custom"><?php echo e(specialty_name_by_id_NEW($ubspecialty)); ?> , </span></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No specialties available</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                <?php endif; ?>                                                
                                                <?php if($profileData->nurseType != 'null'): ?>
                                                    <?php
                                                        $nurseType = json_decode($profileData->nurseType);

                                                        // Ensure $nurseType is an array
                                                        $nurseType = is_array($nurseType) ? $nurseType : [];
                                                        $nursepra = [];
                                                    
                                                    ?>

                                                    <?php $__currentLoopData = $nurseType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                           
                                                            $specialtyName = specialty_name_by_id_NEW($ubspecialty);
                                                           
                                                            $normalizedSpecialty = strtolower(str_replace('_', ' ', $specialtyName));

                                                            // Define strings to compare
                                                            $string1 = 'entry level nursing';
                                                            $string2 = 'registered nurses';
                                                            $string3 = 'advanced practitioner';

                                                            // Extract words from normalized specialty
                                                            $words = explode(' ', $normalizedSpecialty);
                                                            $firstWord = isset($words[0]) ? strtolower($words[0]) : '';
                                                            $secondWord = isset($words[1]) ? strtolower($words[1]) : '';
                                                            $firstTwoWords = $firstWord . ' ' . $secondWord;

                                                            // Determine the correct nurse sub-job type
                                                            if ($normalizedSpecialty === $string1) {
                                                                $nursesubjobType = json_decode($profileData->entry_level_nursing);
                                            
                                                            } elseif ($firstTwoWords === strtolower($string2)) {
                                                                $nursesubjobType = json_decode($profileData->registered_nurses);
                                                            } elseif ($firstWord === 'advanced') {
                                                                $nursepra = $profileData->advanced_practioner;
                                                                $nursesubjobType = json_decode($profileData->advanced_practioner);
                                                            } else {
                                                                $nursesubjobType = json_decode($profileData->advanced_practioner); // Default case
                                                            }

                                                            // Ensure $nursesubjobType is an array
                                                            $nursesubjobType = is_array($nursesubjobType) ? $nursesubjobType : [];
                                                        ?>

                                                        <div class="col-md-12 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong><?php echo e($specialtyName); ?>:</strong>
                                     
                                                                
                                                                <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $nursesubjobType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                                                    <li><span class="dropdown-item-custom"><?php echo e(specialty_name_by_id_NEW($subtype)); ?> , </span></li>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom"></a></li>
                                                                <?php endif; ?>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                                                                                     
                                                <?php 
                                                // Decode the JSON strings to associative arrays
                                                // $nursepraArray = json_decode($nursepra, true); // `true` to return an associative array
                                                 $nursepraArray = is_string($nursepra) ? json_decode($nursepra, true) : (is_array($nursepra) ? $nursepra : []);

                                                // Ensure $profileData is not null and has the required properties
                                                $profileData = $profileData ?? new stdClass();
                                                // $nurse_prac = isset($profileData->nurse_prac) ? json_decode($profileData->nurse_prac, true) : [];
                                                $nurse_prac = isset($profileData->nurse_prac) 
                                                    ? (is_string($profileData->nurse_prac) 
                                                        ? json_decode($profileData->nurse_prac, true) 
                                                        : (is_array($profileData->nurse_prac) 
                                                            ? $profileData->nurse_prac 
                                                            : []))
                                                    : [];
                                                   ?>
                                               
                                                <?php if(is_array($nursepraArray) && in_array(179, $nursepraArray)): ?>
                                                <div class="col-md-12 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Nurse Practitioner (NP) : </strong> 
                                                        

                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $nurse_prac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(specialty_name_by_id_NEW($subtype)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <?php endif; ?>

                                                <?php if($profileData->specialties != 'null'): ?>
                                                <?php $specialties=json_decode($profileData->specialties); ?>
                                                <?php if(is_array($specialties)): ?>
                                                    <div class="col-md-12 mt-4">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong> Specialties : </strong>
                                                            
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom"></a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                                <?php endif; ?>

                                                <?php if($profileData->specialties != 'null'): ?>
                                                    <?php
                                                        $specialties = json_decode($profileData->specialties);
                                                    
                                                        // Ensure $nurseType is an array
                                                        $specialties = is_array($specialties) ? $specialties : [];
                                                        $surgical_preoperative        = [];
                                                        $surgical_obstrics_gynacology = [];
                                                        $neonatal_care = [];
                                                        $paedia_surgical_preoperative = [];
                                                        $i= 1;
                                                    ?>
                                         
                                                    <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                        
                                                            $specialtyName = practitioner_type_by_id($ubspecialty);

                                                            $normalizedSpecialty = strtolower(str_replace('_', ' ', $specialtyName));

                                                            // Define strings to compare
                                                            $string1 = 'adults';
                                                            $string2 = 'maternity';
                                                            $string3 = 'paediatrics neonatal';
                                                            $string4 = 'community';

                                                            // Extract words from normalized specialty
                                                            $words = explode(' ', $normalizedSpecialty);
                                                            $firstWord = isset($words[0]) ? strtolower($words[0]) : '';
                                                            $secondWord = isset($words[1]) ? strtolower($words[1]) : '';
                                                            $firstTwoWords = $firstWord . ' ' . $secondWord;

                                                            // Determine the correct nurse sub-job type
                                                            if ($normalizedSpecialty === $string1) {
                                                                $surgical_preoperative = $profileData->adults;
                                                                $specsubType = json_decode($profileData->adults);
                                                            } elseif ($firstWord  === strtolower($string2)) {
                                                                  $surgical_obstrics_gynacology = $profileData->maternity;
                                                                $specsubType = json_decode($profileData->maternity);
                                                            } elseif ($firstTwoWords === strtolower($string3)) {
                                                                $neonatal_care = $profileData->paediatrics_neonatal;
                                                                $paedia_surgical_preoperative = $profileData->paediatrics_neonatal;
                                                                $specsubType = json_decode($profileData->paediatrics_neonatal);
                                                            } elseif ($firstWord === strtolower($string4)) {

                                                               
                                                                $specsubType = json_decode($profileData->community);
                                                            }else {
                                                                $specsubType = json_decode($profileData->community); // Default case
                                                            }

                                                            // Ensure $nursesubjobType is an array
                                                            $specsubType = is_array($specsubType) ? $specsubType : [];
                                                        ?>

                                                        <div class="col-md-12 mt-4" id="cat_<?php echo e($i); ?>">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong><?php echo e($specialtyName); ?>:</strong>
                                     
                                                                
                                                                
                                                                <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $specsubType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom"></a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                            
                                                            </div>
                                                        </div>
                                                        <?php $i++ ;?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php endif; ?>

                                                <?php 
                                               
                                               
                                                $surgicalArray = is_string($surgical_preoperative) ? json_decode($surgical_preoperative, true) : (is_array($surgical_preoperative) ? $surgical_preoperative : []);
                                               
                                                $profileData = $profileData ?? new stdClass();
                                                $sargicaldata = isset($profileData->surgical_preoperative) ? json_decode($profileData->surgical_preoperative, true) : [];
                                                $operating_room = isset($profileData->operating_room) ? json_decode($profileData->operating_room, true) : [];
                                                $operating_room_scout = isset($profileData->operating_room_scout) ? json_decode($profileData->operating_room_scout, true) : [];
                                                 $operating_room_scrub = isset($profileData->operating_room_scrub) ? json_decode($profileData->operating_room_scrub, true) : [];
                                                ?>
                                               
                                                <?php if(is_array($surgicalArray) && in_array(96, $surgicalArray)): ?> 
                                                <div class="col-md-12 mt-3" id="sugical_care">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Surgical Preoperative and Postoperative Care : </strong> 
                                                        

                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $sargicaldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ubspecialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($ubspecialty)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="col-md-12 mt-3" id="Operating_Room">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Operating Room (OR) : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $operating_room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $operating_rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($operating_rooms)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="col-md-12 mt-3" id="paediatric_oR">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Paediatric OR: Scout (Circulating Nurse) : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $operating_room_scout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $operating_room_scouts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($operating_room_scouts)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="col-md-12 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap" id="Technician_Nurse">
                                                        <strong> Paediatric OR: Scrub (Technician Nurse) : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $operating_room_scrub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $operating_room_scrubs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($operating_room_scrubs)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                 <?php endif; ?>

                                                <?php 
                                               
                                                $gynacologyArray = is_string($surgical_obstrics_gynacology) ? json_decode($surgical_obstrics_gynacology, true) : (is_array($surgical_obstrics_gynacology) ? $surgical_obstrics_gynacology : []);
                                                
                                                $profileData = $profileData ?? new stdClass();
                                                $surgical_preoperative = isset($profileData->surgical_obstrics_gynacology) ? json_decode($profileData->surgical_obstrics_gynacology, true) : [];
                                                   ?>
                                               
                                                <?php if(is_array($gynacologyArray) && in_array(233, $gynacologyArray)): ?>
                                                <div class="col-md-12 mt-3" id="Surgical_Obstetrics"> 
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Surgical Obstetrics and Gynecology (OB/GYN) : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $surgical_preoperative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <?php endif; ?>

                                                <?php 
                                                $neonatalcareArray = is_string($neonatal_care) ? json_decode($neonatal_care, true) : (is_array($neonatal_care) ? $neonatal_care : []);
                                                $profileData = $profileData ?? new stdClass();
                                                $neonatal_care = isset($profileData->neonatal_care) ? json_decode($profileData->neonatal_care, true) : [];
                                                   ?>
                                               
                                                <?php if(is_array($neonatalcareArray) && in_array(250, $neonatalcareArray)): ?>
                                                <div class="col-md-12 mt-3" id="Neonatal_Care">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Neonatal Care : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $neonatal_care; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <?php endif; ?>

                                                <?php 
                                                $paediaArray = is_string($paedia_surgical_preoperative) ? json_decode($paedia_surgical_preoperative, true) : (is_array($paedia_surgical_preoperative) ? $paedia_surgical_preoperative : []);
                                                $profileData = $profileData ?? new stdClass();
                                                $paedia_surgical_preoperative = isset($profileData->paedia_surgical_preoperative) ? json_decode($profileData->paedia_surgical_preoperative, true) : [];
                                                $pad_op_room = isset($profileData->pad_op_room) ? json_decode($profileData->pad_op_room, true) : [];
                                                $pad_qr_scout = isset($profileData->pad_qr_scout) ? json_decode($profileData->pad_qr_scout, true) : [];
                                                 $pad_qr_scrub = isset($profileData->pad_qr_scrub) ? json_decode($profileData->pad_qr_scrub, true) : [];
                                                ?>
                                               
                                                <?php if(is_array($paediaArray) && in_array(285, $paediaArray)): ?>
                                                <div class="col-md-12 mt-3" id="Surgical_Preop">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Paediatric Surgical Preop. and Postop. Care : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $paedia_surgical_preoperative; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="col-md-12 mt-3" id="Paediatric_Operating">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Paediatric Operating Room (OR) : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $pad_op_room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                 <div class="col-md-12 mt-3" id="Paediatric_Operating_Scout">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Paediatric OR: Scout (Circulating Nurse) : </strong> 
                                                        
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $pad_qr_scout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div> 

                                                <div class="col-md-12 mt-3"  id="Paediatric_Operating_Scrub">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong> Paediatric OR: Scrub (Technician Nurse) : </strong> 
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $pad_qr_scrub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(practitioner_type_by_id($subtype)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <?php endif; ?>

                                                <?php if($profileData->bio): ?>
                                                <div class="col-md-12 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Professional Bio   : </strong> <span><?php echo e($profileData->bio); ?></span>
                                                    </div>
                                                </div>
                                                <?php endif; ?>

                                                <?php if($profileData->current_employee_status): ?>
                                                <div class="col-md-12 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Current Employee Status   : </strong> <span><?php echo e($profileData->current_employee_status); ?></span>
                                                    </div>
                                                </div>
                                                <?php endif; ?>                                                
                                            </div>
                                            <?php else: ?>
                                            <div class="col-md-12">
                                                <div class="text-center text-danger fs-5">No data found</div>
                                            </div>
                                            
                                            <?php endif; ?>
                                        
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-3" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center "> Education and Certifications 
                                    </h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                        <?php if($educationData && $profileData): ?>
                                            <div class="row">
                                                
                                               <h4  class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Educational Background : </h4>
                                               <?php if($profileData->degree != 'null'): ?>
                                                <?php $degree = json_decode($profileData->degree); 
                                                // print_r($degree);die;
                                                ?>
                                                <div class="col-md-12 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Nurse & Midwife degree: </strong>
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $degree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <li><span class="dropdown-item-custom"><?php echo e(nurse_midwife_degree_by_id($value)); ?> , </span></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom"></a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if(isset($educationData->institution) && $educationData->institution): ?>
                                                <div class="col-md-12 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Institution : </strong>
                                                        <span class=""><?php echo e($educationData->institution); ?></span>                                                  
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if(isset($educationData->graduate_start_date) && $educationData->graduate_start_date): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Graduation Start Date : </strong>
                                                        <span class=""><?php echo e(\Carbon\Carbon::parse($educationData->graduate_start_date)->format('d/m/Y')); ?></span>                                                  
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if(isset($educationData->graduate_end_date) && $educationData->graduate_end_date): ?>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Graduation End Date : </strong>
                                                        <span class=""><?php echo e(\Carbon\Carbon::parse($educationData->graduate_end_date)->format('d/m/Y')); ?></span>                                                  
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if($educationData->professional_certifications != 'null'): ?>
                                                <?php $certifications = json_decode($educationData->professional_certifications); 
                                                ?>
                                                
                                                <div class="col-md-12 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Professional Certifications :</strong>
                                                        <?php
                                                        $certificates = DB::table("professional_certificate")->orderBy("ordering_id", "asc")->get();
                                                        ?>
                                                       
                                                        <ul class="dropdown-list">
                                                            <?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <?php if(in_array($certificate->id,$certifications)): ?>
                                                                    <li><span class="dropdown-item-custom"><?php echo e($certificate->name); ?> , </span></li>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <li><a href="#" class="dropdown-item-custom">No certifications found</a></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <?php endif; ?>

                                                <?php if($educationData->acls_data && $educationData->acls_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->acls_data){
                                                        $acls_data1 = json_decode($educationData->acls_data);
                                                        $a_data_arr = array();
                                                        foreach ($acls_data1 as $a_data) {
                                                            $a_data_arr[] = $a_data->acls_certification_id;
                                                        }
                                                        $a_data_json = json_encode($a_data_arr);
                                                        }else{
                                                        $acls_data1 = "";
                                                        $a_data_json = "";
                                                        
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>ACLS (Advanced Cardiovascular Life Support) :</strong>
                                                            <?php
                                                                $acls_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "6")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $acls_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acls_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($a_data->acls_certification_id ==  $acls_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($acls_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No certifications found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($a_data->acls_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($a_data->acls_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                             <?php if($a_data->acls_upload_certification ): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$a_data->acls_upload_certification )); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a> 
                                                            <?php else: ?>   
                                                            <span class="text-success">View Image</span>
                                                            <?php endif; ?>                                            
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->bls_data && $educationData->bls_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->bls_data){
                                                        $bls_data1 = json_decode($educationData->bls_data);
                                                        $b_data_arr = array();
                                                        foreach ($bls_data1 as $b_data) {
                                                            $b_data_arr[] = $b_data->bls_certification_id;
                                                        }
                                                        $b_data_json = json_encode($b_data_arr);
                                                        }else{
                                                        $bls_data1 = "";
                                                        $b_data_json = "";
                                                        
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>BLS (Basic Life Support) :</strong>
                                                            <?php
                                                                $bls_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "7")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $bls_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bls_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($b_data->bls_certification_id == $bls_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($bls_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No certifications found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($b_data->bls_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($b_data->bls_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($b_data->bls_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$b_data->bls_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a> 
                                                            <?php else: ?>
                                                            <span class="text-success">No Image</span>
                                                            <?php endif; ?>

                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->cpr_data && $educationData->cpr_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->cpr_data){
                                                            $cpr_data1 = json_decode($educationData->cpr_data);
                                                            $c_data_arr = array();
                                                            foreach ($cpr_data1 as $c_data) {
                                                                $c_data_arr[] = $c_data->cpr_certification_id;
                                                            }
                                                            $c_data_json = json_encode($c_data_arr);
                                                            }else{
                                                            $cpr_data1 = "";
                                                            $c_data_json = "";
                                                            }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>CPR (Cardiopulmonary Resuscitation) :</strong>
                                                            <?php
                                                                $cpr_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "8")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $cpr_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpr_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($c_data->cpr_certification_id == $cpr_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($cpr_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($c_data->cpr_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($c_data->cpr_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($c_data->cpr_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$c_data->cpr_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->nrp_data && $educationData->nrp_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->nrp_data){
                                                        $nrp_data1 = json_decode($educationData->nrp_data);
                                                        $n_data_arr = array();
                                                        foreach ($nrp_data1 as $n_data) {
                                                            $n_data_arr[] = $n_data->nrp_certification_id;
                                                        }
                                                        $n_data_json = json_encode($n_data_arr);
                                                        }else{
                                                        $nrp_data1 = "";
                                                        $n_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>NRP (Neonatal Resuscitation Program) :</strong>
                                                            <?php
                                                                $nrp_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "9")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $nrp_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrp_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($n_data->nrp_certification_id == $nrp_data->name ): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($nrp_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($n_data->nrp_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($n_data->nrp_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($n_data->nrp_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$n_data->nrp_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->pals_data && $educationData->pals_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->pals_data){
                                                        $pls_data1 = json_decode($educationData->pals_data);
                                                        $p_data_arr = array();
                                                        foreach ($pls_data1 as $p_data) {
                                                            $p_data_arr[] = $p_data->pls_certification_id;
                                                        }
                                                        $p_data_json = json_encode($p_data_arr);
                                                        }else{
                                                        $pls_data1 = "";
                                                        $p_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>PALS (Pediatric Advanced Life Support) :</strong>
                                                            <?php if($palsData): ?>
                                                            <?php
                                                                $pals_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "10")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $pals_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pals_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($p_data->pls_certification_id == $pals_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($pals_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                            <?php else: ?>
                                                            <ul class="dropdown-list">
                                                               
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                
                                                            </ul>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($p_data->pls_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($p_data->pls_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($p_data->pls_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$p_data->pls_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->rn_data && $educationData->rn_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->rn_data){
                                                        $rn_data1 = json_decode($educationData->rn_data);
                                                        $r_data_arr = array();
                                                        foreach ($rn_data1 as $r_data) {
                                                            $r_data_arr[] = $r_data->rn_certification_id;
                                                        }
                                                        $r_data_json = json_encode($r_data_arr);
                                                        }else{
                                                        $rn_data1 = "";
                                                        $r_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>RN (Registered Nurse) :</strong>
                                                            
                                                            <?php
                                                                $rn_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "11")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $rn_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rn_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($r_data->rn_certification_id == $rn_data->name ): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($rn_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($r_data->rn_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($r_data->rn_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($r_data->rn_certification_id ): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$r_data->rn_upload_certification )); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->np_data && $educationData->np_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->np_data){
                                                        $np_data1 = json_decode($educationData->np_data);
                                                        $n_data_arr = array();
                                                        foreach ($np_data1 as $n_data) {
                                                            $n_data_arr[] = $n_data->np_certification_id;
                                                        }
                                                        $np_data_json = json_encode($n_data_arr);
                                                        }else{
                                                        $np_data1 = "";
                                                        $np_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>NP (Nurse Practioner) / (APRN) Advanced Practice Registered Nurse :</strong>
                                                            
                                                            <?php
                                                                $np_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "12")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $np_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $np_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($n_data->np_certification_id == $np_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($np_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($n_data->np_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($n_data->np_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($rn_file): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$n_data->np_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->cna_data && $educationData->cna_data != 'null'): ?>
                                                    <?php
                                                        if($educationData && $educationData->cna_data){
                                                            $cna_data1 = json_decode($educationData->cna_data);
                                                            $cn_data_arr = array();
                                                            foreach ($cna_data1 as $cn_data) {
                                                                $cn_data_arr[] = $cn_data->cn_certification_id;
                                                            }
                                                            $cna_data_json = json_encode($cn_data_arr);
                                                            }else{
                                                            $cna_data1 = "";
                                                            $cna_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>CNA (Certified Nursing Assistant) / EN (Enrolled Nurse) :</strong>
                                                            
                                                            <?php
                                                                $cna_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "13")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $cna_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cna_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($cn_data->cn_certification_id == $cna_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($cna_data->name); ?> ,</span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($cn_data->np_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($cn_data->np_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($cna_file): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$cn_data->np_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->lpn_data && $educationData->lpn_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->lpn_data){
                                                        $lpn_data1 = json_decode($educationData->lpn_data);
                                                        $lpn_data_arr = array();
                                                        foreach ($lpn_data1 as $lpn_data) {
                                                            $lpn_data_arr[] = $lpn_data->lpn_certification_id;
                                                        }
                                                        $lpn_data_json = json_encode($lpn_data_arr);
                                                        }else{
                                                        $lpn_data1 = "";
                                                        $lpn_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>LPN (Licensed Practical Nurse) / LVN (Licensed Vocational Nurse) :</strong>
                                                            
                                                            <?php
                                                                $lpn_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "14")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $lpn_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpn_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($lpn_data->lpn_certification_id == $lpn_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($lpn_data->name); ?>,</span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($lpn_data->lpn_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($lpn_data->lpn_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($lpn_data->lpn_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$lpn_data->lpn_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->crna_data && $educationData->crna_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->crna_data){
                                                        $crna_data1 = json_decode($educationData->crna_data);
                                                        $crna_data_arr = array();
                                                        foreach ($crna_data1 as $crna_data) {
                                                            $crna_data_arr[] = $crna_data->crna_certification_id;
                                                        }
                                                        $crna_data_json = json_encode($crna_data_arr);
                                                        }else{
                                                        $crna_data1 = "";
                                                        $crna_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>CRNA (Certified Registered Nurse Anesthetist) :</strong>
                                                            
                                                            <?php
                                                                $crna_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "15")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $crna_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crna_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($crna_data->crna_certification_id == $crna_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($crna_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($crna_data->crna_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($crna_data->crna_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($crna_file): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$crna_data->crna_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->cnm_data && $educationData->cnm_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->cnm_data){
                                                        $cnm_data1 = json_decode($educationData->cnm_data);
                                                        $cnm_data_arr = array();
                                                        foreach ($cnm_data1 as $cnm_data) {
                                                            $cnm_data_arr[] = $cnm_data->cnm_certification_id;
                                                        }
                                                        $cnm_data_json = json_encode($cnm_data_arr);
                                                        }else{
                                                        $cnm_data1 = "";
                                                        $cnm_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>CNM (Certified Nurse Midwife) :</strong>
                                                            
                                                            <?php
                                                                $cnm_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "16")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $cnm_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnm_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($cnm_data->cnm_certification_id == $cnm_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($cnm_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($cnm_data->cnm_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($cnm_data->cnm_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($cnm_data->cnm_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$cnm_data->cnm_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->ons_data && $educationData->ons_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->ons_data){
                                                        $ons_data1 = json_decode($educationData->ons_data);
                                                        $ons_data_arr = array();
                                                        foreach ($ons_data1 as $ons_data) {
                                                            $ons_data_arr[] = $ons_data->ons_certification_id;
                                                        }
                                                        $ons_data_json = json_encode($ons_data_arr);
                                                        }else{
                                                        $ons_data1 = "";
                                                        $ons_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>ONS/ONCC (Oncology Nursing Society/Oncology Nursing Certification Corporation) :</strong>
                                                            
                                                            <?php
                                                                $ons_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "17")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $ons_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ons_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($ons_data->ons_certification_id == $ons_data->name ): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($ons_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($ons_data->ons_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($ons_data->ons_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($cnm_file): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$ons_data->ons_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->msw_data && $educationData->msw_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->msw_data){
                                                        $msw_data1 = json_decode($educationData->msw_data);
                                                        $msw_data_arr = array();
                                                        foreach ($msw_data1 as $msw_data) {
                                                            $msw_data_arr[] = $msw_data->msw_certification_id;
                                                        }
                                                        $msw_data_json = json_encode($msw_data_arr);
                                                        }else{
                                                        $msw_data1 = "";
                                                        $msw_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>MSW/AiM (Maternity Support Worker/Assistant in Midwifery ) / Midwife Assistant :</strong>
                                                            
                                                            <?php
                                                                $msw_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "18")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $msw_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msw_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($msw_data->msw_certification_id == $msw_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($msw_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($msw_data->msw_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($msw_data->msw_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($msw_data->msw_certification_id): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$msw_data->msw_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->ain_data && $educationData->ain_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->ain_data){
                                                        $ain_data1 = json_decode($educationData->ain_data);
                                                        $ain_data_arr = array();
                                                        foreach ($ain_data1 as $ain_data) {
                                                            $ain_data_arr[] = $ain_data->ain_certification_id;
                                                        }
                                                        $ain_data_json = json_encode($ain_data_arr);
                                                        }else{
                                                        $ain_data1 = "";
                                                        $ain_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>AIN (Assistant in Nursing) / NA (Nurse Associate) / HCA (Healthcare Assistant) :</strong>
                                                            
                                                            <?php
                                                                $ain_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "19")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $ain_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ain_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($ain_data->ain_certification_id == $ain_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($ain_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($ain_data->ain_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($ain_data->ain_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($ain_file): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$ain_data->ain_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->rpn_data && $educationData->rpn_data != 'null'): ?>
                                                    <?php 
                                                        if($educationData && $educationData->rpn_data){
                                                        $rpn_data1 = json_decode($educationData->rpn_data);
                                                        $rpn_data_arr = array();
                                                        foreach ($rpn_data1 as $rpn_data) {
                                                            $rpn_data_arr[] = $rpn_data->rpn_certification_id;
                                                        }
                                                        $rpn_data_json = json_encode($rpn_data_arr);
                                                        }else{
                                                        $rpn_data1 = "";
                                                        $rpn_data_json = "";
                                                        }
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>RPN (Registered Practical Nurse) / RGN (Registered General Nurse) :</strong>
                                                            
                                                            <?php
                                                                $rpn_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "20")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $rpn_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpn_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if($rpn_data->rpn_certification_id == $rpn_data->name): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($rpn_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($rpn_data->rpn_license_number); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($rpn_data->rpn_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($rpn_data->rpn_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$rpn_data->rpn_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if($educationData->nl_data && $educationData->nl_data != 'null'): ?>
                                                    <?php 
                                                        $nl_data_ids = json_decode($educationData->nl_data, true); // Decode the acls_data field into an array
                                                        $nlData = json_decode($nl_data_ids['nl_data'], true);
                                                        $nl_licence_num = $nl_data_ids['nl_licence_num'];
                                                        $nl_licence_expiry = $nl_data_ids['nl_licence_expiry'];                                      
                                                        $nl_file = $nl_data_ids['nl_file'];
                                                    ?>
                                                    
                                                     <div class="col-md-12 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>No License/Certification :</strong>
                                                            
                                                            <?php
                                                                $nl_datas = DB::table("professional_certificate_table")
                                                                                ->where("cert_id", "21")
                                                                                ->get();
                                                            ?>
                                                            <ul class="dropdown-list">
                                                                <?php $__empty_1 = true; $__currentLoopData = $nl_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nl_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                    <?php if(is_array($nl_data_ids) && in_array($nl_data->professionalcert_id,$nlData)): ?>
                                                                        <li><span class="dropdown-item-custom"><?php echo e($nl_data->name); ?> , </span></li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Number :</strong>
                                                             <span class=""><?php echo e($nl_licence_num); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry :</strong>
                                                             <span class=""><?php echo e($nl_licence_expiry); ?></span>                                                  
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Certification/Licence Image :</strong>
                                                            <?php if($nl_file): ?>
                                                            <a href="<?php echo e(asset('uploads/'.$nl_file)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?>                                           
                                                        </div>
                                                    </div>
                                                <?php endif; ?>





                                                <?php if($educationData->licence_number && $educationData->country &&
                                                $educationData->state && $educationData->expiration_date ): ?>
                                                <h4  class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Licenses: </h4>
                                               
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>licence_number : </strong>
                                                         <span class=""><?php echo e($educationData->licence_number); ?></span>   
                                                    </div>
                                                </div>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Country : </strong>
                                                        <span class=""><?php echo e($educationData->country); ?> </span>   
                                                         
                                                    </div>
                                                </div>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>State : </strong>
                                                         <span class=""><?php echo e(state_name( $educationData->state)); ?></span>   
                                                    </div>
                                                </div>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Expiration Date : </strong>
                                                         <span class=""><?php echo e(\Carbon\Carbon::parse($educationData->expiration_date)->format('d/m/Y')); ?></span>   
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                  
                                                <?php 
                                                    // $training_workshops = json_decode($educationData->training_workshops);
                                                ?>
                                               <?php
                                                    if(!empty($educationData)){
                                                    $certificate_data = json_decode($educationData->additional_training_data);
                                                    }else{
                                                    $certificate_data = "";
                                                    }

                                                ?>
                                                <?php
                                                $i = 1;
                                                ?>
                                                <?php if(!empty($certificate_data)): ?>
                                                <?php $__currentLoopData = $certificate_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <h4  class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Additional Training :</h4>

                                                <h6>Certification/Licence <?php echo e($i); ?></h6>
                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Courses/workshops : </strong>
                                                        <span class=""><?php echo e($c_data->training_courses); ?></span> 
                                                    </div>
                                                </div>

                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Certification/Licence Number : </strong>
                                                        <span class=""><?php echo e($c_data->additional_license_number); ?></span> 
                                                    </div>
                                                </div>

                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Expiry : </strong>
                                                        <span class=""><?php echo e($c_data->additional_expiry); ?></span> 
                                                    </div>
                                                </div>

                                                <div class="col-md-6 mt-3">
                                                    <div class="d-flex gap-3 flex-wrap">
                                                        <strong>Upload your certification/Licence : </strong>
                                                        <?php if($c_data->additional_upload_certification): ?>
                                                            <a href="<?php echo e(asset('uploads/certificates/'.$c_data->additional_upload_certification)); ?>" target="_blank">
                                                                <span class="text-success">View Image</span>
                                                            </a>  
                                                            <?php else: ?>  
                                                            <span class="">No Image</span> 
                                                            <?php endif; ?> 
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                                

                                            </div>
                                            <?php else: ?>
                                            <div class="col-md-12">
                                                <div class="text-center text-danger fs-5">No data found</div>
                                            </div>
                                            
                                            <?php endif; ?>
                                        
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-4" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Experience</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                            <?php if($experienceData): ?>
                                                <div class="row">
                                                    <?php if(isset($profileData->assistent_level)): ?>
                                                    
                                                    <?php
                                                    $levels = [
                                                            1 => '1st Year', 2 => '2nd Year', 3 => '3rd Year', 4 => '4th Year', 
                                                            5 => '5th Year', 6 => '6th Year', 7 => '7th Year', 8 => '8th Year', 
                                                            9 => '9th Year', 10 => '10th Year', 11 => '11th Year', 12 => '12th Year', 
                                                            13 => '13th Year', 14 => '14th Year', 15 => '15th Year', 16 => '16th Year', 
                                                            17 => '17th Year', 18 => '18th Year', 19 => '19th Year', 20 => '20th Year', 
                                                            21 => '21st Year', 22 => '22nd Year', 23 => '23rd Year', 24 => '24th Year', 
                                                            25 => '25th Year', 26 => '26th Year', 27 => '27th Year', 28 => '28th Year', 
                                                            29 => '29th Year', 30 => '30th Year'
                                                        ];
                                                        $expre = $levels[$profileData->assistent_level] ?? '30th Year';
                                                    ?> 
                                                    
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Total Year of Experience : </strong><span><?php echo e($expre); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>

                                                    <?php
                                                        if(!empty($experienceData)){
                                                        $work_experience_data = json_decode($experienceData->work_experience);
                                                        }else{
                                                        $work_experience_data = "";
                                                        }

                                                    ?>
                                                    
                                                    <?php if(!empty($work_experience_data)): ?>
                                                       <?php
                                                        $i = 1;
                                                        ?>
                                                        <?php $__currentLoopData = $work_experience_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                         <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center ">Previous Employers <?php echo e($i); ?>: </h4>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Names :</strong>
                                                                </strong><span><?php echo e($w_data->previous_employer_name1); ?></span>
                                                            </div>                
                                                        </div>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Position Held : </strong>
                                                                <span>
                                                                    <?php if($w_data->positions_held1 == "Team Member"): ?>
                                                                        Team Member
                                                                    <?php elseif($w_data->positions_held1 == "Team Leader"): ?>
                                                                        Team Leader
                                                                    <?php elseif($w_data->positions_held1 == "Educator"): ?>
                                                                        Educator
                                                                    <?php elseif($w_data->positions_held1 == "Manager"): ?>
                                                                        Manager
                                                                    <?php elseif($w_data->positions_held1 == "Clinical Specialist"): ?>
                                                                        Clinical Specialist
                                                                    <?php else: ?>
                                                                        No position selected
                                                                    <?php endif; ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Employment Start Date : </strong>
                                                                <span><?php echo e(\Carbon\Carbon::parse($w_data->start_date1 )->format('d/m/Y')); ?></span>
                                                            </div>
                                                       </div>
                                                       <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Employment End Date : </strong>
                                                                <span><?php echo e(\Carbon\Carbon::parse($w_data->end_date1)->format('d/m/Y')); ?></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Employment type : </strong>
                                                                <span>
                                                                <?php if($w_data->employeement_type1 == "Agency"): ?>
                                                                    Agency
                                                                <?php else: ?>
                                                                    Staffing Agency
                                                                <?php endif; ?>
                                                                </span>                                                        
                                                            </div>
                                                        </div>

                                                        <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center ">Detailed Job Descriptions :</h4>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Responsibilities :</strong>
                                                                <textarea  style="resize: none;" id="visa_grant_number" name="visa_grant_number" class="form-control" rows="2" readonly><?php echo e($w_data->job_responeblities1); ?></textarea>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Achievements :</strong>
                                                                <textarea  style="resize: none;" id="visa_grant_number" name="visa_grant_number" class="form-control" rows="2" readonly><?php echo e($w_data->achievements1); ?></textarea>
                                                            </div>
                                                       </div>
                                                        <?php
                                                        $i++;
                                                        ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    <?php endif; ?>

                                                   
                                                    <?php if(isset($experienceData->skills_compantancies) && $experienceData->skills_compantancies): ?>
                                                     <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Areas of Expertise :</h4>
                                                     <?php $skills_compantancies=json_decode($experienceData->skills_compantancies); ?>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Specific skills and competencies : </strong>
                                                            <span><?php echo e(skill_name_by_id($skills_compantancies)); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>

                                                </div>
                                                <?php else: ?>
                                                <div class="col-md-12">
                                                    <div class="text-center text-danger fs-5">No data found</div>
                                                </div>
                                                
                                                <?php endif; ?>
                                            
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-4.1" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">References</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                         <?php if(!empty($RefereData)): ?>
                                         <?php
                                            $i = 1;
                                            ?>
                                         <?php $__currentLoopData = $RefereData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <h4>References <?php echo e($i); ?></h4>
                                            <?php if(isset($data->first_name) && $data->first_name): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>First name: </strong>
                                                    <span><?php echo e($data->first_name); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($data->last_name) && $data->last_name): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Last name: </strong>
                                                    <span><?php echo e($data->last_name); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($data->email) && $data->email): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Email: </strong>
                                                    <span><?php echo e($data->email); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(isset($data->phone_no) && $data->phone_no): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Last name: </strong>
                                                    <span><?php echo e($data->phone_no); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(isset($data->relationship) && $data->relationship): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Relationship: </strong>
                                                    <span><?php echo e($data->relationship); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(isset($data->worked_together) && $data->worked_together): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>You worked together at: </strong>
                                                    <span><?php echo e($data->worked_together); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            
                                            <?php if(isset($data->start_date) && $data->start_date): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Start Date : </strong><span><?php echo e(\Carbon\Carbon::parse($data->start_date)->format('d/m/Y')); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($data->end_date) && $data->end_date): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong> End Date : </strong><span><?php echo e(\Carbon\Carbon::parse($data->end_date)->format('d/m/Y')); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($data->position_with_referee) && $data->position_with_referee): ?>
                                            <div class="col-md-12 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>What was your position when you worked with this referee?: </strong>
                                                    <span><?php echo e($data->position_with_referee); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>   
                                        </div>
                                        <?php
                                        $i++;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                    
                                    <?php endif; ?>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-5" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Mandatory Training</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                        <?php if($mandatorytrainingData): ?>
                                        <div class="row">
                                            <h4>Completed training programs</h4>
                                            <?php if(isset($mandatorytrainingData->start_date) && $mandatorytrainingData->start_date): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Training Start Date : </strong><span><?php echo e(\Carbon\Carbon::parse($mandatorytrainingData->start_date)->format('d/m/Y')); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($mandatorytrainingData->end_date) && $mandatorytrainingData->end_date): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Training End Date : </strong><span><?php echo e(\Carbon\Carbon::parse($mandatorytrainingData->end_date)->format('d/m/Y')); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(isset($mandatorytrainingData->institutions) && $mandatorytrainingData->institutions): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Institution: </strong>
                                                    <span><?php echo e($mandatorytrainingData->institutions); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($mandatorytrainingData->continuing_education) && $mandatorytrainingData->continuing_education): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Mandatory Continuing Education: </strong>
                                                    <span><?php echo e($mandatorytrainingData->continuing_education); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>       
                                        </div>
                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                    
                                    <?php endif; ?>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-6" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Vaccinations</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                        <?php if($vaccinationData): ?>
                                        <div class="row">
                                            
                                            <?php if(isset($vaccinationData->vaccination_records) && $vaccinationData->vaccination_records): ?>
                                            <div class="col-md-12 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Vaccination Records : </strong>
                                                    <?php $vaccinations = json_decode($vaccinationData->vaccination_records) ;?>
                                                    <ul class="dropdown-list">
                                                        <?php $__empty_1 = true; $__currentLoopData = $vaccinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <li><span class="dropdown-item-custom"><?php echo e(vaccination_name_by_id($value)); ?> , </span></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <li><a href="#" class="dropdown-item-custom"></a></li>
                                                        <?php endif; ?>
                                                    </ul>
                                            </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($vaccinationData->immunization_status) && $vaccinationData->immunization_status): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Immunization Status : </strong>
                                                     <span><?php echo e($vaccinationData->immunization_status); ?></span>
                                                    
                                                </div>
                                            </div>
                                            <?php endif; ?>
       
                                        </div>
                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                    
                                    <?php endif; ?>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-7" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Work Clearances</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                            <?php if($eligibilityToWorkData): ?>
                                                <div class="row">
                                                    <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Eligibility For Work : </h4>
                                                    <?php if(isset($eligibilityToWorkData->residency) && $eligibilityToWorkData->residency): ?>
                                                    
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Residency : </strong><span><?php echo e($eligibilityToWorkData->residency); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php if(isset($eligibilityToWorkData->support_document) && $eligibilityToWorkData->support_document): ?>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Support Document:</strong>
                                                            <a href="<?php echo e(asset($eligibilityToWorkData->support_document)); ?>" target="_blank">
                                                                <span class="text-success">View Document</span>
                                                            </a>
                                                        </div>
                                                        
                                                    </div>
                                                    <?php endif; ?>

                                                    <?php if(isset($eligibilityToWorkData->visa_subclass_number) && $eligibilityToWorkData->visa_subclass_number): ?>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Visa Subclass Number : </strong>
                                                            <span><?php echo e($eligibilityToWorkData->visa_subclass_number); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>

                                                    <?php if(isset($eligibilityToWorkData->passport_number) && $eligibilityToWorkData->passport_number): ?>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Passport Number : </strong>
                                                            <span><?php echo e($eligibilityToWorkData->passport_number); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>


                                                    <?php if(isset($eligibilityToWorkData->visa_grant_number) && $eligibilityToWorkData->visa_grant_number): ?>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Visa grant number: </strong>
                                                            <span><?php echo e($eligibilityToWorkData->visa_grant_number); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>

                                                    <?php if(isset($eligibilityToWorkData->passport_country_of_Issue) && $eligibilityToWorkData->passport_country_of_Issue): ?>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Passport Country Of Issue: </strong>
                                                            <span><?php echo e(country_name_new($eligibilityToWorkData->passport_country_of_Issue)); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>

                                                    <?php if(isset($eligibilityToWorkData->expiry_date) && $eligibilityToWorkData->expiry_date): ?>
                                                    <div class="col-md-6 mt-3">
                                                        <div class="d-flex gap-3 flex-wrap">
                                                            <strong>Expiry Date: </strong>
                                                            <span><?php echo e($eligibilityToWorkData->expiry_date); ?></span>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                    <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center mt-3">Working With Children Check : </h4>
                                                    <?php if($workingChildrenCheckData): ?>
                                                        <?php if(isset($workingChildrenCheckData->clearance_number) && $workingChildrenCheckData->clearance_number): ?>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Clearance Number : </strong><span><?php echo e($workingChildrenCheckData->clearance_number); ?></span>
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if(isset($workingChildrenCheckData->state) && $workingChildrenCheckData->state): ?>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>State: </strong><span><?php echo e(state_name($workingChildrenCheckData->state)); ?></span>
                                                            </div>
                                                            
                                                        </div>
                                                        <?php endif; ?>

                                                        <?php if(isset($workingChildrenCheckData->expiry_date) && $workingChildrenCheckData->expiry_date): ?>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Expiry Date: </strong>
                                                                <span><?php echo e($workingChildrenCheckData->expiry_date); ?></span>
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>

                                                    <?php else: ?>
                                                    <div class="col-md-12">
                                                        <div class="text-center text-danger fs-5">No data found</div>
                                                    </div>
                                                    
                                                    <?php endif; ?>
                                                    <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center mt-3">Police check : </h4>
                                                    <?php if($policeCheckVerificationData): ?>           
                                                        <?php if(isset($policeCheckVerificationData->date) && $policeCheckVerificationData->date): ?>
                                                        <div class="col-md-12 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Date : </strong><span><?php echo e($policeCheckVerificationData->date); ?></span>
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if(isset($policeCheckVerificationData->image) && $policeCheckVerificationData->image): ?>
                                                        <div class="col-md-12 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Image : </strong>
                                                                <a href="<?php echo e(asset($policeCheckVerificationData->image)); ?>" target="_blank">
                                                                    <img src="<?php echo e(asset($policeCheckVerificationData->image)); ?>" alt="" style="height:50px;width:50px">
                                                                </a>                                                    
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if(isset($policeCheckVerificationData->status) && $policeCheckVerificationData->status): ?>
                                                        <div class="col-md-12 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Status : </strong>
                                                                <?php if($policeCheckVerificationData->status == 1): ?>
                                                                <span class="badge bg-success">Approved</span>
                                                                <?php elseif($policeCheckVerificationData->status == 2): ?>
                                                                <span class="badge bg-danger">Rejected</span>
                                                                <?php else: ?> 
                                                                <?php endif; ?>
                                                        
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>
                                                        <?php if(isset($policeCheckVerificationData->status) && $policeCheckVerificationData->status == 2): ?>
                                                        <div class="col-md-6 mt-3">
                                                            <div class="d-flex gap-3 flex-wrap">
                                                                <strong>Reason : </strong>
                                                                <span><?php echo e($policeCheckVerificationData->reason); ?></span>
                                                            </div>
                                                        </div>
                                                        <?php endif; ?>
                                
                                                     
                                                    <?php else: ?>
                                                    <div class="col-md-12">
                                                        <div class="text-center text-danger fs-5">No data found</div>
                                                    </div>
                                                    
                                                    <?php endif; ?>
                                        
                    
                                                      
                            
                                                </div>
                                                <?php else: ?>
                                                <div class="col-md-12">
                                                    <div class="text-center text-danger fs-5">No data found</div>
                                                </div>
                                                
                                                <?php endif; ?>
                                            
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-8" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Professional Memberships</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                         <?php if($proMembershipData): ?>
                                        <div class="row">
                                            <?php if(isset($proMembershipData->des_profession_association) && $proMembershipData->des_profession_association): ?>
                                            <?php $data = json_decode($proMembershipData->des_profession_association,true)?>
                                            <div class="col-md-12 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Professional Associations : </strong>
                                                    <ul class="dropdown-list">
                                                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <li><span class="dropdown-item-custom"><?php echo e($value); ?> , </span></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <li><a href="#" class="dropdown-item-custom"></a></li>
                                                        <?php endif; ?>
                                                    </ul> 
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($proMembershipData->membership_numbers) && $proMembershipData->membership_numbers): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Membership Numbers : </strong><span><?php echo e($proMembershipData->membership_numbers); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(isset($proMembershipData->membership_status) && $proMembershipData->membership_status): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Status: </strong>
                                                    <span><?php echo e($proMembershipData->membership_status); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>      
                                        </div>
                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                    
                                    <?php endif; ?>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-9" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center">Interview and References</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                        <?php if($interviewrefData): ?>
                                        <div class="row">
                                          
                                            <?php if(isset($interviewrefData->interview_availablity) && $interviewrefData->interview_availablity): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Interview Availability : </strong><span><?php echo e(\Carbon\Carbon::parse($interviewrefData->interview_availablity)->format('d/m/y H:i')); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($interviewrefData->reference_name) && $interviewrefData->reference_name): ?>
                                              <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Professional References</h4>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Names : </strong><span><?php echo e($interviewrefData->reference_name); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(isset($interviewrefData->reference_email) && $interviewrefData->reference_email): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Email: </strong>
                                                    <span><?php echo e($interviewrefData->reference_email); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($interviewrefData->contact_country_code) && $interviewrefData->contact_country_code): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Mobile Number : </strong>
                                                    <span>+<?php echo e($interviewrefData->contact_country_code); ?><?php echo e(" "); ?>

                                                             <?php echo e($interviewrefData->reference_contact); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>  
                                            <?php if(isset($interviewrefData->reference_relationship) && $interviewrefData->reference_relationship): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Relationship : </strong>
                                                    <span><?php echo e($interviewrefData->reference_relationship); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>      
                                        </div>
                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                    
                                    <?php endif; ?>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-10" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center">Personal Preferences</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                        <?php if($personalprefData): ?>
                                        <div class="row">
                                          
                                            <?php if(isset($personalprefData->preferred_work_schedule) && $personalprefData->preferred_work_schedule): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Preferred Work Schedule : </strong><span><?php echo e($personalprefData->preferred_work_schedule); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            <?php if(isset($personalprefData->country) && $personalprefData->country): ?>
                                              <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Preferred Work Locations</h4>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Country : </strong><span><?php echo e(country_name($personalprefData->country)); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>

                                            <?php if(isset($personalprefData->state) && $personalprefData->state): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>State: </strong>
                                                    <span><?php echo e(state_name($personalprefData->state)); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                             
                                            <?php if(isset($personalprefData->work_environment) && $personalprefData->work_environment): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Work Environment Preferences : </strong>
                                                    <span><?php echo e($personalprefData->work_environment); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>  
                                            <?php if(isset($personalprefData->shift_preferences) && $personalprefData->shift_preferences): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Shift Preferences : </strong>
                                                    <span><?php echo e($personalprefData->shift_preferences); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?>  
                                            <?php if(isset($personalprefData->specific_facilities) && $personalprefData->specific_facilities): ?>
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Specific Facilities : </strong>
                                                    <textarea name="specific_facilities" class="form-control"><?php echo e($personalprefData->specific_facilities); ?></textarea>
                                                </div>
                                            </div>
                                            <?php endif; ?>    
                                        </div>
                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                    
                                    <?php endif; ?>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane p-3" id="navpill-11" role="tabpanel">
                        <div class="row">
                            <div class=" w-100  overflow-hidden">
                                <div class="card-body p-3 px-md-4 pb-0">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center">Find Work Preferences</h3>
                                </div>
                                <div class="card-body p-3 px-md-4">
                                    <div class="col-md-12">
                                        <?php if($findworkData): ?>
                                        <div class="row">
                                          
                                            <?php if(isset($findworkData->desired_job_role) && $findworkData->desired_job_role): ?>
                                            <?php 
                                              $desired_job_roles = json_decode($findworkData->desired_job_role);
                                            ?>
                                            <div class="col-md-12 mt-3">
                                               
                                                <div class="d-flex gap-3 flex-wrap">
                                                     <strong>Desired Job Role : </strong>
                                                   <ul class="dropdown-list">
                                                        <?php $__empty_1 = true; $__currentLoopData = $desired_job_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $desired_job_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <li><span class="dropdown-item-custom"><?php echo e(specialty_name_by_id_NEW($desired_job_role)); ?> , </span></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <li><a href="#" class="dropdown-item-custom">No specialties available</a></li>
                                                        <?php endif; ?>
                                                  </ul>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                            

                                            <?php if(isset($findworkData->benefits_preferences) && $findworkData->benefits_preferences): ?>
                                            <div class="col-md-12 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Benefits Preferences : </strong>
                                                    <?php 
                                                        $benefits_preferences = json_decode($findworkData->benefits_preferences);
                                                        ?>
                                                    <ul class="dropdown-list">
                                                        <?php $__empty_1 = true; $__currentLoopData = $benefits_preferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $benefits_prefere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <li><span class="dropdown-item-custom"><?php echo e($benefits_prefere); ?> , </span></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <li><a href="#" class="dropdown-item-custom">No specialties available</a></li>
                                                        <?php endif; ?>
                                                  </ul>
            
                                                </div>
                                            </div>
                                            <?php endif; ?>  
                                            <?php if(isset($findworkData->salary_expectations) && $findworkData->salary_expectations): ?>
                                              
                                            <div class="col-md-6 mt-3">
                                                <div class="d-flex gap-3 flex-wrap">
                                                    <strong>Salary Expectations : </strong><span><?php echo e($findworkData->salary_expectations); ?></span>
                                                </div>
                                            </div>
                                            <?php endif; ?> 
                                        </div>
                                    <?php else: ?>
                                    <div class="col-md-12">
                                        <div class="text-center text-danger fs-5">No data found</div>
                                    </div>
                                    
                                    <?php endif; ?>
                    
                                    </div>
                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript"
        src="https://nextjs.webwiders.in/pindrow/public/advertiser/dist/libs/owl.carousel/dist/owl.carousel.min.js">
    </script>
    <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <script type="text/javascript"></script>
    <script>
        $(document).ready(function() {
            // cate_1
            $('#cat_1').after(sugical_care);
            $('#sugical_care').after(Operating_Room);
            $('#Operating_Room').after(paediatric_oR);
            $('#paediatric_oR').after(Technician_Nurse);

            // For cat 2
            $('#cat_2').after(Surgical_Obstetrics);

            // For cat 3
            $('#cat_3').after(Neonatal_Care);
            $('#Neonatal_Care').after(Surgical_Preop);
            $('#Surgical_Preop').after(Paediatric_Operating);
            $('#Paediatric_Operating').after(Paediatric_Operating_Scout);
            $('#Paediatric_Operating_Scout').after(Paediatric_Operating_Scrub);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/phpserver2/public_html/mediqa/resources/views/admin/profile-view.blade.php ENDPATH**/ ?>