<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="msapplication-TileColor" content="#0E0E0E">
    <meta name="template-color" content="#0E0E0E">
    <meta name="author" content="">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('nurse/assets/imgs/template/favicon.svg')); ?>">
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

     <link rel="stylesheet" type="text/css" href="<?php echo e(asset('nurse/assets/css/stylecd4e.css?version=4.1')); ?>">
    <script src="https://kit.fontawesome.com/107d2907de.js" crossorigin="anonymous"></script>
     <title><?php echo e(env('APP_NAME')); ?></title>
  </head>

<body class="home">
    <div class="page-wrapper">
            <?php echo $__env->make('nurse.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <?php echo $__env->yieldContent('css'); ?>
            <?php echo $__env->make('nurse.layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        
        <?php echo $__env->make('nurse.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('nurse.layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('js'); ?>
      </body>

</html>
<?php /**PATH /home1/vitalqzv/nextjs.webwiders.in/mediqa/resources/views/nurse/layouts/layout.blade.php ENDPATH**/ ?>