<style>
.compliant {
    background-color: #d3d3d33b;
    padding: 18px;
    border: solid 1px #d3d3d385;
    border-radius: 11px;
    margin-bottom: 15px;
}
.compliant span {
    line-height: 1.8;
}

.compliant a {
    line-height: 2.5;
    text-decoration: underline;
    font-weight: 500;
    color: #36c !important;
}

.compliant p.MsoNormal span {
    background: none !important;
    line-height: 1.8 !important;
}



</style>


<?php if($data->isEmpty()): ?>
    <div class="alert alert-warning">
        No data available for the selected state(s) and vaccine(s).
    </div>
<?php else: ?>
<div class="content-container">
    <?php $__currentLoopData = $data->groupBy('state_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stateName => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h6><?php echo e($stateName); ?></h6>
        <p><?php echo $items->first()->policy; ?></p>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="compliant">
                <?php echo $item->complinace_content; ?>

            </div> <!-- Properly closed div -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php endif; ?><?php /**PATH /home/mediqa/public_html/resources/views/nurse/compliance_content.blade.php ENDPATH**/ ?>