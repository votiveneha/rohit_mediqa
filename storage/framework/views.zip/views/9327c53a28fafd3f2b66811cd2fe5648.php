<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="back_arrow" onclick="history.back()" title="Go Back">
        <i class="fa fa-arrow-left"></i>
    </div>
    <div class="card bg-light-info shadow-none position-relative overflow-hidden">
        <div class="card-body px-4 py-3">
            <div class="row align-items-center">
                <div class="col-9">
                    <h4 class="fw-semibold mb-8"> View Profile </h4>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a class="text-muted " href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">View Profile</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-3">
                    <div class="text-center mb-n5">
                        <img src="<?php echo e(asset('admin/dist/images/breadcrumb/ChatBc.png')); ?>" alt=""
                            class="img-fluid" style="height: 125px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card w-100  overflow-hidden">
        <div class="card-body p-3 px-md-4 pb-0">
            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Personal Detail <?php if($profileData->status == 1): ?>
                <span class="badge bg-success ms-2">Unblock</span>
                <?php else: ?>
                <span class="badge bg-danger ms-2">Blocked</span>
                <?php endif; ?>
            </h3>
        </div>
        <div class="card-body p-3 px-md-4">
            <div class="row align-items-center justify-content-between">
                <div class="col ">
                    <div class="d-flex align-items-md-center gap-4 flex-column flex-md-row">
                        <div class="d-flex  mb-2 ">
                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center "
                                style="width: 144px; height: 144px;" ;>
                                <div class="border rounded-circle border-3 border-white d-flex align-items-center justify-content-center  overflow-hidden btn-light commingsoon"
                                    data-bs-toggle="modal" data-bs-target="#commingsoonModel"
                                    style="width: 140px; height: 140px;" ;>
                                    <img src="<?php echo e(asset($profileData->profile_img)); ?>" alt=""
                                        class="w-100 h-100">
                                </div>

                            </div>
                        </div>
                        <div class="w-100">
                            <div class="d-flex justify-content-between">
                                <h5 class="fs-5 mb-2 fw-bolder"> <?php echo e(ucwords($profileData->name)." ".ucwords($profileData->lastname)); ?> </h5>
                                <h5 class="fs-5 mb-2 fw-bolder"> </h5>

                            </div>
                            <?php if($profileData->phone != ''): ?>
                            <p class="d-flex text-dark align-items-center gap-2 mb-1">
                                <i class="ti ti-phone fs-4"></i><strong> +<?php echo e($profileData->country_code); ?>

                                    <?php echo e($profileData->phone); ?>

                                </strong>
                            </p>
                            <?php endif; ?>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <p class="mb-0 d-flex text-dark align-items-center gap-2">
                                    <i class="ti ti-mail fs-4"></i><?php echo e($profileData->email); ?>

                                </p>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->post_code != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Post Code : <?php echo e($profileData->post_code); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->preferred != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Preferred Name : <?php echo e($profileData->preferred); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-">
                                <?php if($profileData->store_url != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Store URL: <?php echo e($profileData->store_url); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>


                        </div>
                    </div>
                </div>



            </div>

        </div>
    </div>
    <div class="card list-drpdwns-set">
        <div class="card-body">
            <?php echo $__env->make("admin.layouts.nurse_view_tabs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="tab-content border mt-2">
                <div class="tab-pane p-3 active show" id="navpill-1" role="tabpanel">
                    <div class=" w-100  overflow-hidden">
                        <div class="card-body p-3 px-md-4 pb-0">
                            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Language Skills</h3>
                        </div>
                        <div class="card-body p-3 px-md-4">
                            <?php if(!empty($language_skills)): ?>
                            <div class="language_skills_details">
                                <div class="mt-4">
                                     <?php
                                            if(!empty($language_skills) && $language_skills->langprof_level != NULL){
                                                $language_skills_data = json_decode($language_skills->langprof_level);
                                            
                                            }else{
                                                $language_skills_data = array(); 
                                            }

                                            $lang_data = (array)$language_skills_data;
                                            //print_r($lang_data);

                                            $langs_arr = array();
                                            $langid_arr = array();

                                            if(!empty($language_skills_data)){
                                                foreach ($language_skills_data as $index=>$langdata) {
                                                
                                                    $languages_name = DB::table("languages")->where("language_id",$index)->first();
                                                    //print_r($p_memb);
                                                    $langs_arr[] = $languages_name->language_name;
                                                    $langid_arr[] = $index;
                                                    
                                                }
                                            }
                                            $i = 0;
                                           
                                        ?>

                                <!-- Language Groups -->
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Language Groups</label>
                                    <div>
                                    <?php $__currentLoopData = $langs_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                    <span class="badge bg-dark me-1"><?php echo e($langdata); ?></span>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $langid_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l_arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $sub_lang = (array)$lang_data[$l_arr];
                                    $language_data = DB::table("languages")->where("language_id",$l_arr)->first();
                                    $sublanguage_data = DB::table("languages")->where("sub_language_id",$l_arr)->orderBy("language_name","ASC")->get();
                                    //print_r($sub_lang);   
                                    $sub_lang_arr = array();
                                    $sublangid_arr = array();
                                    $sub_lang_text = '';

                                    foreach ($sub_lang as $index=>$larr) {
                                        $languages_name = DB::table("languages")->where("language_id",$index)->first();
                                        if(!empty($language_data) && $language_data->language_field == "dropdown"){
                                            
                                            $sub_lang_arr[] = $languages_name->language_name;
                                            $sublangid_arr[] = $index;
                                        }else{
                                            $sub_lang_arr[] = $languages_name->language_name;
                                            $sublangid_arr[] = $index;
                                            //$sub_lang_text = $sub_lang[0];
                                        }
                                    
                                    }
                                    
                                    
                                ?>
                                
                                    <!-- Asian Languages -->
                                <div class="mb-3">
                                    <label class="form-label"><?php echo e($langs_arr[$i]); ?></label>
                                    <div>
                                        <?php $__currentLoopData = $sub_lang_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl_arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-secondary me-1"><?php echo e($sl_arr); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    
                                    </div>
                                </div>

                                <!-- Proficiency Level (Asian Languages) -->
                                <div class="mb-3">
                                    <label class="form-label">Proficiency Level (<?php echo e($langs_arr[$i]); ?>)</label>
                                    <div>
                                        <?php $__currentLoopData = $sublangid_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subl_arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $sublanguage_name = DB::table("languages")->where("language_id",$subl_arr)->first();
                                            $prof_level = (array)$sub_lang[$subl_arr];
                                            //print_r($prof_level);
                                            
                                        ?>
                                    <div class="mb-1"><?php echo e($sublanguage_name->language_name); ?>: <strong><?php echo e($prof_level[0]); ?></strong></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                
                                <?php
                                    $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                </div>
                                <div class="language_proficiency">
                                    <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center  mt-3" style="margin-bottom: 20px;">Language Proficiency Certifications</h4>
                                    <?php
                                        if(!empty($language_skills) && $language_skills->english_prof_cert != NULL){
                                        $english_prof_data = json_decode($language_skills->english_prof_cert);
                                        
                                        }else{
                                        $english_prof_data = array(); 
                                        }

                                        $english_data = (array)$english_prof_data;
                                        //print_r($lang_data);

                                        $eng_arr = array();
                                        $engid_arr = array();

                                        if(!empty($english_prof_data)){
                                            foreach ($english_prof_data as $index=>$englishdata) {
                                                $languages_name = DB::table("languages")->where("language_id",$index)->first();
                                                //print_r($p_memb);
                                                $engid_arr[] = $index;
                                                $eng_arr[] = $languages_name->language_name;
                                                
                                            }
                                        }
                                        
                                    ?>    
                                    <?php if(!empty($engid_arr)): ?>
                                    <?php $__currentLoopData = $engid_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $lang_data = DB::table("languages")->where("language_id",$engids)->first();
                                        $engdata = (array)$english_data[$engids];
                                    ?>
                                    <div style="margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 20px;">
                                        <h4 style="margin-bottom: 10px; font-size: 16px;">
                                        <?php echo e($lang_data->language_name); ?>

                                        </h4>
                                        <p><strong>Score / Level Obtained:</strong><?php echo e($engdata['score_level']); ?></p>
                                        <p><strong>Expiring Date:</strong><?php echo e($engdata['expiring_date']); ?></p>
                                        
                                        <div class="evidence_img_list">
                                            <p><strong>Evidence:</strong>
                                            <ul>
                                                <?php
                                                    if(isset($engdata['evidence_imgs'])){
                                                        $evidence_imgs = (array)json_decode($engdata['evidence_imgs']);
                                                    //$evorgimg = $evidence_imgs[$p_arr2];
                                                    //print_r($evorgimg);
                                                    $i = 0;
                                                    ?>
                                                <?php if(!empty($evidence_imgs)): ?>
                                                <?php $__currentLoopData = $evidence_imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($ev_img); ?>" target="_blank" style="color: #007bff; text-decoration: none;">
                                                        📄 <?php echo e($ev_img); ?>

                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <?php
                                                }
                                                //print_r($evidence_imgs);
                                                ?>
                                                
                                            
                                            </ul>
                                        </div>    
                                        
                                        </p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php endif; ?>
                                </div>
                              
                            
                                <div class="other_proficiency">
                                    <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center  mt-3" style="margin-bottom: 20px;">Other Language Proficiency Certifications</h3>
                                    <?php
                                        if(!empty($language_skills) && $language_skills->other_prof_cert != NULL){
                                        $other_prof_data = json_decode($language_skills->other_prof_cert);
                                        
                                        }else{
                                        $other_prof_data = array(); 
                                        }

                                        $otherprof_data = (array)$other_prof_data;
                                        //print_r($lang_data);

                                        $other_prof_arr = array();

                                        if(!empty($other_prof_data)){
                                            foreach ($other_prof_data as $index=>$otherdata) {
                                            
                                                //print_r($p_memb);
                                                $other_prof_arr[] = $index;
                                                
                                            }
                                        }
                                    
                                    ?>
                                    <!-- Repeat this block for each certification -->
                                    <?php $__currentLoopData = $other_prof_arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherarr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $otherdata = (array)$otherprof_data[$otherarr];
                                        $other_prof_name = DB::table("languages")->where("language_id",$otherarr)->first();
                                    
                                    //print_r($engdata['score_level']);
                                    ?>
                                    <div style="margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 20px;">
                                        <h4 style="margin-bottom: 10px; font-size: 16px;">
                                        <?php echo e($other_prof_name->language_name); ?>

                                        </h4>
                                        <p><strong>Score / Level Obtained:</strong><?php echo e($otherdata['score_level']); ?></p>
                                        <p><strong>Expiring Date:</strong> <?php echo e($otherdata['expiring_date']); ?></p>
                                        
                                        <div class="evidence_img_list">
                                            <p><strong>Evidence:</strong>
                                            <ul>
                                                <?php
                                                    if(isset($otherdata['evidence_imgs'])){
                                                        $evidence_imgs = (array)json_decode($otherdata['evidence_imgs']);
                                                    //$evorgimg = $evidence_imgs[$p_arr2];
                                                    //print_r($evorgimg);
                                                    $i = 0;
                                                    ?>
                                                <?php if(!empty($evidence_imgs)): ?>
                                                <?php $__currentLoopData = $evidence_imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($ev_img); ?>" target="_blank" style="color: #007bff; text-decoration: none;">
                                                        📄 <?php echo e($ev_img); ?>

                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <?php
                                                }
                                                //print_r($evidence_imgs);
                                                ?>
                                                
                                            
                                            </ul>
                                        </div>    
                                        </p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>

                                <div class="specialized_skills">
                                    <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center  mt-3" style="margin-bottom: 20px;">Specialized Language Skills</h4>
                                    <?php
                                        if(!empty($language_skills) && $language_skills->specialized_lang_skills != NULL){
                                        $specialized_lang_data = json_decode($language_skills->specialized_lang_skills);
                                        
                                        }else{
                                        $specialized_lang_data = array(); 
                                        }

                                        $specialized_langskills = (array)$specialized_lang_data;
                                        //print_r($lang_data);

                                        $specialized_langarr = array();

                                        if(!empty($specialized_lang_data)){
                                        foreach ($specialized_lang_data as $index=>$specializeddata) {
                                        
                                            //print_r($p_memb);
                                            $specialized_langarr[] = $index;
                                            
                                        }
                                        }
                                    
                                        $specialized_lang_json = json_encode($specialized_langarr);
                                    ?>
                                    <!-- Repeat this block for each certification -->
                                    <?php $__currentLoopData = $specialized_langarr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speclangarr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $specializeddata = (array)$specialized_langskills[$speclangarr];
                                        $specialized_lang_name = DB::table("languages")->where("language_id",$speclangarr)->first();
                                    
                                    //print_r($engdata['score_level']);
                                    ?>
                                    <div style="margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 20px;">
                                        <h4 style="margin-bottom: 10px; font-size: 16px;">
                                        <?php echo e($specialized_lang_name->language_name); ?>

                                        </h4>
                                        <div class="evidence_img_list">
                                            <p><strong>Evidence:</strong>
                                            <ul>
                                                <?php
                                                    if(isset($specializeddata['evidence_imgs'])){
                                                        $evidence_imgs = (array)json_decode($specializeddata['evidence_imgs']);
                                                    //$evorgimg = $evidence_imgs[$p_arr2];
                                                    //print_r($evorgimg);
                                                    $i = 0;
                                                    ?>
                                                <?php if(!empty($evidence_imgs)): ?>
                                                <?php $__currentLoopData = $evidence_imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev_img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(url("/public")); ?>/uploads/education_degree/<?php echo e($ev_img); ?>" target="_blank" style="color: #007bff; text-decoration: none;">
                                                        📄 <?php echo e($ev_img); ?>

                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <?php
                                                }
                                                //print_r($evidence_imgs);
                                                ?>
                                                
                                            
                                            </ul>
                                        </div>    
                                        
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            </div>
                            <?php else: ?>
                            <div class="col-md-12">
                                <div class="text-center text-danger fs-5">No data found</div>
                            </div>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mediqa/public_html/resources/views/admin/view_language_skills.blade.php ENDPATH**/ ?>