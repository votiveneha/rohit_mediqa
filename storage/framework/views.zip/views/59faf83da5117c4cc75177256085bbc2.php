<?php $__env->startSection('content'); ?>
<style>
    h6 {
        font-family: "Plus Jakarta Sans", sans-serif;
        font-style: normal;
        font-weight: 700;
        font-size: 16px;
        line-height: 26px;
        color: #000000;
    }

    .dropdown-list {
        background-color: white;
        color: white;
        max-height: 200px;
        /* Adjust the height as needed */
        overflow-y: auto;
        /* Add scrollbar if content overflows */
        padding: 0;
        list-style: none;
        margin: 0;
        border: 1px solid #f1f1f1;
        border-radius: 4px;
        background-color: #ffffff;
        padding: 11px 15px 13px 15px;
        width: 100%;
        color: #A0ABB8;

    }

    .dropdown-item-custom {
        padding: 10px;
        /* Add padding to list items */
        color: black;
        text-decoration: none;
        display: block;
    }

    .dropdown-item-custom:hover {
        background-color: white;
        /* Change the hover background color */
    }

    .vacc_rec_div {
        padding: 20px;
        width: 97%;
        margin: auto;
        margin-top: 20px;
        margin-bottom: 0;
    }

    .vacc_rec_div .record_v {
        border-bottom: solid 1px #80808045;
        margin-bottom: 15px;
    }

    .vacc_rec_div .record_v h6 {
        margin-bottom: 0px;
    }

    .vaccine-section {
        padding: 20px;
        width: 97%;
        margin: auto;
        padding-top: 0px;
        border-bottom: solid 1px #80808045;
        margin-bottom: 15px;
    }

    h6.other-vaccin {
        font-size: 18px;
    }
</style>

<div class="container-fluid">
    <div class="back_arrow" onclick="history.back()" title="Go Back">
        <i class="fa fa-arrow-left"></i>
    </div>
    <div class="card bg-light-info shadow-none position-relative overflow-hidden">
        <div class="card-body px-4 py-3">
            <div class="row align-items-center">
                <div class="col-9">
                    <h4 class="fw-semibold mb-8"> View Profile </h4>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a class="text-muted " href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item" aria-current="page">View Profile</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-3">
                    <div class="text-center mb-n5">
                        <img src="<?php echo e(asset('admin/dist/images/breadcrumb/ChatBc.png')); ?>" alt=""
                            class="img-fluid" style="height: 125px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="card w-100  overflow-hidden">
        <div class="card-body p-3 px-md-4 pb-0">
            <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Personal Detail <?php if($profileData->status == 1): ?>
                <span class="badge bg-success ms-2">Unblock</span>
                <?php else: ?>
                <span class="badge bg-danger ms-2">Blocked</span>
                <?php endif; ?>
            </h3>
        </div>
        <div class="card-body p-3 px-md-4">
            <div class="row align-items-center justify-content-between">
                <div class="col ">
                    <div class="d-flex align-items-md-center gap-4 flex-column flex-md-row">
                        <div class="d-flex  mb-2 ">
                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center "
                                style="width: 144px; height: 144px;" ;>
                                <div class="border rounded-circle border-3 border-white d-flex align-items-center justify-content-center  overflow-hidden btn-light commingsoon"
                                    data-bs-toggle="modal" data-bs-target="#commingsoonModel"
                                    style="width: 140px; height: 140px;" ;>
                                    <img src="<?php echo e(asset($profileData->profile_img)); ?>" alt=""
                                        class="w-100 h-100">
                                </div>

                            </div>
                        </div>
                        <div class="w-100">
                            <div class="d-flex justify-content-between">
                                <h5 class="fs-5 mb-2 fw-bolder"> <?php echo e(ucwords($profileData->name)." ".ucwords($profileData->lastname)); ?> </h5>
                                <h5 class="fs-5 mb-2 fw-bolder"> </h5>

                            </div>
                            <?php if($profileData->phone != ''): ?>
                            <p class="d-flex text-dark align-items-center gap-2 mb-1">
                                <i class="ti ti-phone fs-4"></i><strong> +<?php echo e($profileData->country_code); ?>

                                    <?php echo e($profileData->phone); ?>

                                </strong>
                            </p>
                            <?php endif; ?>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <p class="mb-0 d-flex text-dark align-items-center gap-2">
                                    <i class="ti ti-mail fs-4"></i><?php echo e($profileData->email); ?>

                                </p>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->post_code != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Post Code : <?php echo e($profileData->post_code); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-2">
                                <?php if($profileData->preferred != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Preferred Name : <?php echo e($profileData->preferred); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>
                            <div class="d-md-flex align-items-center gap-3 mb-">
                                <?php if($profileData->store_url != ''): ?>
                                <p class="fs-3 mb-0 fw-bolder">Store URL: <?php echo e($profileData->store_url); ?></p>
                                <?php endif; ?>
                                <h5 class="fs-5 mb-0 fw-bolder"> </h5>

                            </div>


                        </div>
                    </div>
                </div>



            </div>

        </div>
    </div>
    <div class="card list-drpdwns-set">
        <div class="card-body">
            <?php echo $__env->make("admin.layouts.nurse_view_tabs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Tab panes -->
            <div class="tab-content border mt-2">
                <div class="tab-pane p-3 active show" id="navpill-1" role="tabpanel">
                    <div class="row">
                        <div class=" w-100  overflow-hidden">
                            <div class="card-body p-3 px-md-4 pb-0">
                                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Basic Details</h3>
                            </div>
                            <div class="card-body p-3 px-md-4">
                                <div class="col-md-12">
                                    <div class="row">
                                        <?php if($profileData->date_of_birth && $profileData->gender && $profileData->state && $profileData->city
                                        && $profileData->personal_website && $profileData->home_address && $profileData->emergency_conact_numeber): ?>
                                        <?php if($profileData->date_of_birth): ?>
                                        <div class="col-md-6 mt-3">
                                            <div class="d-flex gap-3 flex-wrap">
                                                
                                                <strong>Date of Birth : </strong>
                                                <span><?php echo e(\Carbon\Carbon::parse($profileData->date_of_birth)->format('d/m/Y')); ?></span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($profileData->gender): ?>
                                        <div class="col-md-6 mt-3">
                                            <div class="d-flex gap-3 flex-wrap">
                                                <!-- specialty_name_by_id -->
                                                <strong>Gender: </strong><span><?php echo e($profileData->gender); ?></span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        


                                        

                                        <?php if($profileData->state): ?>
                                        <div class="col-md-6 mt-3">
                                            <div class="d-flex gap-3 flex-wrap">
                                                <strong> State : </strong> <span><?php echo e(state_name($profileData->state)); ?></span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($profileData->city): ?>
                                        <div class="col-md-6 mt-3">
                                            <div class="d-flex gap-3 flex-wrap">
                                                <strong> City : </strong> <span><?php echo e($profileData->city); ?></span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($profileData->personal_website): ?>
                                        <div class="col-md-6 mt-3">
                                            <div class="d-flex gap-3 flex-wrap">
                                                <strong> Personal website : </strong> <span><?php echo e($profileData->personal_website); ?></span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($profileData->home_address): ?>
                                        <div class="col-md-6 mt-3">
                                            <div class="d-flex gap-3 flex-wrap">
                                                <strong>Home Address : </strong> <span><?php echo e($profileData->home_address); ?></span>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center  mt-3">Emergency Contact Information : </h4>
                                <?php if($profileData->emergency_conact_numeber): ?>
                                <div class="col-md-6 mt-3">
                                    <div class="d-flex gap-3 flex-wrap">
                                        <strong>Mobile No :</strong> <span>
                                            +<?php echo e($profileData->emegency_country_code); ?><?php echo e(" "); ?>

                                            <?php echo e($profileData->emergency_conact_numeber); ?>

                                        </span>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if($profileData->emergergency_contact_email): ?>
                                <div class="col-md-6 mt-3">
                                    <div class="d-flex gap-3 flex-wrap">
                                        <strong>Email :</strong> <span>
                                            <?php echo e($profileData->emergergency_contact_email); ?>

                                        </span>
                                    </div>
                                </div>
                                <?php endif; ?>


                                
                        <?php else: ?>
                        <div class="col-md-12">
                            <div class="text-center text-danger fs-5">No data found</div>
                        </div>

                        <?php endif; ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<div class="tab-pane p-3" id="navpill-3" role="tabpanel">
    <div class="row">
        <div class=" w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center "> Education and Certifications
                </h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="col-md-12">
                    <?php if($educationData && $profileData): ?>
                    <div class="row">

                        <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Educational Background : </h4>
                        <?php if($profileData->degree != 'null'): ?>
                        <?php $degree = json_decode($profileData->degree);
                        // print_r($degree);die;
                        ?>
                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Nurse & Midwife degree: </strong>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $degree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li><span class="dropdown-item-custom"><?php echo e(nurse_midwife_degree_by_id($value)); ?> , </span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom"></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($educationData->institution) && $educationData->institution): ?>
                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Institution : </strong>
                                <span class=""><?php echo e($educationData->institution); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($educationData->graduate_start_date) && $educationData->graduate_start_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Graduation Start Date : </strong>
                                <span class=""><?php echo e(\Carbon\Carbon::parse($educationData->graduate_start_date)->format('d/m/Y')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($educationData->graduate_end_date) && $educationData->graduate_end_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Graduation End Date : </strong>
                                <span class=""><?php echo e(\Carbon\Carbon::parse($educationData->graduate_end_date)->format('d/m/Y')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if($educationData->professional_certifications != 'null'): ?>
                        <?php $certifications = json_decode($educationData->professional_certifications);
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Professional Certifications :</strong>
                                <?php
                                $certificates = DB::table("professional_certificate")->orderBy("ordering_id", "asc")->get();
                                ?>

                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if(in_array($certificate->id,$certifications)): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($certificate->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No certifications found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->acls_data && $educationData->acls_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->acls_data){
                        $acls_data1 = json_decode($educationData->acls_data);
                        $a_data_arr = array();
                        foreach ($acls_data1 as $a_data) {
                        $a_data_arr[] = $a_data->acls_certification_id;
                        }
                        $a_data_json = json_encode($a_data_arr);
                        }else{
                        $acls_data1 = "";
                        $a_data_json = "";

                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>ACLS (Advanced Cardiovascular Life Support) :</strong>
                                <?php
                                $acls_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "6")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $acls_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acls_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($a_data->acls_certification_id == $acls_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($acls_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No certifications found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($a_data->acls_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($a_data->acls_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($a_data->acls_upload_certification ): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$a_data->acls_upload_certification )); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="text-success">View Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->bls_data && $educationData->bls_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->bls_data){
                        $bls_data1 = json_decode($educationData->bls_data);
                        $b_data_arr = array();
                        foreach ($bls_data1 as $b_data) {
                        $b_data_arr[] = $b_data->bls_certification_id;
                        }
                        $b_data_json = json_encode($b_data_arr);
                        }else{
                        $bls_data1 = "";
                        $b_data_json = "";

                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>BLS (Basic Life Support) :</strong>
                                <?php
                                $bls_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "7")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $bls_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bls_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($b_data->bls_certification_id == $bls_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($bls_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No certifications found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($b_data->bls_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($b_data->bls_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($b_data->bls_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$b_data->bls_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="text-success">No Image</span>
                                <?php endif; ?>

                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->cpr_data && $educationData->cpr_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->cpr_data){
                        $cpr_data1 = json_decode($educationData->cpr_data);
                        $c_data_arr = array();
                        foreach ($cpr_data1 as $c_data) {
                        $c_data_arr[] = $c_data->cpr_certification_id;
                        }
                        $c_data_json = json_encode($c_data_arr);
                        }else{
                        $cpr_data1 = "";
                        $c_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>CPR (Cardiopulmonary Resuscitation) :</strong>
                                <?php
                                $cpr_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "8")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $cpr_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpr_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($c_data->cpr_certification_id == $cpr_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($cpr_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($c_data->cpr_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($c_data->cpr_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($c_data->cpr_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$c_data->cpr_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->nrp_data && $educationData->nrp_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->nrp_data){
                        $nrp_data1 = json_decode($educationData->nrp_data);
                        $n_data_arr = array();
                        foreach ($nrp_data1 as $n_data) {
                        $n_data_arr[] = $n_data->nrp_certification_id;
                        }
                        $n_data_json = json_encode($n_data_arr);
                        }else{
                        $nrp_data1 = "";
                        $n_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>NRP (Neonatal Resuscitation Program) :</strong>
                                <?php
                                $nrp_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "9")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $nrp_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nrp_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($n_data->nrp_certification_id == $nrp_data->name ): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($nrp_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($n_data->nrp_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($n_data->nrp_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($n_data->nrp_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$n_data->nrp_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->pals_data && $educationData->pals_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->pals_data){
                        $pls_data1 = json_decode($educationData->pals_data);
                        $p_data_arr = array();
                        foreach ($pls_data1 as $p_data) {
                        $p_data_arr[] = $p_data->pls_certification_id;
                        }
                        $p_data_json = json_encode($p_data_arr);
                        }else{
                        $pls_data1 = "";
                        $p_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>PALS (Pediatric Advanced Life Support) :</strong>
                                <?php if($palsData): ?>
                                <?php
                                $pals_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "10")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $pals_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pals_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($p_data->pls_certification_id == $pals_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($pals_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                                <?php else: ?>
                                <ul class="dropdown-list">

                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>

                                </ul>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($p_data->pls_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($p_data->pls_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($p_data->pls_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$p_data->pls_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->rn_data && $educationData->rn_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->rn_data){
                        $rn_data1 = json_decode($educationData->rn_data);
                        $r_data_arr = array();
                        foreach ($rn_data1 as $r_data) {
                        $r_data_arr[] = $r_data->rn_certification_id;
                        }
                        $r_data_json = json_encode($r_data_arr);
                        }else{
                        $rn_data1 = "";
                        $r_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>RN (Registered Nurse) :</strong>

                                <?php
                                $rn_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "11")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $rn_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rn_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($r_data->rn_certification_id == $rn_data->name ): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($rn_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($r_data->rn_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($r_data->rn_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($r_data->rn_certification_id ): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$r_data->rn_upload_certification )); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->np_data && $educationData->np_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->np_data){
                        $np_data1 = json_decode($educationData->np_data);
                        $n_data_arr = array();
                        foreach ($np_data1 as $n_data) {
                        $n_data_arr[] = $n_data->np_certification_id;
                        }
                        $np_data_json = json_encode($n_data_arr);
                        }else{
                        $np_data1 = "";
                        $np_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>NP (Nurse Practioner) / (APRN) Advanced Practice Registered Nurse :</strong>

                                <?php
                                $np_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "12")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $np_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $np_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($n_data->np_certification_id == $np_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($np_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($n_data->np_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($n_data->np_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($rn_file): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$n_data->np_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->cna_data && $educationData->cna_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->cna_data){
                        $cna_data1 = json_decode($educationData->cna_data);
                        $cn_data_arr = array();
                        foreach ($cna_data1 as $cn_data) {
                        $cn_data_arr[] = $cn_data->cn_certification_id;
                        }
                        $cna_data_json = json_encode($cn_data_arr);
                        }else{
                        $cna_data1 = "";
                        $cna_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>CNA (Certified Nursing Assistant) / EN (Enrolled Nurse) :</strong>

                                <?php
                                $cna_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "13")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $cna_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cna_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($cn_data->cn_certification_id == $cna_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($cna_data->name); ?> ,</span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($cn_data->np_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($cn_data->np_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($cna_file): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$cn_data->np_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->lpn_data && $educationData->lpn_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->lpn_data){
                        $lpn_data1 = json_decode($educationData->lpn_data);
                        $lpn_data_arr = array();
                        foreach ($lpn_data1 as $lpn_data) {
                        $lpn_data_arr[] = $lpn_data->lpn_certification_id;
                        }
                        $lpn_data_json = json_encode($lpn_data_arr);
                        }else{
                        $lpn_data1 = "";
                        $lpn_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>LPN (Licensed Practical Nurse) / LVN (Licensed Vocational Nurse) :</strong>

                                <?php
                                $lpn_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "14")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $lpn_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpn_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($lpn_data->lpn_certification_id == $lpn_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($lpn_data->name); ?>,</span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($lpn_data->lpn_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($lpn_data->lpn_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($lpn_data->lpn_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$lpn_data->lpn_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->crna_data && $educationData->crna_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->crna_data){
                        $crna_data1 = json_decode($educationData->crna_data);
                        $crna_data_arr = array();
                        foreach ($crna_data1 as $crna_data) {
                        $crna_data_arr[] = $crna_data->crna_certification_id;
                        }
                        $crna_data_json = json_encode($crna_data_arr);
                        }else{
                        $crna_data1 = "";
                        $crna_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>CRNA (Certified Registered Nurse Anesthetist) :</strong>

                                <?php
                                $crna_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "15")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $crna_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crna_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($crna_data->crna_certification_id == $crna_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($crna_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($crna_data->crna_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($crna_data->crna_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($crna_file): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$crna_data->crna_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->cnm_data && $educationData->cnm_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->cnm_data){
                        $cnm_data1 = json_decode($educationData->cnm_data);
                        $cnm_data_arr = array();
                        foreach ($cnm_data1 as $cnm_data) {
                        $cnm_data_arr[] = $cnm_data->cnm_certification_id;
                        }
                        $cnm_data_json = json_encode($cnm_data_arr);
                        }else{
                        $cnm_data1 = "";
                        $cnm_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>CNM (Certified Nurse Midwife) :</strong>

                                <?php
                                $cnm_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "16")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $cnm_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnm_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($cnm_data->cnm_certification_id == $cnm_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($cnm_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($cnm_data->cnm_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($cnm_data->cnm_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($cnm_data->cnm_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$cnm_data->cnm_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->ons_data && $educationData->ons_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->ons_data){
                        $ons_data1 = json_decode($educationData->ons_data);
                        $ons_data_arr = array();
                        foreach ($ons_data1 as $ons_data) {
                        $ons_data_arr[] = $ons_data->ons_certification_id;
                        }
                        $ons_data_json = json_encode($ons_data_arr);
                        }else{
                        $ons_data1 = "";
                        $ons_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>ONS/ONCC (Oncology Nursing Society/Oncology Nursing Certification Corporation) :</strong>

                                <?php
                                $ons_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "17")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $ons_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ons_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($ons_data->ons_certification_id == $ons_data->name ): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($ons_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($ons_data->ons_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($ons_data->ons_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($cnm_file): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$ons_data->ons_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->msw_data && $educationData->msw_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->msw_data){
                        $msw_data1 = json_decode($educationData->msw_data);
                        $msw_data_arr = array();
                        foreach ($msw_data1 as $msw_data) {
                        $msw_data_arr[] = $msw_data->msw_certification_id;
                        }
                        $msw_data_json = json_encode($msw_data_arr);
                        }else{
                        $msw_data1 = "";
                        $msw_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>MSW/AiM (Maternity Support Worker/Assistant in Midwifery ) / Midwife Assistant :</strong>

                                <?php
                                $msw_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "18")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $msw_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msw_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($msw_data->msw_certification_id == $msw_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($msw_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($msw_data->msw_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($msw_data->msw_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($msw_data->msw_certification_id): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$msw_data->msw_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->ain_data && $educationData->ain_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->ain_data){
                        $ain_data1 = json_decode($educationData->ain_data);
                        $ain_data_arr = array();
                        foreach ($ain_data1 as $ain_data) {
                        $ain_data_arr[] = $ain_data->ain_certification_id;
                        }
                        $ain_data_json = json_encode($ain_data_arr);
                        }else{
                        $ain_data1 = "";
                        $ain_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>AIN (Assistant in Nursing) / NA (Nurse Associate) / HCA (Healthcare Assistant) :</strong>

                                <?php
                                $ain_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "19")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $ain_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ain_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($ain_data->ain_certification_id == $ain_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($ain_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($ain_data->ain_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($ain_data->ain_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($ain_file): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$ain_data->ain_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->rpn_data && $educationData->rpn_data != 'null'): ?>
                        <?php
                        if($educationData && $educationData->rpn_data){
                        $rpn_data1 = json_decode($educationData->rpn_data);
                        $rpn_data_arr = array();
                        foreach ($rpn_data1 as $rpn_data) {
                        $rpn_data_arr[] = $rpn_data->rpn_certification_id;
                        }
                        $rpn_data_json = json_encode($rpn_data_arr);
                        }else{
                        $rpn_data1 = "";
                        $rpn_data_json = "";
                        }
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>RPN (Registered Practical Nurse) / RGN (Registered General Nurse) :</strong>

                                <?php
                                $rpn_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "20")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $rpn_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpn_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($rpn_data->rpn_certification_id == $rpn_data->name): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($rpn_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($rpn_data->rpn_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($rpn_data->rpn_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($rpn_data->rpn_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$rpn_data->rpn_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($educationData->nl_data && $educationData->nl_data != 'null'): ?>
                        <?php
                        $nl_data_ids = json_decode($educationData->nl_data, true); // Decode the acls_data field into an array
                        $nlData = json_decode($nl_data_ids['nl_data'], true);
                        $nl_licence_num = $nl_data_ids['nl_licence_num'];
                        $nl_licence_expiry = $nl_data_ids['nl_licence_expiry'];
                        $nl_file = $nl_data_ids['nl_file'];
                        ?>

                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>No License/Certification :</strong>

                                <?php
                                $nl_datas = DB::table("professional_certificate_table")
                                    ->where("cert_id", "21")
                                    ->get();
                                ?>
                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $nl_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nl_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if(is_array($nl_data_ids) && in_array($nl_data->professionalcert_id,$nlData)): ?>
                                    <li><span class="dropdown-item-custom"><?php echo e($nl_data->name); ?> , </span></li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom">No Data found</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number :</strong>
                                <span class=""><?php echo e($nl_licence_num); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry :</strong>
                                <span class=""><?php echo e($nl_licence_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Image :</strong>
                                <?php if($nl_file): ?>
                                <a href="<?php echo e(asset('uploads/'.$nl_file)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>





                        <?php if($educationData->licence_number && $educationData->country &&
                        $educationData->state && $educationData->expiration_date ): ?>
                        <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Licenses: </h4>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>licence_number : </strong>
                                <span class=""><?php echo e($educationData->licence_number); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Country : </strong>
                                <span class=""><?php echo e($educationData->country); ?> </span>
                                
                            </div>
                        </div>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>State : </strong>
                                <span class=""><?php echo e(state_name( $educationData->state)); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiration Date : </strong>
                                <span class=""><?php echo e(\Carbon\Carbon::parse($educationData->expiration_date)->format('d/m/Y')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php
                        // $training_workshops = json_decode($educationData->training_workshops);
                        ?>
                        <?php
                        if (!empty($educationData)) {
                            $certificate_data = json_decode($educationData->additional_training_data);
                        } else {
                            $certificate_data = "";
                        }

                        ?>
                        <?php
                        $i = 1;
                        ?>
                        <?php if(!empty($certificate_data)): ?>
                        <?php $__currentLoopData = $certificate_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Additional Training :</h4>

                        <h6>Certification/Licence <?php echo e($i); ?></h6>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Courses/workshops : </strong>
                                <span class=""><?php echo e($c_data->training_courses); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Certification/Licence Number : </strong>
                                <span class=""><?php echo e($c_data->additional_license_number); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry : </strong>
                                <span class=""><?php echo e($c_data->additional_expiry); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Upload your certification/Licence : </strong>
                                <?php if($c_data->additional_upload_certification): ?>
                                <a href="<?php echo e(asset('uploads/certificates/'.$c_data->additional_upload_certification)); ?>" target="_blank">
                                    <span class="text-success">View Image</span>
                                </a>
                                <?php else: ?>
                                <span class="">No Image</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>



                    </div>
                    <?php else: ?>
                    <div class="col-md-12">
                        <div class="text-center text-danger fs-5">No data found</div>
                    </div>

                    <?php endif; ?>


                </div>

            </div>
        </div>
    </div>
</div>

<div class="tab-pane p-3" id="navpill-4.1" role="tabpanel">
    <div class="row">
        <div class=" w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">References</h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="col-md-12">
                    <?php if(!empty($RefereData)): ?>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $RefereData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <h4>References <?php echo e($i); ?></h4>
                        <?php if(isset($data->first_name) && $data->first_name): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>First name: </strong>
                                <span><?php echo e($data->first_name); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($data->last_name) && $data->last_name): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Last name: </strong>
                                <span><?php echo e($data->last_name); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($data->email) && $data->email): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Email: </strong>
                                <span><?php echo e($data->email); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($data->phone_no) && $data->phone_no): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Last name: </strong>
                                <span><?php echo e($data->phone_no); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($data->relationship) && $data->relationship): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Relationship: </strong>
                                <span><?php echo e($data->relationship); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($data->worked_together) && $data->worked_together): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>You worked together at: </strong>
                                <span><?php echo e($data->worked_together); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>


                        <?php if(isset($data->start_date) && $data->start_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Start Date : </strong><span><?php echo e(\Carbon\Carbon::parse($data->start_date)->format('d/m/Y')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($data->end_date) && $data->end_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong> End Date : </strong><span><?php echo e(\Carbon\Carbon::parse($data->end_date)->format('d/m/Y')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($data->position_with_referee) && $data->position_with_referee): ?>
                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>What was your position when you worked with this referee?: </strong>
                                <span><?php echo e($data->position_with_referee); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php
                    $i++;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <div class="col-md-12">
                        <div class="text-center text-danger fs-5">No data found</div>
                    </div>

                    <?php endif; ?>

                </div>

            </div>
        </div>
    </div>
</div>
<div class="tab-pane p-3" id="navpill-5" role="tabpanel">
    <div class="row">
        <div class=" w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Mandatory Training</h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="col-md-12">
                    <?php if($mandatorytrainingData): ?>
                    <div class="row">
                        <h4>Completed training programs</h4>
                        <?php if(isset($mandatorytrainingData->start_date) && $mandatorytrainingData->start_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Training Start Date : </strong><span><?php echo e(\Carbon\Carbon::parse($mandatorytrainingData->start_date)->format('d/m/Y')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($mandatorytrainingData->end_date) && $mandatorytrainingData->end_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Training End Date : </strong><span><?php echo e(\Carbon\Carbon::parse($mandatorytrainingData->end_date)->format('d/m/Y')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($mandatorytrainingData->institutions) && $mandatorytrainingData->institutions): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Institution: </strong>
                                <span><?php echo e($mandatorytrainingData->institutions); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($mandatorytrainingData->continuing_education) && $mandatorytrainingData->continuing_education): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Mandatory Continuing Education: </strong>
                                <span><?php echo e($mandatorytrainingData->continuing_education); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <div class="col-md-12">
                        <div class="text-center text-danger fs-5">No data found</div>
                    </div>

                    <?php endif; ?>

                </div>

            </div>
        </div>
    </div>
</div>
<div class="tab-pane p-3" id="navpill-6" role="tabpanel">
    <div class="row">
        <div class=" w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Vaccinations</h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="col-md-12">
                    <?php if($vaccinationData): ?>
                    <div class="row">
                        <?php
                        $vacc = [];
                        ?>

                        <?php if(!empty($vaccinationData)): ?>
                        <?php $__currentLoopData = $vaccinationData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vcdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $vacc[] = $vcdata->vaccination_id; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if(count($vacc)>0): ?>
                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Vaccination Records : </strong>

                                <ul class="dropdown-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $vaccinationData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <li><span class="dropdown-item-custom"><?php echo e(vaccination_name_by_id($value->vaccination_id)); ?> </span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <li><a href="#" class="dropdown-item-custom"></a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="vacc_rec_div">
                            <?php
                            if (!empty($vccdata)) {
                                foreach ($vccdata as $vcvalue) { ?>

                                    <div class="record_v">
                                        <h6><?php echo e($vcvalue->vaccination_name); ?></h6>
                                        <div class="row vacc_rec_institution">
                                            <div class="form-group col-md-12">
                                                <?php
                                                $vcc_level_req = DB::table("vcc_level_req")->where("type", $vcvalue->vaccination_id)->get();
                                                ?>
                                                <label class="form-label">Level of Requirement : </label>
                                                <div>
                                                    <?php $__currentLoopData = $vcc_level_req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label><?php echo e($level->level_req); ?></label><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label class="form-label">Immunization Status :</label>
                                                <label class="form-label"><?php echo e($vcvalue->imm_status); ?></label>
                                            </div>
                                            <?php if($vcvalue->covid_dose !=0): ?>
                                            <div class="form-group col-md-12">
                                                <label class="form-label">How many doses of a TGA-recognised COVID-19 vaccine have you received? : </label>
                                                <label class="form-label"><?php echo e($vcvalue->covid_dose); ?> dose</label>
                                            </div>
                                            <?php endif; ?>

                                            <div class="form-group col-md-12">
                                                <label class="form-label">Evidence Required:</label>
                                                <label class="form-label"><?php echo e($vcvalue->evidence_type_name); ?></label>
                                            </div>
                                            <div class="form-group col-md-12">
                                                <label class="form-label">Evidence : </label>
                                                <div id="fileList" class="file-list">
                                                    <?php
                                                    $getevidancedata = DB::table("evidance_file")->where("vcc_front_id", $vcvalue->id)->get();
                                                    if ($getevidancedata->isNotEmpty()) {
                                                        foreach ($getevidancedata as $vals) { ?>
                                                            <div class="file-item">
                                                                <a href="<?php echo e(asset('uploads/evidence/' . $vals->file_name)); ?>" target="_blank"><i class="fa fa-file" aria-hidden="true"></i> <?php echo e($vals->original_name); ?></a>
                                                            </div>
                                                    <?php }
                                                    } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php  }
                            } ?>
                        </div>

                        <!--[ADD OTHER VACCINE START]-->
                        <div class="row" id="vaccine-section-container">
                            <h6 class="other-vaccin">Other Vaccination </h6>
                            <?php $ci = 1; ?>
                            <?php if($other_vaccine): ?>
                            <?php $__currentLoopData = $other_vaccine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="vaccine-section">
                                <div class="col-md-12">
                                    <input type="hidden" name="other_id[]" value="<?php echo e($other->id); ?>">
                                    <h6>Vaccination <?php echo e($ci); ?></h6>
                                    <div class="form-group level-drp">
                                        <label class="form-label" for="input-1">Vaccination Name : </label>
                                        <label class="form-label" for="input-1"><?php echo e($other->vaccination_name); ?> </label>
                                    </div>

                                    <div class="form-group level-drp">
                                        <label class="form-label" for="input-1">Immunization Status : </label>
                                        <label class="form-label" for="input-1">
                                            <?php
                                            $get_imm_status = DB::table("imm_status")->get();
                                            foreach ($get_imm_status as $status) {
                                                if ($other->immunization_status == $status->id) {
                                                    echo $status->name;
                                                }
                                            } ?>
                                        </label>
                                    </div>
                                    <div class="form-group level-drp">
                                        <label class="form-label" for="input-1">Evidence Type : </label>
                                        <label class="form-label" for="input-1"><?php echo e($other->evidence_type); ?></label>
                                    </div>
                                    <div class="form-group level-drp">
                                        <label class="form-label" for="input-1">Upload Evidence : </label>
                                        <div id="fileListo" class="file-list">
                                            <?php if($other->evidence_file!=''): ?>
                                            <div class="file-item">
                                                <a href="<?php echo e(asset('uploads/evidence/' . $other->evidence_file)); ?>" target="_blank"><i class="fa fa-file" aria-hidden="true"></i> <?php echo e($other->evidence_file); ?></a>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <span class="reqError text-danger valley"></span>
                                    </div>
                                </div>
                            </div>
                            <?php $ci++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <!--[ADD OTHER VACCINE END]-->
                    </div>
                    <?php else: ?>
                    <div class="col-md-12">
                        <div class="text-center text-danger fs-5">No data found</div>
                    </div>

                    <?php endif; ?>

                </div>

            </div>
        </div>
    </div>
</div>
<div class="tab-pane p-3" id="navpill-7" role="tabpanel">
    <div class="row">
        <div class=" w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Checks and Clearances</h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="col-md-12">
                    
                    <div class="row">
                        <?php if($work_eligibility): ?>
                        <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center ">Residency and Work Eligibility : </h4>
                        <?php if(isset($work_eligibility->residency) && $work_eligibility->residency): ?>

                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Residency : </strong><span><?php echo e($work_eligibility->residency); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($work_eligibility->passport_number) && $work_eligibility->passport_number): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Passport Number : </strong>
                                <span><?php echo e($work_eligibility->passport_number); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($work_eligibility->country_name) && $work_eligibility->country_name): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Passport Country Of Issue: </strong>
                                <span><?php echo e($work_eligibility->country_name); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($work_eligibility->sublcass_text) && $work_eligibility->sublcass_text): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Visa Subclass Number : </strong>
                                <span><?php echo e($work_eligibility->sublcass_text); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($work_eligibility->other_visa_type) && $work_eligibility->other_visa_type): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Other Visa Type: </strong>
                                <span><?php echo e($work_eligibility->other_visa_type); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($work_eligibility->visa_grant_number) && $work_eligibility->visa_grant_number): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Visa grant number: </strong>
                                <span><?php echo e($work_eligibility->visa_grant_number); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($work_eligibility->evidence_type) && $work_eligibility->evidence_type): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Evience Type: </strong>
                                <span><?php echo e($work_eligibility->evidence_type); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($work_eligibility->support_document) && $work_eligibility->support_document): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Support Document:</strong>
                                <a href="<?php echo e(asset('uploads/support_document/'.$work_eligibility->support_document)); ?>" target="_blank">
                                    <span class="text-success">View Document</span>
                                </a>
                            </div>

                        </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <div class="col-md-12">
                            <div class="text-center text-danger fs-5">No data found</div>
                        </div>

                        <?php endif; ?>
                        
                        <?php if($ndis): ?>
                        <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center mt-3">NDIS Worker Screening Check : </h4>
                        <?php if(isset($ndis->state_id) && $ndis->state_id): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>State: </strong><span><?php echo e(state_name($ndis->state_id)); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($ndis->clearance_number) && $ndis->clearance_number): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>NDIS Worker Clearance Number: </strong><span><?php echo e($ndis->clearance_number); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($ndis->expiry_date) && $ndis->expiry_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Expiry date: </strong><span><?php echo e($ndis->expiry_date); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($ndis->evidence_file) && $ndis->evidence_file): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Support Document:</strong>
                                <a href="<?php echo e(asset('uploads/support_document/'.$ndis->evidence_file)); ?>" target="_blank">
                                    <span class="text-success">View Document</span>
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php else: ?>
                        <div class="col-md-12">
                            <div class="text-center text-danger fs-5">No data found</div>
                        </div>

                        <?php endif; ?>

                        <?php if($ww_child): ?>
                        <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center mt-3">Working With Children Check : </h4>
                        <?php $__currentLoopData = $ww_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>State: </strong><span><?php echo e(state_name($child->state_id)); ?></span>
                                </div>
                            </div>

                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>Clearance Number : </strong><span><?php echo e($child->clearance_number); ?></span>
                                </div>
                            </div>   

                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>Expiry Date: </strong> <span><?php echo e($child->expiry_date); ?></span>
                                </div>
                            </div>

                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>Support Document:</strong>
                                    <a href="<?php echo e(asset('uploads/support_document/'.$child->wwcc_evidence)); ?>" target="_blank">
                                        <span class="text-success">View Document</span>
                                    </a>
                                </div>
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="col-md-12">
                            <div class="text-center text-danger fs-5">No data found</div>
                        </div>

                        <?php endif; ?>


                        <?php if($policy_check): ?>
                        <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center mt-3">Police check : </h4>
                        
                        <?php if(isset($policy_check->issuance_date) && $policy_check->issuance_date): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Date : </strong><span><?php echo e($policy_check->issuance_date); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($policy_check->evidence_file) && $policy_check->evidence_file): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Police Clearance : </strong>
                                <a href="<?php echo e(asset('uploads/support_document/'.$policy_check->evidence_file)); ?>" target="_blank">
                                    <img src="<?php echo e(asset('uploads/support_document/'.$policy_check->evidence_file)); ?>" alt="" style="height:50px;width:50px">
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                                                
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Status : </strong>
                                <?php if($policy_check->status == 1): ?>
                                <span class="badge bg-success">Approvedee</span>
                                <?php elseif($policy_check->status == 0): ?>
                                <span class="badge bg-danger">Pending</span>
                                <?php elseif($policy_check->status == 2): ?>
                                <span class="badge bg-danger">Rejected</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php if(isset($policy_check->status) && $policy_check->status == 2): ?>
                        <div class="col-md-12 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Reason : </strong>
                                <span><?php echo e($policy_check->reason); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <div class="col-md-12">
                            <div class="text-center text-danger fs-5">No data found</div>
                        </div>
                        <?php endif; ?>


                        <?php if($specialize): ?>
                        <h4 class="fw-bolder fs-6 lh-base d-flex align-items-center mt-3">Specialized Clearances : </h4>
                        <?php $__currentLoopData = $specialize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialized): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>State: </strong><span><?php echo e(state_name($specialized->clearance_state)); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>Specialized Clearance type: </strong> <span><?php echo e($specialized->clearance_type); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>Specialized Clearance Number: </strong> <span><?php echo e($specialized->clearance_number); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>Expiry Date: </strong> <span><?php echo e($specialized->clearance_expiry_date); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6 mt-3">
                                <div class="d-flex gap-3 flex-wrap">
                                    <strong>Support Document:</strong>
                                    <a href="<?php echo e(asset('uploads/support_document/'.$specialized->clearance_evidence)); ?>" target="_blank">
                                        <span class="text-success">View Document</span>
                                    </a>
                                </div>
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="col-md-12">
                            <div class="text-center text-danger fs-5">No data found</div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="tab-pane p-3" id="navpill-9" role="tabpanel">
    <div class="row">
        <div class=" w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center">Interview and References</h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="col-md-12">
                    <?php if($interviewrefData): ?>
                    <div class="row">

                        <?php if(isset($interviewrefData->interview_availablity) && $interviewrefData->interview_availablity): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Interview Availability : </strong><span><?php echo e(\Carbon\Carbon::parse($interviewrefData->interview_availablity)->format('d/m/y H:i')); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($interviewrefData->reference_name) && $interviewrefData->reference_name): ?>
                        <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Professional References</h4>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Names : </strong><span><?php echo e($interviewrefData->reference_name); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($interviewrefData->reference_email) && $interviewrefData->reference_email): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Email: </strong>
                                <span><?php echo e($interviewrefData->reference_email); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($interviewrefData->contact_country_code) && $interviewrefData->contact_country_code): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Mobile Number : </strong>
                                <span>+<?php echo e($interviewrefData->contact_country_code); ?><?php echo e(" "); ?>

                                    <?php echo e($interviewrefData->reference_contact); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($interviewrefData->reference_relationship) && $interviewrefData->reference_relationship): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Relationship : </strong>
                                <span><?php echo e($interviewrefData->reference_relationship); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <div class="col-md-12">
                        <div class="text-center text-danger fs-5">No data found</div>
                    </div>

                    <?php endif; ?>

                </div>

            </div>
        </div>
    </div>
</div>
<div class="tab-pane p-3" id="navpill-10" role="tabpanel">
    <div class="row">
        <div class=" w-100  overflow-hidden">
            <div class="card-body p-3 px-md-4 pb-0">
                <h3 class="fw-bolder fs-6 lh-base d-flex align-items-center">Personal Preferences</h3>
            </div>
            <div class="card-body p-3 px-md-4">
                <div class="col-md-12">
                    <?php if($personalprefData): ?>
                    <div class="row">

                        <?php if(isset($personalprefData->preferred_work_schedule) && $personalprefData->preferred_work_schedule): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Preferred Work Schedule : </strong><span><?php echo e($personalprefData->preferred_work_schedule); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($personalprefData->country) && $personalprefData->country): ?>
                        <h4 class="mt-4 fw-bolder fs-6 lh-base d-flex align-items-center">Preferred Work Locations</h4>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Country : </strong><span><?php echo e(country_name($personalprefData->country)); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($personalprefData->state) && $personalprefData->state): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>State: </strong>
                                <span><?php echo e(state_name($personalprefData->state)); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($personalprefData->work_environment) && $personalprefData->work_environment): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Work Environment Preferences : </strong>
                                <span><?php echo e($personalprefData->work_environment); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($personalprefData->shift_preferences) && $personalprefData->shift_preferences): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Shift Preferences : </strong>
                                <span><?php echo e($personalprefData->shift_preferences); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($personalprefData->specific_facilities) && $personalprefData->specific_facilities): ?>
                        <div class="col-md-6 mt-3">
                            <div class="d-flex gap-3 flex-wrap">
                                <strong>Specific Facilities : </strong>
                                <textarea name="specific_facilities" class="form-control"><?php echo e($personalprefData->specific_facilities); ?></textarea>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <div class="col-md-12">
                        <div class="text-center text-danger fs-5">No data found</div>
                    </div>

                    <?php endif; ?>

                </div>

            </div>
        </div>
    </div>
</div>

</div>
</div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript"
    src="https://nextjs.webwiders.in/pindrow/public/advertiser/dist/libs/owl.carousel/dist/owl.carousel.min.js">
</script>

<script type="text/javascript"></script>
<script>
    $(document).ready(function() {
        // cate_1
        $('#cat_1').after(sugical_care);
        $('#sugical_care').after(Operating_Room);
        $('#Operating_Room').after(paediatric_oR);
        $('#paediatric_oR').after(Technician_Nurse);

        // For cat 2
        $('#cat_2').after(Surgical_Obstetrics);

        // For cat 3
        $('#cat_3').after(Neonatal_Care);
        $('#Neonatal_Care').after(Surgical_Preop);
        $('#Surgical_Preop').after(Paediatric_Operating);
        $('#Paediatric_Operating').after(Paediatric_Operating_Scout);
        $('#Paediatric_Operating_Scout').after(Paediatric_Operating_Scrub);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mediqa/public_html/resources/views/admin/profile-view.blade.php ENDPATH**/ ?>